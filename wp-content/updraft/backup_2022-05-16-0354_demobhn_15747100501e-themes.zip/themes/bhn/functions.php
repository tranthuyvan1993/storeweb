<?php
/**
 * posolo functions and definitions
 *
 * @version 1.0
 *
 * @date 12.08.2015
 */

load_theme_textdomain( 'posolo', get_template_directory() . '/languages' );

/**
 * Set the content width based on the theme's design and stylesheet.
 */
if ( ! isset( $content_width ) ) {
	$content_width = 640; /* pixels */
}

require_once( trailingslashit( get_template_directory() ). '/t888core/function/function.php' );
require_once( trailingslashit( get_template_directory() ). '/t888core/config/config.php' );

// LOAD CLASS LIB

require_once( trailingslashit( get_template_directory() ). '/t888core/class/asset.php' );
require_once( trailingslashit( get_template_directory() ). '/t888core/class/class-tgm-plugin-activation.php' );
require_once( trailingslashit( get_template_directory() ). '/t888core/class/importer.php' );
require_once( trailingslashit( get_template_directory() ). '/t888core/class/mega_menu.php' );
require_once( trailingslashit( get_template_directory() ). '/t888core/class/order-comment-field.php' );
require_once( trailingslashit( get_template_directory() ). '/t888core/class/require-plugin.php' );
require_once( trailingslashit( get_template_directory() ). '/t888core/class/template.php' );

// END LOAD

// LOAD CONTROLER LIB

require_once( trailingslashit( get_template_directory() ). '/t888core/controler/BaseControl.php' );
require_once( trailingslashit( get_template_directory() ). '/t888core/controler/Customize_Control.php' );
require_once( trailingslashit( get_template_directory() ). '/t888core/controler/Visual_composer_Control.php' );
require_once( trailingslashit( get_template_directory() ). '/t888core/controler/Walker_megamenu.php' );
require_once( trailingslashit( get_template_directory() ). '/t888core/controler/Woocommerce_Control.php' );
require_once( trailingslashit( get_template_directory() ). '/t888core/controler/Woocommerce_Variable.php' );
require_once( trailingslashit( get_template_directory() ). '/t888core/controler/Multi_Language_Control.php' );
//require_once( trailingslashit( get_template_directory() ). '/t888core/controler/Project_Control.php' );
// require_once( trailingslashit( get_template_directory() ). '/t888core/controler/Banner_Item_Control.php' );
// require_once( trailingslashit( get_template_directory() ). '/t888core/controler/Images_Library_Control.php');
// require_once( trailingslashit( get_template_directory() ). '/t888core/controler/Header_Control.php' );
// require_once( trailingslashit( get_template_directory() ). '/t888core/controler/Footer_Control.php' );
require_once( trailingslashit( get_template_directory() ). '/t888core/controler/MegaItem_Control.php' );
if(class_exists('Redux')) require_once( trailingslashit( get_template_directory() ). '/t888core/controler/redux-config.php' );
else require_once( trailingslashit( get_template_directory() ). '/t888core/controler/Option_Control.php' );
require_once( trailingslashit( get_template_directory() ). '/t888core/controler/Metabox_Control.php' );
require_once( trailingslashit( get_template_directory() ). '/t888core/metabox/Metabox-Page-Controller.php' );
require_once( trailingslashit( get_template_directory() ). '/t888core/metabox/Metabox-Post-Controller.php' );
require_once( trailingslashit( get_template_directory() ). '/t888core/controler/Custom_Product_Control.php');
require_once( trailingslashit( get_template_directory() ). '/t888core/metabox/Metabox-Product-Controller.php' );
//require_once( trailingslashit( get_template_directory() ). '/t888core/metabox/Metabox-Project-Controller.php' );
//require_once( trailingslashit( get_template_directory() ). '/t888core/metabox/Metabox-Project-Service-Controller.php' );
// require_once( trailingslashit( get_template_directory() ). '/t888core/metabox/Metabox-Banner-Item-Controller.php' );
// END LOAD

require_once( trailingslashit( get_template_directory() ). '/t888core/index.php' );


function remove_default_posts_meta_boxes() {
        remove_meta_box( 'linktargetdiv', 'link', 'normal' );
        remove_meta_box( 'linkxfndiv', 'link', 'normal' );
        remove_meta_box( 'linkadvanceddiv', 'link', 'normal' );
        remove_meta_box( 'trackbacksdiv', 'post', 'normal' );
        remove_meta_box( 'postcustom', 'post', 'normal' );
        remove_meta_box( 'commentstatusdiv', 'post', 'normal' );
        remove_meta_box( 'commentsdiv', 'post', 'normal' );
        remove_meta_box( 'revisionsdiv', 'post', 'normal' );
        remove_meta_box( 'authordiv', 'post', 'normal' );
        remove_meta_box( 'sqpt-meta-tags', 'post', 'normal' );
        remove_meta_box( 'slugdiv', 'post', 'normal' );
}
add_action( 'admin_menu', 'remove_default_posts_meta_boxes' );


//add_filter( 'the_content', 'shortcode_unautop');
//add_filter( 'the_content', 'do_shortcode');

add_filter('use_block_editor_for_post', '__return_false', 10);