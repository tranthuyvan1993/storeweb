<?php
/**
 * Created by PhpStorm.
 * User: toanngo92
 * Date: 4/12/2019
 * Time: 3:00 PM
 */

if(!function_exists('tech888f_vc_mega_list_image'))
{
    function tech888f_vc_mega_list_image($attr)
    {
        $html = '';
        $css_class = '';

        // merge data to responsive page builder

        $data_array = array_merge(array(
            'style'         => '',
            'title'         => '',
            'size'          => '',
            'list_image'         => '',
            'el_class'      => '',
            'custom_css'    => '',
        ),tech888f_get_responsive_default_atts());

        $attr = shortcode_atts($data_array,$attr);
        extract($attr);
        $css_classes = vc_shortcode_custom_css_class( $custom_css );
        $css_class = preg_replace( '/\s+/', ' ', apply_filters( 'vc_shortcodes_css_class', $css_classes, '', $attr ) );
        // Variable process vc_shortcodes_css_class
        if(!empty($css_class)) $el_class .= ' '.$css_class;
        if(!empty($style)) $el_class .= ' '.$style;
        $data = (array) vc_param_group_parse_atts( $list_image );
        $default_val = array(
            'img_title'         => '',
            'img_title_2'         => '',
            'list'          => '',
            'style'         => '',
            'custom_class'  => '',
            'url'           => '',
        );

        // Add variable to data
        $attr = array_merge($attr,array(
            'el_class' => $el_class,
            'data'          => $data,
            'default_val'   => $default_val,
        ));

        // frontend
        $html = tech888f_get_template_element('mega-list-image/list',$style,$attr);
        return $html;

        // End frontend
    }
}

stp_reg_shortcode('tech888f_mega_list_image','tech888f_vc_mega_list_image');

vc_map( array(
    "name"      => esc_html__("Mega List Image", 'posolo'),
    "base"      => "tech888f_mega_list_image",
    "icon"      => "icon-st",
    "category"      => esc_html__("T888-Elements", 'posolo'),
    "description"   => esc_html__( 'Display list of page', 'posolo' ),
    "params"    => array(
        array(
            "type" => "textfield",
            "admin_label"   => true,
            "heading" => esc_html__("Title",'posolo'),
            "param_name" => "title",
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Style",'posolo'),
            "param_name" => "style",
            "value"         => array(
                esc_html__("Default",'posolo')   => '',
                esc_html__("style2 - Widget Banner",'posolo')   => 'style2',
                esc_html__("style3 - Widget Banner Shop",'posolo')   => 'style3',
            ),
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Custom size",'posolo'),
            'description'   => esc_html__( 'Enter image custom size.Example: 200x200', 'posolo' ),
            "param_name" => "size",
            "value"         => '',
        ),
        array(
            "type" => "param_group",
            "heading" => esc_html__("Add List Item",'posolo'),
            "param_name" => "list_image",
            "params"    => array(
                array(
                    "type" => "dropdown",
                    "heading" => esc_html__("Style",'posolo'),
                    "param_name" => "style",
                    "value"         => array(
                        esc_html__("Default",'posolo')   => '',
                    ),
                ),
                array(
                    "type"          => "attach_image",
                    "heading"       => esc_html__("Image",'posolo'),
                    "param_name"    => "image",
                ),
                array(
                    "type"          => "textfield",
                    "heading"       => esc_html__("Image Title",'posolo'),
                    "param_name"    => "img_title",
                ),
                array(
                    "type"          => "textfield",
                    "heading"       => esc_html__("Image Title 2",'posolo'),
                    "param_name"    => "img_title_2",
                    "dependency"    =>  array(
                        "element"       => "style",
                        "value"         => "style3",
                    ),
                ),
                array(
                    "type"          => "textfield",
                    "heading"       => esc_html__("Image Link",'posolo'),
                    "param_name"    => "url",
                ),
                array(
                    "type" => "textfield",
                    "heading" => esc_html__("Custom class",'posolo'),
                    "param_name" => "custom_class",
                    'description'   => esc_html__( 'Enter element custom class.', 'posolo' ),
                ),
            ),
        ),
        array(
            "type"          => "textfield",
            "heading"       => esc_html__("Extra class name",'posolo'),
            "param_name"    => "el_class",
            'group'         => esc_html__('Design Options','posolo'),
            'description'   => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'posolo' )
        ),
        array(
            "type"          => "css_editor",
            "heading"       => esc_html__("CSS box",'posolo'),
            "param_name"    => "custom_css",
            'group'         => esc_html__('Design Options','posolo')
        ),
    )
));