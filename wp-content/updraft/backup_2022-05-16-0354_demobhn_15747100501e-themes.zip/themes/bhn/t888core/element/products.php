<?php
/**
 * Created by Sublime text 2.
 * User: thanhhiep992
 * Date: 05/09/15
 * Time: 10:00 AM
 */
if(class_exists("woocommerce")){
    if(!function_exists('tech888f_vc_products')){
        function tech888f_vc_products($attr, $content = false){
            $html = $css_class = '';
            $data_array = array_merge(array(
                'style'         => 'grid',
                'title'         => '',
                'des'           => '',
                'number'        => '8',
                'cats'          => '',
                'order_by'      => 'date',
                'order'         => 'DESC',
                'product_type'  => '',
                'column'        => '1',
                'row_number'    => '1',
                'gap'           => '',
                'pagination'    => '',
                'grid_type'     => '',
                'item_style'    => '',
                'item'          => '',
                'item_res'      => '',
                'speed'         => '',
                'slider_navi'   => '',
                'slider_pagi'   => '',
                'size'          => '',
                'animation'     => '',
                'el_class'      => '',
                'custom_css'    => '',
                'custom_ids'    => '',
                'filter_show'   => '',
                'filter_cats'   => '',
                'filter_price'  => 'yes',
                'filter_attr'   => '',
                'filter_style'  => '',
                'filter_column' => 'filter-2-col',
                'filter_pos'    => ''
            ),tech888f_get_responsive_default_atts());
            $attr = shortcode_atts($data_array,$attr);
            extract($attr);
            $css_classes = vc_shortcode_custom_css_class( $custom_css );
            $css_class = preg_replace( '/\s+/', ' ', apply_filters( 'vc_shortcodes_css_class', $css_classes, '', $attr ) );
            
            // Variable process vc_shortcodes_css_class
            if(!empty($css_class)) $el_class .= ' '.$css_class;
            $el_class .= ' product-'.$style.'-view '.$grid_type.' '.$style.' filter-'.$filter_show;
            $paged = (get_query_var('paged') && $style != 'slider') ? get_query_var('paged') : 1;
            $args = array(
                'post_type'         => 'product',
                'posts_per_page'    => $number,
                'orderby'           => $order_by,
                'order'             => $order,
                'paged'             => $paged,
                );
            if($product_type == 'trending'){
                $args['meta_query'][] = array(
                        'key'     => 'trending_product',
                        'value'   => 'on',
                        'compare' => '=',
                    );
            }
            if($product_type == 'toprate'){
                $args['meta_key'] = '_wc_average_rating';
                $args['orderby'] = 'meta_value_num';
                $args['meta_query'] = WC()->query->get_meta_query();
                $args['tax_query'][] = WC()->query->get_tax_query();
            }
            if($product_type == 'mostview'){
                $args['meta_key'] = 'post_views';
                $args['orderby'] = 'meta_value_num';
            }
            if($product_type == 'menu_order'){
                $args['meta_key'] = 'menu_order';
                $args['orderby'] = 'meta_value_num';
            }
            if($product_type == 'bestsell'){
                $args['meta_key'] = 'total_sales';
                $args['orderby'] = 'meta_value_num';
            }
            if($product_type=='onsale'){
                $args['meta_query']['relation']= 'OR';
                $args['meta_query'][]=array(
                    'key'   => '_sale_price',
                    'value' => 0,
                    'compare' => '>',                
                    'type'          => 'numeric'
                );
                $args['meta_query'][]=array(
                    'key'   => '_min_variation_sale_price',
                    'value' => 0,
                    'compare' => '>',                
                    'type'          => 'numeric'
                );
            }
            if($product_type == 'featured'){
                $args['tax_query'][] = array(
                    'taxonomy' => 'product_visibility',
                    'field'    => 'name',
                    'terms'    => 'featured',
                    'operator' => 'IN',
                );
            }
            if(!empty($cats)) {
                $custom_list = explode(",",$cats);
                $args['tax_query'][]=array(
                    'taxonomy'=>'product_cat',
                    'field'=>'slug',
                    'terms'=> $custom_list
                );
            }
            if(!empty($custom_ids)){
                $args['post__in'] = explode(',', $custom_ids);
            }
            $product_query = new WP_Query($args);
            $count = 1;
            $count_query = $product_query->post_count;
            $max_page = $product_query->max_num_pages;
            $size = tech888f_get_size_crop($size);
            if($gap != '') $el_class .= ' '.$gap;
            $attr = array_merge($attr,array(
                'el_class'      => $el_class,
                'product_query' => $product_query,
                'count'         => $count,
                'count_query'   => $count_query,
                'max_page'      => $max_page,
                'args'          => $args,
                'size'          => $size,
            ));
            $html = tech888f_get_template_element('products/'.$style,'',$attr);
            wp_reset_postdata();
            return $html;
        }
    }
stp_reg_shortcode('tech888f_products','tech888f_vc_products');
$check_add = '';
if(isset($_GET['return'])) $check_add = sanitize_text_field($_GET['return']);
if(empty($check_add)) add_action( 'vc_before_init_base','tech888f_add_list_product',10,100 );
if ( ! function_exists( 'tech888f_add_list_product' ) ) {
    function tech888f_add_list_product(){
        $tab_id = 'tech888f_'.uniqid();
        vc_map( array(
            "name"      => esc_html__("Products", 'posolo'),
            "base"      => "tech888f_products",
            "icon"      => "icon-st",
            "category"      => esc_html__("T888-Elements", 'posolo'),
            "description"   => esc_html__( 'Display list of product', 'posolo' ),
            "params"    => array(                
                array(
                    'type'        => 'textfield',
                    "admin_label"   => true,
                    'heading'     => esc_html__( 'Title', 'posolo' ),
                    'param_name'  => 'title',
                ),
                array(
                    'type'        => 'textfield',
                    'heading'     => esc_html__( 'Description', 'posolo' ),
                    'param_name'  => 'des',
                ),
                array(
                    'heading'     => esc_html__( 'Style', 'posolo' ),
                    "admin_label"   => true,
                    'type'        => 'dropdown',
                    'description' => esc_html__( 'Choose style to display.', 'posolo' ),
                    'param_name'  => 'style',
                    'value'       => array(                        
                        esc_html__('Grid','posolo')      => 'grid',
                        esc_html__('Slider','posolo')    => 'slider',
                        ),
                    'edit_field_class'=>'vc_col-sm-6 vc_column',
                ),
                array(
                    'heading'     => esc_html__( 'Number', 'posolo' ),
                    'type'        => 'textfield',
                    'description' => esc_html__( 'Enter number of product. Default is 8.', 'posolo' ),
                    'param_name'  => 'number',
                    'edit_field_class'=>'vc_col-sm-6 vc_column',
                ),
                array(
                    'type'        => 'textfield',
                    'heading'     => esc_html__( 'Custom IDs', 'posolo' ),
                    'param_name'  => 'custom_ids',
                    'description' => esc_html__( 'Enter list ID. Separate values by ",". Example is 12,15,20', 'posolo' ),
                ),
                array(
                    'heading'     => esc_html__( 'Product Type', 'posolo' ),
                    'type'        => 'dropdown',
                    'param_name'  => 'product_type',
                    'value' => array(
                        esc_html__('Default','posolo')            => '',
                        esc_html__('Trending','posolo')          => 'trending',
                        esc_html__('Featured Products','posolo')  => 'featured',
                        esc_html__('Best Sellers','posolo')       => 'bestsell',
                        esc_html__('On Sale','posolo')            => 'onsale',
                        esc_html__('Top rate','posolo')           => 'toprate',
                        esc_html__('Most view','posolo')          => 'mostview',
                        esc_html__('Menu order','posolo')         => 'menu_order',
                    ),
                    'description' => esc_html__( 'Select Product View Type', 'posolo' ),
                ),
                array(
                    'heading'     => esc_html__( 'Product Categories', 'posolo' ),
                    'type'        => 'autocomplete',
                    'param_name'  => 'cats',
                    'settings' => array(
                        'multiple' => true,
                        'sortable' => true,
                        'values' => tech888f_get_list_taxonomy(),
                    ),
                    'save_always' => true,
                    'description' => esc_html__( 'List of product categories', 'posolo' ),
                ),
                array(
                    'type' => 'dropdown',
                    'heading' => esc_html__( 'Order By', 'posolo' ),
                    'value' => tech888f_get_order_list(),
                    'param_name' => 'order_by',
                    'description' => esc_html__( 'Select Orderby Type ', 'posolo' ),
                    'edit_field_class'=>'vc_col-sm-6 vc_column',
                ),
                array(
                    'heading'     => esc_html__( 'Order', 'posolo' ),
                    'type'        => 'dropdown',
                    'param_name'  => 'order',
                    'value' => array(                   
                        esc_html__('Desc','posolo')  => 'DESC',
                        esc_html__('Asc','posolo')  => 'ASC',
                    ),
                    'description' => esc_html__( 'Select Order Type ', 'posolo' ),
                    'edit_field_class'=>'vc_col-sm-6 vc_column',
                ), 
                array(
                    'heading'       => esc_html__( 'Product style', 'posolo' ),
                    'type'          => 'dropdown',
                    'description'   => esc_html__( 'Choose style to display.', 'posolo' ),
                    'param_name'    => 'item_style',
                    'value'         => tech888f_get_product_style(),
                ),
                array(
                    'heading'     => esc_html__( 'Gap products', 'posolo' ),
                    'type'        => 'dropdown',
                    'param_name'  => 'gap',
                    'value' => array(                   
                        esc_html__('Default','posolo')  => '',
                        esc_html__('0px','posolo')   => 'gap-0',
                        esc_html__('5px','posolo')   => 'gap-5',
                        esc_html__('10px','posolo')  => 'gap-10',
                        esc_html__('15px','posolo')  => 'gap-15',
                        esc_html__('20px','posolo')  => 'gap-20',
                        esc_html__('30px','posolo')  => 'gap-30',
                        esc_html__('40px','posolo')  => 'gap-40',
                        esc_html__('50px','posolo')  => 'gap-50',
                    ),
                    'description' => esc_html__( 'Select space for products.', 'posolo' ),
                ),              
                array(
                    'heading'     => esc_html__( 'Grid style', 'posolo' ),
                    'type'        => 'dropdown',
                    'param_name'  => 'grid_type',
                    'value' => array(                   
                        esc_html__('Default','posolo')  => '',
                        esc_html__('Masonry','posolo')  => 'list-masonry',
                    ),
                    'description' => esc_html__( 'Select Column display ', 'posolo' ),
                    "group"         => esc_html__("Grid Settings",'posolo'),
                    "dependency"    =>  array(
                        "element"       => "style",
                        "value"         => "grid",
                    ),
                ),  
                array(
                    'heading'     => esc_html__( 'Column', 'posolo' ),
                    'type'        => 'dropdown',
                    'param_name'  => 'column',
                    'value' => array(                   
                        esc_html__('1 columns','posolo')  => '1',
                        esc_html__('2 columns','posolo')  => '2',
                        esc_html__('3 columns','posolo')  => '3',
                        esc_html__('4 columns','posolo')  => '4',
                        esc_html__('5 columns','posolo')  => '5',
                        esc_html__('6 columns','posolo')  => '6',
                        esc_html__('7 columns','posolo')  => '7',
                        esc_html__('8 columns','posolo')  => '8',
                        esc_html__('9 columns','posolo')  => '9',
                        esc_html__('10 columns','posolo')  => '10',
                    ),
                    'description' => esc_html__( 'Select Column display ', 'posolo' ),
                    "group"         => esc_html__("Grid Settings",'posolo'),
                    "dependency"    =>  array(
                        "element"       => "style",
                        "value"         => "grid",
                    ),
                ),                
                array(
                    "type"          => "dropdown",
                    "heading"       => esc_html__("Pagination",'posolo'),
                    "param_name"    => "pagination",
                    "value"         => array(
                        esc_html__("None",'posolo')                => '',
                        esc_html__("Pagination",'posolo')          => 'pagination',
                        esc_html__("Load more button",'posolo')    => 'load-more',
                        ),
                    'group'         => esc_html__('Grid Settings','posolo'),
                    "dependency"    =>  array(
                        "element"       => "style",
                        "value"         => "grid",
                    ),
                ),              
                array(
                    "type"          => "textfield",
                    "heading"       => esc_html__("Size Thumbnail",'posolo'),
                    "param_name"    => "size",
                    'description'   => esc_html__( 'Enter image size (Example: "thumbnail", "medium", "large", "full" or other sizes defined by theme). Alternatively enter size in pixels (Example: 200x100 (Width x Height), for multi size: 200x100|200x200 separate by "|" or ",").', 'posolo' ),
                ),
                array(
                    'heading'       => esc_html__( 'Thumbnail animation', 'posolo' ),
                    'type'          => 'dropdown',
                    'description'   => esc_html__( 'Choose style to display.', 'posolo' ),
                    'param_name'    => 'animation',
                    'value'         => tech888f_get_product_thumb_animation(),
                ),
                array(
                    "type"          => "textfield",
                    "heading"       => esc_html__("Item",'posolo'),
                    "param_name"    => "item",
                    "group"         => esc_html__("Slider Settings",'posolo'),
                    "dependency"    =>  array(
                        "element"       => "style",
                        "value"         => "slider",
                    ),
                ),
                array(
                    "type"          => "textfield",
                    "heading"       => esc_html__("Item Responsive",'posolo'),
                    "param_name"    => "item_res",
                    "group"         => esc_html__("Slider Settings",'posolo'),
                    'description'   => esc_html__( 'Enter item for screen width(px) format is width:value and separate values by ",". Example is 0:2,600:3,1000:4. Default is auto.', 'posolo' ),
                    "dependency"    =>  array(
                        "element"       => "style",
                        "value"         => "slider",
                    ),
                ),
                array(
                    "type"          => "textfield",
                    "heading"       => esc_html__("Speed",'posolo'),
                    "param_name"    => "speed",
                    "group"         => esc_html__("Slider Settings",'posolo'),
                    'description'   => esc_html__( 'Enter number speed to auto slider (ms). Example is 5000. Default auto is disable.', 'posolo' ),
                    "dependency"    =>  array(
                        "element"       => "style",
                        "value"         => "slider",
                    ),                   
                ),
                array(
                    "type"          => "dropdown",
                    "heading"       => esc_html__("Row / item slider",'posolo'),
                    "param_name"    => "row_number",
                    'value' => array(                   
                        esc_html__('1 row','posolo')  => '1',
                        esc_html__('2 rows','posolo')  => '2',
                        esc_html__('3 rows','posolo')  => '3',
                        esc_html__('4 rows','posolo')  => '4',
                        esc_html__('5 rows','posolo')  => '5',
                        esc_html__('6 rows','posolo')  => '6',
                        esc_html__('7 rows','posolo')  => '7',
                        esc_html__('8 rows','posolo')  => '8',
                        esc_html__('9 rows','posolo')  => '9',
                        esc_html__('10 rows','posolo')  => '10',
                    ),
                    'description'   => esc_html__( 'Choose number row to display', 'posolo' ),
                    "group"         => esc_html__("Slider Settings",'posolo'),
                    "dependency"    =>  array(
                        "element"       => "style",
                        "value"         => "slider",
                    ),  
                ),
                array(
                    'type'        => 'dropdown',
                    'heading'     => esc_html__( 'Navigation', 'posolo' ),
                    'param_name'  => 'slider_navi',
                    'value'       => array(
                        esc_html__( 'Hidden', 'posolo' )                  => '',
                        esc_html__( 'Default Navigation', 'posolo' )      => 'navi-nav-style',
                        esc_html__( 'Group Navigation', 'posolo' )        => 'group-navi',
                    ),
                    "group"         => esc_html__("Slider Settings",'posolo'),
                        "dependency"    =>  array(
                            "element"       => "style",
                            "value"         => "slider",
                        ), 
                ),
                array(
                    'type'        => 'dropdown',
                    'heading'     => esc_html__( 'Pagination', 'posolo' ),
                    'param_name'  => 'slider_pagi',
                    'value'       => array(
                        esc_html__( 'Hidden', 'posolo' )                  => '',
                        esc_html__( 'Default Pagination', 'posolo' )      => 'pagi-nav-style',
                    ),
                    "group"         => esc_html__("Slider Settings",'posolo'),
                        "dependency"    =>  array(
                            "element"       => "style",
                            "value"         => "slider",
                        ), 
                ),
                array(
                    'type'        => 'dropdown',
                    'heading'     => esc_html__( 'Show filter', 'posolo' ),
                    'param_name'  => 'filter_show',
                    'value'       => array(
                        esc_html__( 'No', 'posolo' )          => '',
                        esc_html__( 'Yes', 'posolo' )         => 'yes',
                    ),
                    "group"         => esc_html__("Filter Settings",'posolo'),
                ),
                array(
                    'type'        => 'dropdown',
                    'heading'     => esc_html__( 'Filter position', 'posolo' ),
                    'param_name'  => 'filter_pos',
                    'value'       => array(
                        esc_html__( 'Left', 'posolo' )          => '',
                        esc_html__( 'Right', 'posolo' )         => 'pull-right',
                        esc_html__( 'Center', 'posolo' )        => 'text-center',
                    ),
                    "group"         => esc_html__("Filter Settings",'posolo'),
                    "dependency"    =>  array(
                        "element"       => "filter_show",
                        "value"         => "yes",
                    ), 
                ),
                array(
                    'type'        => 'dropdown',
                    'heading'     => esc_html__( 'Filter style', 'posolo' ),
                    'param_name'  => 'filter_style',
                    'value'       => array(
                        esc_html__( 'Style 1( Horizontal )', 'posolo' )         => '',
                        esc_html__( 'Style 2( Column list inline )', 'posolo' )          => 'filter-col',
                        esc_html__( 'Style 3( Column list )', 'posolo' )          => 'filter-col filter-col-list',
                    ),
                    "group"         => esc_html__("Filter Settings",'posolo'),
                    "dependency"    =>  array(
                        "element"       => "filter_show",
                        "value"         => "yes",
                    ),
                ),
                array(
                    'type'        => 'dropdown',
                    'heading'     => esc_html__( 'Filter column', 'posolo' ),
                    'param_name'  => 'filter_column',
                    'value'       => array(
                        esc_html__( '1 Column', 'posolo' )         => 'filter-1-col',
                        esc_html__( '2 Column', 'posolo' )         => 'filter-2-col',
                        esc_html__( '3 Column', 'posolo' )         => 'filter-3-col',
                        esc_html__( '4 Column', 'posolo' )         => 'filter-4-col',
                    ),
                    "group"         => esc_html__("Filter Settings",'posolo'),
                    "dependency"    =>  array(
                        "element"       => "filter_style",
                        "value"         => array("filter-col","filter-col filter-col-list"),
                    ),
                ),
                array(
                    'heading'       => esc_html__( 'Filter Categories', 'posolo' ),
                    'type'          => 'autocomplete',
                    'param_name'    => 'filter_cats',
                    'settings'      => array(
                        'multiple'      => true,
                        'sortable'      => true,
                        'values'        => tech888f_get_list_taxonomy(),
                    ),
                    'save_always'   => true,
                    'description'   => esc_html__( 'List of product categories', 'posolo' ),
                    "group"         => esc_html__("Filter Settings",'posolo'),
                    "dependency"    =>  array(
                        "element"       => "filter_show",
                        "value"         => "yes",
                    ), 
                ),
                array(
                    'type'        => 'dropdown',
                    'heading'     => esc_html__( 'Filter price', 'posolo' ),
                    'param_name'  => 'filter_price',
                    'value'       => array(
                        esc_html__( 'Yes', 'posolo' )         => 'yes',
                        esc_html__( 'No', 'posolo' )          => '',
                    ),
                    "group"         => esc_html__("Filter Settings",'posolo'),
                    "dependency"    =>  array(
                        "element"       => "filter_show",
                        "value"         => "yes",
                    ),
                ),
                array(
                    "type"          => "checkbox",
                    "heading"       => esc_html__( "Filter attribute", 'posolo' ),
                    "param_name"    => "filter_attr",
                    "value"         => tech888f_get_list_attribute(),
                    "description"   => esc_html__( "Check list attribute to filter", 'posolo' ),
                    "group"         => esc_html__("Filter Settings",'posolo'),
                    "dependency"    =>  array(
                        "element"       => "filter_show",
                        "value"         => "yes",
                    ), 
                ),
                array(
                    "type"          => "textfield",
                    "heading"       => esc_html__("Extra class name",'posolo'),
                    "param_name"    => "el_class",
                    'group'         => esc_html__('Design Options','posolo'),
                    'description'   => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'posolo' )
                ),
                array(
                    "type"          => "css_editor",
                    "heading"       => esc_html__("CSS box",'posolo'),
                    "param_name"    => "custom_css",
                    'group'         => esc_html__('Design Options','posolo')
                ),
            )
        ));
    }
}
}