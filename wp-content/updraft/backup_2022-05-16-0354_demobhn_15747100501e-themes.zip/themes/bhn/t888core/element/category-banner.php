<?php
/**
 * Created by PhpStorm.
 * User: toanngo92
 * Date: 1/4/2019
 * Time: 9:25 AM
 */
if(!function_exists('tech888f_vc_category_banner'))
{
    function tech888f_vc_category_banner($attr, $content = false)
    {
        $html = $icon_html = '';
        $data_array = array_merge(array(
            'display'       => 'grid',
            'style'         => '',
            'title'         => '',
            'des'           => '',
            'list'          => '',
            'column'        => '3',
            'item'          => '',
            'itemres'       => '',
            'speed'         => '',
            'row_number'           => '',
            'size'          => '',
            'el_class'      => '',
            'custom_css'    => '',
            'content'       => $content,
        ),tech888f_get_responsive_default_atts());
        $attr = shortcode_atts($data_array,$attr);
        extract($attr);
        $css_classes = vc_shortcode_custom_css_class( $custom_css );
        $css_class = preg_replace( '/\s+/', ' ', apply_filters( 'vc_shortcodes_css_class', $css_classes, '', $attr ) );

        $size = tech888f_get_size_crop($size,'full');

        // Variable process vc_shortcodes_css_class
        if(!empty($css_class)) $el_class .= ' '.$css_class;
        $el_class .= ' '.$style;

        $data = (array) vc_param_group_parse_atts( $list );
        $default_val = array(
            'image'     => '',
            'title_1'     => '',
            'title_2'     => '',
            'des'       => '',
            'des2'       => '',
            'des3'       => '',
            'link'      => '',
            'custom_class' => '',
        );

        // Add variable to data
        $attr = array_merge($attr,array(
            'el_class'      => $el_class,
            'data'          => $data,
            'default_val'   => $default_val,
            'size'          => $size,
        ));

        // Call function get template

        $html = tech888f_get_template_element('category-banner/category-banner',$style,$attr);

        return  $html;
    }
}

stp_reg_shortcode('sv_category_banner','tech888f_vc_category_banner');
$check_add = '';
if(isset($_GET['return'])) $check_add = $_GET['return'];
if(empty($check_add)) add_action( 'vc_before_init_base','tech888f_add_list_introduce_category',10,100 );
if(! function_exists('tech888f_add_list_introduce_category')){
    function tech888f_add_list_introduce_category(){
        vc_map( array(
            "name"          => esc_html__("Introduce Category", 'posolo'),
            "base"          => "sv_category_banner",
            "icon"          => "icon-st",
            "category"      => esc_html__("T888-Elements", 'posolo'),
            "description"   => esc_html__( 'Display Introduce Category', 'posolo' ),
            "params"        => array(
                array(
                    "type"          => "dropdown",
                    "admin_label"   => true,
                    "heading"       => esc_html__("Display",'posolo'),
                    "param_name"    => "display",
                    "std"           => "grid",
                    "value"         => array(
                        esc_html__("Grid",'posolo')    => 'grid',
                    ),
                    "description"   => esc_html__( 'Choose a style to display.', 'posolo' )
                ),
                array(
                    "type"          => "dropdown",
                    "admin_label"   => true,
                    "heading"       => esc_html__("Style",'posolo'),
                    "param_name"    => "style",
                    "value"         => array(
                        esc_html__("Default",'posolo')    => '',
                    ),
                    "description"   => esc_html__( 'Choose a style to display.', 'posolo' )
                ),
                array(
                    "type"          => "textfield",
                    "admin_label"   => true,
                    "heading"       => esc_html__("Title",'posolo'),
                    "param_name"    => "title",
                    "description"   => esc_html__( 'Enter title of element.', 'posolo' )
                ),
                array(
                    "admin_label"   => true,
                    "type"          => "textfield",
                    "heading"       => esc_html__("Description",'posolo'),
                    "param_name"    => "des",
                    "description"   => esc_html__( 'Enter description of element.', 'posolo' )
                ),
                array(
                    "type"          => "textfield",
                    "heading"       => esc_html__("Image custom size",'posolo'),
                    "param_name"    => "size",
                    'description'   => esc_html__( 'Enter image size (Example: "thumbnail", "medium", "large", "full" or other sizes defined by theme). Alternatively enter size in pixels (Example: 200x100 (Width x Height)).', 'posolo' ),
                ),
                array(
                    'heading'       => esc_html__( 'Item', 'posolo' ),
                    'type'          => 'textfield',
                    'param_name'    => 'item',
                    'group'         => esc_html__("Slider Settings","posolo"),
                    "dependency"    =>  array(
                        "element"       => "display",
                        "value"         => "slider",
                    ),
                ),
                array(
                    'heading'       => esc_html__( 'Custom Item', 'posolo' ),
                    'type'          => 'textfield',
                    'description'   => esc_html__( 'Enter item for screen width(px) format is width:value and separate values by ",". Example is 0:2,600:3,1000:4. Default is auto.', 'posolo' ),
                    'param_name'    => 'itemres',
                    'group'         => esc_html__("Slider Settings","posolo"),
                    "dependency"    =>  array(
                        "element"       => "display",
                        "value"         => "slider",
                    ),
                ),
                array(
                    'heading'       => esc_html__( 'Speed', 'posolo' ),
                    'type'          => 'textfield',
                    'group'         => esc_html__("Slider Settings","posolo"),
                    'description'   => esc_html__( 'Enter time slider go to next item. Unit (ms). Example 5000. If empty this field autoPlay is false.', 'posolo' ),
                    'param_name'    => 'speed',
                    "dependency"    =>  array(
                        "element"       => "display",
                        "value"         => "slider",
                    ),
                ),
                array(
                    "type"          => "dropdown",
                    "heading"       => esc_html__("Row / item slider",'posolo'),
                    "param_name"    => "row_number",
                    'value' => array(
                        esc_html__('1 row','posolo')  => '1',
                        esc_html__('2 rows','posolo')  => '2',
                        esc_html__('3 rows','posolo')  => '3',
                        esc_html__('4 rows','posolo')  => '4',
                        esc_html__('5 rows','posolo')  => '5',
                        esc_html__('6 rows','posolo')  => '6',
                        esc_html__('7 rows','posolo')  => '7',
                        esc_html__('8 rows','posolo')  => '8',
                        esc_html__('9 rows','posolo')  => '9',
                        esc_html__('10 rows','posolo')  => '10',
                    ),
                    'description'   => esc_html__( 'Choose number row to display', 'posolo' ),
                    "group"         => esc_html__("Slider Settings",'posolo'),
                    "dependency"    =>  array(
                        "element"       => "display",
                        "value"         => "slider",
                    ),
                ),
                array(
                    'heading'     => esc_html__( 'Column', 'posolo' ),
                    'type'        => 'dropdown',
                    'param_name'  => 'column',
                    'value' => array(
                        esc_html__('Default','posolo')  => '3',
                        esc_html__('1 column','posolo')  => '1',
                        esc_html__('2 columns','posolo')  => '2',
                        esc_html__('3 columns','posolo')  => '3',
                        esc_html__('4 columns','posolo')  => '4',
                        esc_html__('5 columns','posolo')  => '5',
                        esc_html__('6 columns','posolo')  => '6',
                    ),
                    'description' => esc_html__( 'Select Column display ', 'posolo' ),
                    "group"         => esc_html__("Grid Settings",'posolo'),
                    "dependency"    =>  array(
                        "element"       => "display",
                        "value"         => "grid",
                    ),
                ),
                array(
                    "type"          => "param_group",
                    "heading"       => esc_html__("Add Category List",'posolo'),
                    "param_name"    => "list",
                    "params"        => array(
                        array(
                            "type"          => "attach_image",
                            "heading"       => esc_html__("Image",'posolo'),
                            "param_name"    => "image",
                        ),
                        array(
                            "type"          => "textfield",
                            "heading"       => esc_html__("Title Line 1",'posolo'),
                            "param_name"    => "title_1",
                        ),
                        array(
                            "type"          => "textfield",
                            "heading"       => esc_html__("Title Line 2",'posolo'),
                            "param_name"    => "title_2",
                        ),
                        array(
                            "type"          => "textfield",
                            "heading"       => esc_html__("Description line 1",'posolo'),
                            "param_name"    => "des",
                        ),
                        array(
                            "type"          => "textfield",
                            "heading"       => esc_html__("Description line 2",'posolo'),
                            "param_name"    => "des2",
                        ),
                        array(
                            "type"          => "textfield",
                            "heading"       => esc_html__("Description line 3",'posolo'),
                            "param_name"    => "des3",
                        ),
                        array(
                            "type"          => "textfield",
                            "heading"       => esc_html__("Custom Link",'posolo'),
                            "param_name"    => "link",
                        ),
                        array(
                            "type"          => "textfield",
                            "heading"       => esc_html__("Custom Class",'posolo'),
                            "param_name"    => "custom_class",
                        ),
                    ),
                    'description'   => esc_html__( 'Add more image with link', 'posolo' ),
                ),
                array(
                    "type"          => "textfield",
                    "heading"       => esc_html__("Extra class name",'posolo'),
                    "param_name"    => "el_class",
                    'group'         => esc_html__('Design Options','posolo'),
                    'description'   => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'posolo' )
                ),
                array(
                    "type"          => "css_editor",
                    "heading"       => esc_html__("CSS box",'posolo'),
                    "param_name"    => "custom_css",
                    'group'         => esc_html__('Design Options','posolo')
                ),
            )
        ));
    }
}
