<?php
/**
 * Created by Sublime text 2.
 * User: thanhhiep992
 * Date: 26/10/17
 * Time: 10:00 AM
 */

if(!function_exists('tech888f_vc_advertisement'))
{
    function tech888f_vc_advertisement($attr,$content = false)
    {
        $html = $css_class = $css_class2 = '';
        $data_array = array_merge(array(
            'style'         => '',
            'image'         => '',
            'image2'        => '',
            'link'          => '',
            'animation'     => '',
            'el_class'      => '',
            'el_class2'     => '',
            'custom_css'    => '',
            'custom_css2'   => '',
            'size'          => '',
            'content'       => $content,
        ),tech888f_get_responsive_default_atts());
        $attr = shortcode_atts($data_array,$attr);
        extract($attr);
        $css_classes = vc_shortcode_custom_css_class( $custom_css );
        $css_class = preg_replace( '/\s+/', ' ', apply_filters( 'vc_shortcodes_css_class', $css_classes, '', $attr ) );
        
        // Variable process vc_shortcodes_css_class
        if(!empty($css_class)) $el_class .= ' '.$css_class;
        
        $el_class .= ' '.$style.' '.$animation;
        if(!empty($custom_css2)) $el_class2 .= ' '.vc_shortcode_custom_css_class( $custom_css2 );
        if(!empty($size)) $size = explode('x', $size);
        else $size = 'full';
        $attr = array_merge($attr,array(
            'el_class'  => $el_class,
            'el_class2' => $el_class2,
            'size'      => $size,
            ));

        $html = tech888f_get_template_element('advertisement/advertisement',$style,$attr);

        return $html;
    }
}

stp_reg_shortcode('tech888f_advertisement','tech888f_vc_advertisement');

vc_map( array(
    "name"          => esc_html__("Advertisement", 'posolo'),
    "base"          => "tech888f_advertisement",
    "icon"          => "icon-st",
    "category"      => esc_html__("T888-Elements", 'posolo'),
    "description"   => esc_html__( 'Display a advertisement', 'posolo' ),
    "params"        => array(        
        array(
            "type"          => "textarea_html",
            "holder"        => "div",
            "heading"       => esc_html__("Content Info",'posolo'),
            "param_name"    => "content",
            "description"   => esc_html__( 'Enter info content of element.', 'posolo' )
        ),
        array(
            "type"          => "dropdown",
            "admin_label"   => true,
            "heading"       => esc_html__("Style",'posolo'),
            "param_name"    => "style",
            "value"         => array(
                esc_html__("Default",'posolo')   => '',
                esc_html__("About",'posolo')   => 'about',
            ),
            "description"   => esc_html__( 'Choose menu style to display.', 'posolo' )
        ),
        array(
            "type"          => "attach_image",
            "admin_label"   => true,
            "heading"       => esc_html__("Image",'posolo'),
            "param_name"    => "image",
            "description"   => esc_html__( 'Select image from media library.', 'posolo' )
        ),
        array(
            "type"          => "textfield",
            "heading"       => esc_html__("Link",'posolo'),
            "param_name"    => "link",
            "description"   => esc_html__( 'Enter URL redirect when click to image.', 'posolo' )
        ),
        array(
            "type"          => "dropdown",
            "heading"       => esc_html__("Animation",'posolo'),
            "param_name"    => "animation",
            "value"         => array(
                esc_html__("Default",'posolo')                    => '',
                esc_html__("Zoom",'posolo')                       => 'zoom-image',
                esc_html__("Zoom out",'posolo')                   => 'zoom-out',
                esc_html__("Zoom out Overlay",'posolo')           => 'zoom-out overlay-image',
                esc_html__("Fade out-in",'posolo')                => 'fade-out-in',
                esc_html__("Zoom Fade out-in",'posolo')           => 'zoom-image fade-out-in',
                esc_html__("Fade in-out",'posolo')                => 'fade-in-out',
                esc_html__("Zoom rotate",'posolo')                => 'zoom-rotate',
                esc_html__("Zoom rotate Fade out-in",'posolo')    => 'zoom-rotate fade-out-in',
                esc_html__("Overlay",'posolo')                    => 'overlay-image',
                esc_html__("Overlay Zoom",'posolo')               => 'overlay-image zoom-image',
                esc_html__("Zoom image line",'posolo')            => 'zoom-image line-scale',
                esc_html__("Gray image",'posolo')                 => 'gray-image',
                esc_html__("Gray image line",'posolo')            => 'gray-image line-scale',
                esc_html__("Pull curtain",'posolo')               => 'pull-curtain',
                esc_html__("Pull curtain gray image",'posolo')    => 'pull-curtain gray-image',
                esc_html__("Pull curtain zoom image",'posolo')    => 'pull-curtain zoom-image',
            ),
            "description"   => esc_html__( 'Select type of animation for image.', 'posolo' )
        ),
        array(
            "type"          => "attach_image",
            "heading"       => esc_html__("Image fade",'posolo'),
            "param_name"    => "image2",
            "dependency"    => array(
                "element"       => "animation",
                "value"     => array("zoom-out","zoom-out overlay-image"),
            ),
            "description"   => esc_html__( 'Select image from media library.', 'posolo' )
        ),
        array(
            "type"          => "textfield",
            "heading"       => esc_html__("Image custom size",'posolo'),
            "param_name"    => "size",
            'description'   => esc_html__( 'Enter image size (Example: "thumbnail", "medium", "large", "full" or other sizes defined by theme). Alternatively enter size in pixels (Example: 200x100 (Width x Height)).', 'posolo' ),
        ),
        array(
            "type"          => "textfield",
            "heading"       => esc_html__("Extra class name",'posolo'),
            "param_name"    => "el_class",
            'group'         => esc_html__('Design Options','posolo'),
            'description'   => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'posolo' )
        ),
        array(
            "type"          => "css_editor",
            "heading"       => esc_html__("CSS box",'posolo'),
            "param_name"    => "custom_css",
            'group'         => esc_html__('Design Options','posolo')
        ),
        array(
            "type"          => "textfield",
            "heading"       => esc_html__("Extra class name",'posolo'),
            "param_name"    => "el_class2",
            'group'         => esc_html__('Design Info Box','posolo'),
            'description'   => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'posolo' )
        ),
        array(
            "type"          => "css_editor",
            "heading"       => esc_html__("CSS box",'posolo'),
            "param_name"    => "custom_css2",
            'group'         => esc_html__('Design Info Box','posolo')
        ),
    )
));