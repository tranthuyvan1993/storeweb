<?php
/**
 * Created by Sublime text 2.
 * User: thanhhiep992
 * Date: 26/10/17
 * Time: 10:00 AM
 */
if(!function_exists('tech888f_vc_customer_reviews'))
{
    function tech888f_vc_customer_reviews($attr, $content = false)
    {
        $html = $icon_html = '';
        $data_array = array_merge(array(
            'style'         => 'default',
            'title'         => '',
            'des'           => '',
            'name'           => '',
            'list'          => '',
            'el_class'      => '',
            'custom_css'    => '',
            'content'       => $content,
        ),tech888f_get_responsive_default_atts());
        $attr = shortcode_atts($data_array,$attr);
        extract($attr);
        $css_classes = vc_shortcode_custom_css_class( $custom_css );
        $css_class = preg_replace( '/\s+/', ' ', apply_filters( 'vc_shortcodes_css_class', $css_classes, '', $attr ) );

        $size = tech888f_get_size_crop($size,'full');

        // Variable process vc_shortcodes_css_class
        if(!empty($css_class)) $el_class .= ' '.$css_class;
        $el_class .= ' '.$style;

        $data = (array) vc_param_group_parse_atts( $list );
        $default_val = array(
            'title'     => '',
            'des'       => '',
            'image'     => '',
            'link_fb'     => '#',
            'link_yt'     => '#',
            'link_insta'     => '#',
        );

        // Add variable to data
        $attr = array_merge($attr,array(
            'el_class'      => $el_class,
            'data'          => $data,
            'default_val'   => $default_val,
            'size'          => $size,
        ));

        // Call function get template
        $html = tech888f_get_template_element('list-staff/list',$style,$attr);

        return  $html;
    }
}

stp_reg_shortcode('customer_reviews','tech888f_vc_customer_reviews');

vc_map( array(
    "name"          => esc_html__("Danh sách Nhân sự", 'posolo'),
    "base"          => "customer_reviews",
    "icon"          => "icon-st",
    "category"      => esc_html__("T888-Elements", 'posolo'),
    "description"   => esc_html__( 'Display list images ', 'posolo' ),
    "params"        => array(
        array(
            "type"          => "dropdown",
            "admin_label"   => true,
            "heading"       => esc_html__("Style",'posolo'),
            "param_name"    => "style",
            "value"         => array(
                esc_html__("Default",'posolo')    => 'default',
                esc_html__("style 2",'posolo')    => 'style2',
                esc_html__("style 3",'posolo')    => 'style3',
            ),
            "description"   => esc_html__( 'Choose a style to display.', 'posolo' )
        ),
        array(
            "type"          => "param_group",
            "heading"       => esc_html__("Add Image List",'posolo'),
            "param_name"    => "list",
            "params"        => array(
                array(
                    "type"          => "textfield",
                    "heading"       => esc_html__("Title",'posolo'),
                    "param_name"    => "title",
                ),
                array(
                    "type"          => "textfield",
                    "heading"       => esc_html__("Description",'posolo'),
                    "param_name"    => "des",
                ),
                array(
                    "type"          => "attach_image",
                    "heading"       => esc_html__("Image",'posolo'),
                    "param_name"    => "image",
                ),
                array(
                    "type"          => "textfield",
                    "heading"       => esc_html__("Link Facebook",'posolo'),
                    "param_name"    => "link_fb",
                ),
                array(
                    "type"          => "textfield",
                    "heading"       => esc_html__("Link Youtube",'posolo'),
                    "param_name"    => "link_yt",
                ),
                array(
                    "type"          => "textfield",
                    "heading"       => esc_html__("Link Insta",'posolo'),
                    "param_name"    => "link_insta",
                ),
            ),
            'description'   => esc_html__( 'Add more image with link', 'posolo' ),
        ),
        array(
            "type"          => "textfield",
            "heading"       => esc_html__("Extra class name",'posolo'),
            "param_name"    => "el_class",
            'group'         => esc_html__('Design Options','posolo'),
            'description'   => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'posolo' )
        ),
        array(
            "type"          => "css_editor",
            "heading"       => esc_html__("CSS box",'posolo'),
            "param_name"    => "custom_css",
            'group'         => esc_html__('Design Options','posolo')
        ),
    )
));