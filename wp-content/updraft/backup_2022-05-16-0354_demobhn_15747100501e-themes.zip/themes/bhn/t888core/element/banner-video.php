<?php
/**
 * User: vinh
 * Date: 2018
 */

if(!function_exists('tech888f_vc_banner_video'))
{
    function tech888f_vc_banner_video($attr , $content = false)
    {
        $html = $settings = '';
        extract(shortcode_atts(array(
            'style'         => '',
            'poster'        => '',
            'size'          => '',
            'video_link'    => '',
            'loop'          => 'loop',
            'audio'         => 'muted',
            'autoplay'      => 'autoplay',
            'link'          => '',
            'info_animation'    => '',
            'info_align'        => '',
        ),$attr));

        if(!empty($size)) $size = explode('x', $size);
        else $size = 'full';
        if(!empty($poster)) $settings .= 'poster="'.wp_get_attachment_image_url($poster,$size).'"';
        if($loop != 'no') $settings .= ' '.$loop;
        if($audio != 'no') $settings .= ' '.$audio;
        if($autoplay != 'no') $settings .= ' '.$autoplay;


        switch ($style) {
            case 'style2':
                $html .=    '<div class="banner-video '.esc_attr($style).'">
                                <a class="video-button" href="'.esc_url("#").'" title="'.esc_attr__('Play', 'posolo' ).'">
                                    <i class="li li-play-circle"></i>
                                </a>
                                <video '.$settings.' oncontextmenu="return false;" class="video-play">
                                    <source src="'.esc_url($video_link).'" type="video/mp4">
                                </video>
                            </div>';
                break;
            default:
                $html .=    '<div class="banner-video '.esc_attr($style).'">
                                <a class="video-button" href="'.esc_url("#").'" title="'.esc_attr__('Play', 'posolo' ).'">
                                    <i class="fa fa-play-circle-o"></i>
                                </a>
                                <video '.$settings.' oncontextmenu="return false;" class="video-play">
                                    <source src="'.esc_url($video_link).'" type="video/mp4">
                                </video>
                            </div>';

                break;
        }
        return $html;
    }
}

stp_reg_shortcode('tech888f_banner_video','tech888f_vc_banner_video');

vc_map( array(
    "name"      => esc_html__("Banner Video", 'posolo'),
    "base"      => "tech888f_banner_video",
    "icon"      => "icon-st",
    "description"   => esc_html__( 'Display video background', 'posolo' ),
    "category"  => esc_html__("T888-Elements", 'posolo'),
    "params"    => array(
        array(
            'type'        => 'dropdown',
            'heading'     => esc_html__( 'Style', 'posolo' ),
            'param_name'  => 'style',
            'value'       => array(
                esc_html__( 'Default', 'posolo' )      => '',
                esc_html__( 'full width', 'posolo' )      => 'style2'
            ),
        ),
        array(
            "type" => "attach_image",
            "heading" => esc_html__("Image video preview",'posolo'),
            "param_name" => "poster",
        ),
        array(
            "type"          => "textfield",
            "heading"       => esc_html__("Image video preview custom size",'posolo'),
            "param_name"    => "size",
            'description'   => esc_html__( 'Enter image size (Example: "thumbnail", "medium", "large", "full" or other sizes defined by theme). Alternatively enter size in pixels (Example: 200x100 (Width x Height)).', 'posolo' ),
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Video source",'posolo'),
            "param_name" => "video_link",
            "description" => esc_html__( "Enter video source.", 'posolo' ),
        ),
        array(
            "type" => "textfield",
            "heading" => esc_html__("Redirect Link",'posolo'),
            "param_name" => "link",
        ),
        array(
            'type'        => 'dropdown',
            'heading'     => esc_html__( 'Loop', 'posolo' ),
            'param_name'  => 'loop',
            'value'       => array(
                esc_html__( 'Yes', 'posolo' )                  => 'loop',
                esc_html__( 'No', 'posolo' )                  => 'no',
            ),
        ),
        array(
            'type'        => 'dropdown',
            'heading'     => esc_html__( 'Audio', 'posolo' ),
            'param_name'  => 'loop',
            'value'       => array(
                esc_html__( 'No', 'posolo' )                  => 'muted',
                esc_html__( 'Yes', 'posolo' )                  => 'no',
            ),
        ),
        array(
            'type'        => 'dropdown',
            'heading'     => esc_html__( 'Autoplay', 'posolo' ),
            'param_name'  => 'autoplay',
            'value'       => array(
                esc_html__( 'Yes', 'posolo' )                  => 'autoplay',
                esc_html__( 'No', 'posolo' )                  => 'no',
            ),
        ),
        array(
            "type" => "textarea_html",
            "holder" => "div",
            "heading" => esc_html__("Content",'posolo'),
            "param_name" => "content",
            "dependency"    => array(
                "element"       => "style",
                "value"     => array("style-content"),
            ),
        ),
        array(
            'type'          => 'animation_style',
            'heading'       => esc_html__( 'Info Animation', 'posolo' ),
            'param_name'    => 'info_animation',
            'admin_label'   => true,
            'value'         => '',
            'settings'      => array(
                'type'          => 'in',
                'custom'        =>  array(
                    array(
                        'label'     => esc_html__( 'Default', 'posolo' ),
                        'values'    => array(
                            esc_html__( 'Top to bottom', 'posolo' ) => 'top-to-bottom',
                            esc_html__( 'Bottom to top', 'posolo' ) => 'bottom-to-top',
                            esc_html__( 'Left to right', 'posolo' ) => 'left-to-right',
                            esc_html__( 'Right to left', 'posolo' ) => 'right-to-left',
                            esc_html__( 'Appear from center', 'posolo' ) => 'appear',
                        ),
                    ),
                ),
            ),
            'description' => esc_html__( 'Select type of animation for element to be animated when it enters the browsers viewport (Note: works only in modern browsers).', 'posolo' ),
            "dependency"    => array(
                "element"       => "style",
                "value"     => array("style-content"),
            ),
        )
    )
));

