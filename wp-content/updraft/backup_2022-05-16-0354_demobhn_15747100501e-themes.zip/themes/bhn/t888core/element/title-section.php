<?php
/**
 * Created by Sublime text 2.
 * User: thanhhiep992
 * Date: 15/12/15
 * Time: 10:00 AM
 */

if(!function_exists('sv_vc_title'))
{
    function sv_vc_title($attr)
    {
        $html = '';
        extract(shortcode_atts(array(
            'title'      => '',
            'des'      => '',
            'style'    => '',
        ),$attr));

        switch ($style){
            case "":
                $html .=    '<div class="box-title text-center pst-relative">';
                if(!empty($title)) $html .=        '<h2 class="no-margin no-margin title48 fontphilo font-normal  blackmain">'.$title.'</h2>';
                if(!empty($des)) $html .=        '<span class="desc-title color3 font-bold text-uppercase">'.$des.'</span>';
                $html .=    '</div>';
                return $html;
                break;
            case "style2":
                $html .=    '<div class="box-title style2 pst-relative">';
                if(!empty($des)) $html .=        '<span class="desc-title blackmain font-bold text-uppercase">'.$des.'</span>';
                if(!empty($title)) $html .=        '<h2 class="no-margin no-margin title72 fontphilo font-normal  blackmain">'.$title.'</h2>';
                $html .=    '</div>';
                return $html;
                break;
            case "style3":
                $html .=    '<div class="box-title style3 pst-relative">';
                if(!empty($des)) $html .=        '<span class="desc-title color font-bold text-uppercase">'.$des.'</span>';
                if(!empty($title)) $html .=        '<h2 class="no-margin no-margin title45 fontphilo font-normal  blackmain">'.$title.'</h2>';
                $html .=    '</div>';
                return $html;
                break;
            case "style4":
                $html .=    '<div class="box-title style4 text-center pst-relative">';
                if(!empty($title)) $html .=        '<h2 class="no-margin no-margin title48 fontphilo font-normal  blackmain">'.$title.'</h2>';
                if(!empty($des)) $html .=        '<span class="desc-title color3 font-bold text-uppercase">'.$des.'</span>';
                $html .=    '</div>';
                return $html;
                break;
        }
    }
}

stp_reg_shortcode('sv_title','sv_vc_title');

vc_map( array(
    "name"      => esc_html__("Title Box", 'posolo'),
    "base"      => "sv_title",
    "icon"      => "icon-st",
    "category"  => 'T888-Elements',
    "params"    => array(
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Style",'posolo'),
            "param_name" => "style",
            "value"   => array(
                esc_html__("Default","posolo") => "",
                esc_html__("Style 2","posolo") => "style2",
                esc_html__("Style 3","posolo") => "style3",
                esc_html__("Style 4","posolo") => "style4",
            )
        ),
        array(
            "type" => "textfield",
            "holder" => "div",
            "heading" => esc_html__("Title",'posolo'),
            "param_name" => "title",
        ),
        array(
            "type" => "textfield",
            "holder" => "div",
            "heading" => esc_html__("Description",'posolo'),
            "param_name" => "des",
        )
    )
));