<?php
/**
 * Created by PhpStorm.
 * User: windear
 * Date: 11/13/2018
 * Time: 10:10 AM
 */

if(!function_exists('tech888f_vc_progess_bar')){
    function tech888f_vc_progess_bar($attr){
        $html = $css_class = '';
        $data_array = array_merge(array(
            'style'         => '',
            'title'         => '',
            'pb_values'        => '',
            'el_class'      => '',
            'custom_css'    => '',
        ),tech888f_get_responsive_default_atts());
        $attr = shortcode_atts($data_array,$attr);
        extract($attr);
        $css_classes = vc_shortcode_custom_css_class( $custom_css );
        $css_class = preg_replace( '/\s+/', ' ', apply_filters( 'vc_shortcodes_css_class', $css_classes, '', $attr ) );

        // Variable process vc_shortcodes_css_class
        if(!empty($css_class)) $el_class .= ' '.$css_class;
        if(!empty($style)) $el_class .= ' '.$style;

        $data = (array) vc_param_group_parse_atts( $pb_values );
        $default_val = array(
            'label'      => '',
            'value'      => '',
            'color'      => '',
            'bgcolor'    => '',
        );
        // Add variable to data
        $attr = array_merge($attr,array(
            'el_class' => $el_class,
            'data'          => $data,
            'default_val'   => $default_val,
        ));

        // Call function get template
        $html = tech888f_get_template_element('progess-bar/progess-bar',$style,$attr);

        return $html;
    }
}

stp_reg_shortcode('tech888f_progess_bar','tech888f_vc_progess_bar');

vc_map( array(
    "name"      => esc_html__("Progess bar", 'posolo'),
    "base"      => "tech888f_progess_bar",
    "icon"      => "icon-st",
    "category"      => esc_html__("T888-Elements", 'posolo'),
    "description"   => esc_html__( 'Display a progess bar', 'posolo' ),
    "params"    => array(
        array(
            "type"          => "dropdown",
            "admin_label"   => true,
            "heading"       => esc_html__("Style",'posolo'),
            "param_name"    => "style",
            "value"         => array(
                esc_html__("Default",'posolo')     => '',
            ),
            "description"   => esc_html__( 'Choose style to display.', 'posolo' )
        ),
        array(
            "type"          => "textfield",
            "admin_label"   => true,
            "heading"       => esc_html__("Title",'posolo'),
            "param_name"    => "title",
            "description"   => esc_html__( 'Enter title of progessbar.', 'posolo' )
        ),
        array(
            "type"          => "param_group",
            "heading"       => esc_html__("Progess Bar Values",'posolo'),
            "param_name"    => "pb_values",
            "params"        => array(
                array(
                    "type"          => "textfield",
                    "heading"       => esc_html__("Label",'posolo'),
                    "param_name"    => "label",
                    "description"   => esc_html__( 'Enter text used as title of bar.', 'posolo' )
                ),
                array(
                    "type"          => "textfield",
                    "heading"       => esc_html__("Value",'posolo'),
                    "param_name"    => "value",
                    "description"   => esc_html__( 'Enter value of bar.', 'posolo' )
                ),
                array(
                    'type'          => 'colorpicker',
                    'heading'       => esc_html__( 'Color', 'posolo' ),
                    'param_name'    => 'color',
                    'value'         => '#e7b622',
                    'description'   => esc_html__( 'Enter color of single bar.', 'posolo' ),
                ),
                array(
                    'type'          => 'colorpicker',
                    'heading'       => esc_html__( 'Color', 'posolo' ),
                    'param_name'    => 'bgcolor',
                    'value'         => '#cacaca',
                    'description'   => esc_html__( 'Enter Background color of single bar.', 'posolo' ),
                ),
            )
        ),
        array(
            "type"          => "textfield",
            "heading"       => esc_html__("Extra class name",'posolo'),
            "param_name"    => "el_class",
            'group'         => esc_html__('Design Options','posolo'),
            'description'   => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'posolo' )
        ),
        array(
            "type"          => "css_editor",
            "heading"       => esc_html__("CSS box",'posolo'),
            "param_name"    => "custom_css",
            'group'         => esc_html__('Design Options','posolo')
        ),
    )
));