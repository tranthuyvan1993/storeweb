(function ($) {
    /**
     * @param $scope The Widget wrapper element as a jQuery element
     * @param $ The jQuery alias
     */

    function hiddenFix(animation, self) {
        self.find('.swiper-slide-contents').css("display", "none");
    }

    function callAnimation(animation, self) {
        if (animation != '') {
            self.find('.swiper-slide-contents').css("display", "block");
            self.find('.swiper-slide-contents').removeClass(animation);
            self.find('.swiper-slide-contents').removeClass('animated');
            self.find('.swiper-slide-active .swiper-slide-contents').addClass('animated ' + animation);
        }
    }

    function customize_swiper_slider($scope) {
        // get unique uid for slider
        const uid = Date.now().toString(36) + Math.random().toString(36).substr(2);
        var _self = $scope.find('.extends-module-slider .swiper-container');
        var classAdd = 'custom-swiper_' + uid;
        var classCall = '.' + classAdd;
        _self.addClass(classAdd);

        /* swiper option */
        var delay = (_self.attr('data-speed') != '') ? _self.attr('data-speed') : '';
        var autoplay = (_self.attr('data-autoplay') === 'yes') ? true : false;
        if (autoplay == true) {
            var pause_on_hover = (_self.attr('data-pause-on-hover') === 'yes') ? true : false;
            var pause_on_interaction = (_self.attr('data-pause-on-interaction') === 'yes') ? true : false;
            if (delay != '') autoplay = {
                delay: delay,
                pauseOnMouseEnter: pause_on_hover,
                disableOnInteraction: pause_on_interaction
            }
        }

        var speed = (_self.attr('data-transition-speed') != '') ? parseInt(_self.attr('data-transition-speed')) : '';

        var navigation = (_self.attr('data-arrows') == 'arrows' || _self.attr('data-arrows') != 'both') ? {
            nextEl: '.elementor-swiper-button-next',
            prevEl: '.elementor-swiper-button-prev',
        } : false;

        var pagination = (_self.attr('data-dots') == 'dots' || _self.attr('data-dots') != 'both') ? {
            el: '.swiper-pagination',
            type: 'bullets',
            clickable: true
        } : false;

        var effect = (_self.attr('data-effect') != '') ? _self.attr('data-effect') : 'slide';

        var animation = (_self.attr('data-animation') != '') ? _self.attr('data-animation') : '';

        var loop = (_self.attr('data-infinite') === 'yes') ? true : false;

        var slidesPerView = (_self.attr('data-item-desktop') != '') ? parseInt(_self.attr('data-item-desktop')) : 1;
        var slidesPerViewTablet = (_self.attr('data-item-tablet') != '') ? parseInt(_self.attr('data-item-tablet')) : 1;
        var slidesPerViewMobile = (_self.attr('data-item-mobile') != '') ? parseInt(_self.attr('data-item-mobile')) : 1;

        var options_swiper = {
            autoplay: autoplay,
            speed: speed,
            slidesPerView: slidesPerView,
            loop: loop,
            navigation: navigation,
            pagination: pagination,
            effect: effect,

            breakpoints: {
                // when window width is >= 0px
                0: {
                    slidesPerView: 1,
                    loop: loop,
                    navigation: navigation,
                    pagination: pagination,
                    //spaceBetween: 20
                },
                320: {
                    slidesPerView: slidesPerViewMobile,
                    loop: loop,
                    navigation: navigation,
                    pagination: pagination,
                    //    spaceBetween: 20
                },
                // when window width is >= 768px
                768: {
                    slidesPerView: slidesPerViewTablet,
                    loop: loop,
                    navigation: navigation,
                    pagination: pagination,
                    //    spaceBetween: 15
                },
                // when window width is >= 1024px
                1024: {
                    slidesPerView: slidesPerView,
                    loop: loop,
                    navigation: navigation,
                    pagination: pagination,
                    //     spaceBetween: 30
                }
            }
        }

        var swiper = new Swiper(classCall, {
            autoplay: autoplay,
            speed: speed,
            slidesPerView: slidesPerView,
            loop: loop,
            navigation: navigation,
            pagination: pagination,
            effect: effect,

            breakpoints: {
                // when window width is >= 0px
                0: {
                    slidesPerView: 1,
                    loop: loop,
                    navigation: navigation,
                    pagination: pagination,
                    //spaceBetween: 20
                },
                320: {
                    slidesPerView: slidesPerViewMobile,
                    loop: loop,
                    navigation: navigation,
                    pagination: pagination,
                    //    spaceBetween: 20
                },
                // when window width is >= 768px
                768: {
                    slidesPerView: slidesPerViewTablet,
                    loop: loop,
                    navigation: navigation,
                    pagination: pagination,
                    //    spaceBetween: 15
                },
                // when window width is >= 1024px
                1024: {
                    slidesPerView: slidesPerView,
                    loop: loop,
                    navigation: navigation,
                    pagination: pagination,
                    //     spaceBetween: 30
                }
            }
        });
        console.log(swiper);
    }



    var WidgetExtendModuleSliderHandler = function ($scope, $) {
      //  customize_swiper_slider($scope);
    };

    // Make sure you run this code under Elementor.
    $(window).on('elementor/frontend/init', function ($scope) {
        elementorFrontend.hooks.addAction('frontend/element_ready/global', function ($scope) {
            if ($scope.hasClass('elementor-widget-extend-module-slider')) {
                var _self = $scope.find('.extends-module-slider .swiper-container');
                if ('undefined' === typeof Swiper) {
                    /* swiper option */
                    var delay = (_self.attr('data-speed') != '') ? _self.attr('data-speed') : '';
                    var autoplay = (_self.attr('data-autoplay') === 'yes') ? true : false;
                    if (autoplay == true) {
                        var pause_on_hover = (_self.attr('data-pause-on-hover') === 'yes') ? true : false;
                        var pause_on_interaction = (_self.attr('data-pause-on-interaction') === 'yes') ? true : false;
                        if (delay != '') autoplay = {
                            delay: delay,
                            pauseOnMouseEnter: pause_on_hover,
                            disableOnInteraction: pause_on_interaction
                        }
                    }

                    var speed = (_self.attr('data-transition-speed') != '') ? parseInt(_self.attr('data-transition-speed')) : '';

                    var navigation = (_self.attr('data-arrows') == 'arrows' || _self.attr('data-arrows') != 'both') ? {
                        nextEl: '.elementor-swiper-button-next',
                        prevEl: '.elementor-swiper-button-prev',
                    } : false;

                    var pagination = (_self.attr('data-dots') == 'dots' || _self.attr('data-dots') != 'both') ? {
                        el: '.swiper-pagination',
                        type: 'bullets',
                        clickable: true
                    } : false;

                    var effect = (_self.attr('data-effect') != '') ? _self.attr('data-effect') : 'slide';

                    var animation = (_self.attr('data-animation') != '') ? _self.attr('data-animation') : '';

                    var loop = (_self.attr('data-infinite') === 'yes') ? true : false;

                    var slidesPerView = (_self.attr('data-item-desktop') != '') ? parseInt(_self.attr('data-item-desktop')) : 1;
                    var slidesPerViewTablet = (_self.attr('data-item-tablet') != '') ? parseInt(_self.attr('data-item-tablet')) : 1;
                    var slidesPerViewMobile = (_self.attr('data-item-mobile') != '') ? parseInt(_self.attr('data-item-mobile')) : 1;

                    var options_swiper = {
                        autoplay: autoplay,
                        speed: speed,
                        slidesPerView: slidesPerView,
                        loop: loop,
                        navigation: navigation,
                        pagination: pagination,
                        effect: effect,

                        breakpoints: {
                            // when window width is >= 0px
                            0: {
                                slidesPerView: 1,
                                loop: loop,
                                navigation: navigation,
                                pagination: pagination,
                                //spaceBetween: 20
                            },
                            320: {
                                slidesPerView: slidesPerViewMobile,
                                loop: loop,
                                navigation: navigation,
                                pagination: pagination,
                                //    spaceBetween: 20
                            },
                            // when window width is >= 768px
                            768: {
                                slidesPerView: slidesPerViewTablet,
                                loop: loop,
                                navigation: navigation,
                                pagination: pagination,
                                //    spaceBetween: 15
                            },
                            // when window width is >= 1024px
                            1024: {
                                slidesPerView: slidesPerView,
                                loop: loop,
                                navigation: navigation,
                                pagination: pagination,
                                //     spaceBetween: 30
                            }
                        }
                    }
                    const asyncSwiper = elementorFrontend.utils.swiper;
                    var swiper = new asyncSwiper(_self, options_swiper);
                } else {
                    console.log('Swiper global variable is ready, create a new instance: ', Swiper);

                    mySwiper = new Swiper(swiperElement, swiperConfig);
                }
                //run one time and return
                return;
            }
        });
    });
})(jQuery);