( function( $ ) {
    /**
     * @param $scope The Widget wrapper element as a jQuery element
     * @param $ The jQuery alias
     */

    function hiddenFix(animation, self){
        self.find('.swiper-slide-contents').css("display","none");
    }

    function callAnimation(animation, self){
        if(animation != ''){
            self.find('.swiper-slide-contents').css("display","block");
            self.find('.swiper-slide-contents').removeClass(animation);
            self.find('.swiper-slide-contents').removeClass('animated');
            self.find('.swiper-slide-active .swiper-slide-contents').addClass('animated '+animation);
        }
    }

    function customize_swiper_slider($scope){
        // get unique uid for slider
        const uid = Date.now().toString(36) + Math.random().toString(36).substr(2);

        var _self = $scope.find('.extends-slider .swiper-container');
        var classAdd = 'custom-swiper_'+uid;
        var classCall = '.'+classAdd;
        _self.addClass(classAdd);

        var delay = ( _self.attr('data-speed') != '') ? _self.attr('data-speed') : '';

        var autoplay = ( _self.attr('data-autoplay') === 'yes') ?  true :  false ;
        if(autoplay == true){
            var pause_on_hover = (_self.attr('data-pause-on-hover') === 'yes') ?  true : false;
            var pause_on_interaction = (_self.attr('data-pause-on-interaction') === 'yes') ?  true : false;
            if(delay != '') autoplay = {
                delay:delay,
                pauseOnMouseEnter: pause_on_hover,
                disableOnInteraction: pause_on_interaction
            }
        }

        var speed = ( _self.attr('data-transition-speed') != '') ?  parseInt(_self.attr('data-transition-speed')) :  '' ;

        var navigation =  ( _self.attr('data-arrows') == '1' ) ? {
            nextEl: '.extends-slider .elementor-swiper-button-next',
            prevEl: '.extends-slider .elementor-swiper-button-prev',
            disabledClass: 'swiper-button-disabled'
        } : false;

        console.log(navigation);

        var pagination  = ( _self.attr('data-dots') ==  '1') ? {
            el: '.extends-slider .swiper-pagination',
            type: 'bullets',
            clickable: true
        } : false;

        console.log(pagination);

        var effect = ( _self.attr('data-effect') != '') ?  _self.attr('data-effect') : 'slide';

        var animation = (_self.attr('data-animation') != '') ? _self.attr('data-animation') : '';

        var loop = ( _self.attr('data-infinite') === 'yes') ? true : false;

        var swiper = new Swiper(classCall, {
                // observeParents: true,
                // observer: true,
                // parallax:true,
                autoplay: autoplay,
                speed: speed,
              loop : loop,
             //   enabled: true,
                slidesPerView: 1,
                navigation: navigation,
                pagination: pagination,
                effect : effect,
                on: {
                    init: function () {
                        callAnimation(animation,_self);
                    },
                    slideChangeTransitionStart: function(){
                        hiddenFix(animation,_self);
                        callAnimation(animation,_self);
                    },
                    slideChangeTransitionEnd: function () {

                    },
                },
                breakpoints: {
                    1200: {
                        slidesPerView: 1,
                    },
                }
        });
        // console.log(swiper);

    }

    var WidgetExtendSliderHandler = function( $scope, $ ) {
        customize_swiper_slider($scope);
    };

    // Make sure you run this code under Elementor.
    $( window ).on( 'elementor/frontend/init', function() {
        elementorFrontend.hooks.addAction( 'frontend/element_ready/extend-slider.default', WidgetExtendSliderHandler );
    } );
} )( jQuery );