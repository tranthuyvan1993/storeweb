( function( $ ) {
    /**
     * @param $scope The Widget wrapper element as a jQuery element
     * @param $ The jQuery alias
     */

    function customize_swiper_slider($scope){
        // get unique uid for slider
        const uid = Date.now().toString(36) + Math.random().toString(36).substr(2);

        var _self = $scope.find('.extends-module-slider .swiper-container');
        var classAdd = 'custom-swiper_'+uid;
        var classCall = '.'+classAdd;
        _self.addClass(classAdd);

        /* swiper option */
        var autoplay = ( _self.attr('data-autoplay') === 'yes') ?  true :  false ;
        var speed = ( _self.attr('data-speed') != '') ?  parseInt(_self.attr('data-speed')) :  '' ;
        var slidesPerView = ( _self.attr('data-item-desktop') != '') ? parseInt(_self.attr('data-item-desktop')) : 1;
        var slidesPerViewTablet = ( _self.attr('data-item-tablet') != '') ? parseInt(_self.attr('data-item-tablet')) : 1;
        var slidesPerViewMobile = ( _self.attr('data-item-mobile') != '') ? parseInt(_self.attr('data-item-mobile')) : 1;
        var swiper = new Swiper(classCall, {
            autoplay: autoplay,
            speed: speed,
            slidesPerView: slidesPerView,
            breakpoints: {
                // when window width is >= 0px
                0: {
                    slidesPerView: 1,
                    //spaceBetween: 20
                },
                320: {
                    slidesPerView: slidesPerViewMobile,
                //    spaceBetween: 20
                },
                // when window width is >= 768px
                768: {
                    slidesPerView: slidesPerViewTablet,
                //    spaceBetween: 15
                },
                // when window width is >= 1024px
                1024: {
                    slidesPerView: slidesPerView,
               //     spaceBetween: 30
                }
            }
        });
    }

    var WidgetExtendModuleSliderHandler = function( $scope, $ ) {
        customize_swiper_slider($scope);
    };

    // Make sure you run this code under Elementor.
    $( window ).on( 'elementor/frontend/init', function() {
        elementorFrontend.hooks.addAction( 'frontend/element_ready/extend-module-slider.default', WidgetExtendModuleSliderHandler );
    } );
} )( jQuery );