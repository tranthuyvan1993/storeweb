<?php
/**
 * Created by PhpStorm.
 * User: toan1
 * Date: 29/07/2021
 * Time: 5:25 PM
 */

function theme_prefix_register_elementor_locations( $elementor_theme_manager ) {

//        $elementor_theme_manager->register_location( 'header' );
    $elementor_theme_manager->register_location( 'footer' );
    // $elementor_theme_manager->register_location( 'single' );
    // $elementor_theme_manager->register_location( 'archive' );

}
add_action( 'elementor/theme/register_locations', 'theme_prefix_register_elementor_locations' );

class My_Elementor_Widgets {

    protected static $instance = null;

    protected static $list_widgets = array(
        'extend-slider',
       'extend-box3',
       'extend-main-box3',
       'extend-main-box4',
       'extend-main-box5',
       'extend-main-box6',
       'extend-main-box6',
       'extend-main-box9',
       'extend-bhn-banner',
       'slider-bhn-box8',
        'extend-slider-style2',
        'extend-module-slider',
        'extend-title',
        // 'extend-slide-box6',
        'extend-toggle',
   //     'extend-form',
        'extend-capabilities',
        'extend-breadcrumb',
        'extend-project-summary',
        'extend-youtube-list',
        'extend-link-list'
    );

    public static function get_instance() {
        if ( ! isset( static::$instance ) ) {
            static::$instance = new static;
        }

        return static::$instance;
    }

    protected function __construct() {
        add_action( 'elementor/widgets/widgets_registered', [ $this, 'register_widgets' ] );
        add_action( 'elementor/frontend/after_register_scripts', [$this, 'register_script_elementor']);
        add_action( 'elementor/frontend/after_enqueue_styles', [$this, 'register_style_elementor'] );
    }

    public function register_script_elementor()
    {
        $list_widgets = $this::$list_widgets;
        foreach ($list_widgets as $key => $value){
            wp_register_script( 'elementor-'.$value, get_template_directory_uri().'/t888core/elementor-widget/widget/'.$value.'/assets/js/'.$value.'.js', [ 'jquery' ], null, true );
        }
    }

    public function register_style_elementor(){
        $list_widgets = $this::$list_widgets;
        foreach ($list_widgets as $key => $value){
            wp_enqueue_style( 'elementor-'.$value, get_template_directory_uri().'/t888core/elementor-widget/widget/'.$value.'/assets/css/'.$value.'.css',  array(),  false, 'all' );
        }
      //  wp_enqueue_style( 'elementor-extend-slider', get_template_directory_uri().'/t888core/elementor-widget/widget/extend-slider/assets/css/extend-slider.css',  array(),  false, 'all' );
        //      wp_register_style( 'elementor-extend-slider', get_template_directory_uri().'/t888core/elementor-widget/widget/extend-slider/assets/css/extend-slider.css',  array(),  false, 'all' );
    }

    public function register_widgets() {
            $list_widgets = $this::$list_widgets;
            foreach ($list_widgets as $key => $value){
                require_once('widget/'.$value.'/'.$value.'.php');
            }
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\Extend_Slider() );
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\Widget_Extend_Title() );
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\Widget_Extend_Main_Box3() );
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\Widget_Extend_Main_Box4() );
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\Widget_Extend_Main_Box5() );
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\Widget_Extend_Main_Box6() );
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\Widget_Extend_Main_Box9() );
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\Widget_Extend_Capabitites() );
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\Widget_Extend_Box3() );
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\Widget_Extend_Bhn_Banner() );
            // \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\Widget_Extend_Title2() );
            // \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\Extend_Slider_Box6() );
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\Widget_Extend_Breadcrumb() );
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\Widget_Extend_Project_Summary() );
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\Extend_Module_Slider() );
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\Slider_Bhn_Box8());
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\Extend_Slider_Style2() );
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\Extend_Toggle() );
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\Extend_Youtube_List() );
            \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Elementor\Widget_Extend_Link_List() );
        //    \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \ElementorPro\Extend_Posts() );
        //    \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \ElementorPro\Extend_Call_To_Action() );
         //   \Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \ElementorPro\Extend_Form() );
    }

}

add_action( 'init', 'my_elementor_init' );
function my_elementor_init() {
    My_Elementor_Widgets::get_instance();
}