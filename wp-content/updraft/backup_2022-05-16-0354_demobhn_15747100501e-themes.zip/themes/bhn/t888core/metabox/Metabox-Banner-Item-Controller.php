<?php
/**
 * Created by PhpStorm.
 * User: toanngo92
 * Date: 2/11/2019
 * Time: 2:39 PM
 */

if (!class_exists('Tech888f_Metabox_Banner_Item_Controller')) {
    class Tech888f_Metabox_Banner_Item_Controller
    {

        static function _init()
        {
            if (function_exists('tech888f_reg_metabox')) {
                //add_action( 'admin_menu' , 'remove_post_metabox_fields' );
                add_filter( 'rwmb_meta_boxes', 'tech888f_register_banner_Item_meta_boxes' );
            }
        }

//        static function _add_meta_box()
//        {
//            $id = 'tech888f_Banner_Item_metabox';
//            $title = esc_html__('Tech888 Page Customize Settings', 'posolo');
//            $screen = 'page';
//            $context = 'normal';
//            $callback_args = null;
//            tech888f_reg_metabox($id, $title, 'output_metabox_Banner_Item_backend', $screen, $context, null, $callback_args);
//        }

    }

    Tech888f_Metabox_Banner_Item_Controller::_init();

}


if(!function_exists('tech888f_register_banner_Item_meta_boxes')){
    function tech888f_register_banner_Item_meta_boxes( $meta_boxes ) {
        $meta_boxes[] = array (
            'title' => 'Page Settings',
            'id' => 'page-settings',
            'post_types' => array(
                0 => 'banner_item',
            ),
            'context' => 'normal',
            'priority' => 'high',
            'fields' => array(
                array (
                    'id' => 'banner_item_title_1',
                    'label'       => esc_html__('Tiêu đề 1','posolo'),
                    'type' => 'text',
                    'name' => esc_html('Tiêu đề 1','posolo'),
                ),
                array (
                    'id' => 'banner_item_title_2',
                    'label'       => esc_html__('Tiêu đề 2','posolo'),
                    'type' => 'text',
                    'name' => esc_html('Tiêu đề 2','posolo'),
                ),
                array (
                    'id' => 'banner_item_desc',
                    'label'       => esc_html__('Mô tả','posolo'),
                    'type' => 'text',
                    'name' => esc_html('Mô tả','posolo'),
                ),
            ),
        );
        return $meta_boxes;
    }
}