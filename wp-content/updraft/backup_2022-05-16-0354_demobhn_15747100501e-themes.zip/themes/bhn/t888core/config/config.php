<?php
/**
 * Created by Sublime Text 2.
 * User: thanhhiep992
 * Date: 12/08/15
 * Time: 10:20 AM
 */
if (!function_exists('tech888f_set_theme_config')) {
    function tech888f_set_theme_config()
    {
        global $tech888f_dir, $tech888f_config, $redux_option;
        /**************************************** BEGIN ****************************************/
        $tech888f_dir = get_template_directory_uri() . '/t888core';
        $redux_option = true;
        $tech888f_config = array();
        $tech888f_config['dir'] = $tech888f_dir;
        $tech888f_config['css_url'] = $tech888f_dir . '/assets/css/';
        $tech888f_config['js_url'] = $tech888f_dir . '/assets/js/';
        $tech888f_config['bootstrap_ver'] = '3';
        $tech888f_config['nav_menu'] = array(
            'primary' => esc_html__('Primary Navigation', 'posolo'),
        );
        $tech888f_config['mega_menu'] = '1';
        $tech888f_config['sidebars'] = array(
            array(
                'name' => esc_html__('Blog Sidebar', 'posolo'),
                'id' => 'blog-sidebar',
                'description' => esc_html__('Widgets in this area will be shown on all blog page.', 'posolo'),
                'before_title' => '<h3 class="widget-title">',
                'after_title' => '</h3>',
                'before_widget' => '<div id="%1$s" class="sidebar-widget widget %2$s">',
                'after_widget' => '</div>',
            )
        );
        if (class_exists("woocommerce")) {
            $tech888f_config['sidebars'][] = array(
                'name' => esc_html__('Woocommerce Sidebar', 'posolo'),
                'id' => 'woocommerce-sidebar',
                'description' => esc_html__('Widgets in this area will be shown on all woocommerce page.', 'posolo'),
                'before_title' => '<h3 class="widget-title">',
                'after_title' => '</h3>',
                'before_widget' => '<div id="%1$s" class="sidebar-widget widget %2$s">',
                'after_widget' => '</div>',
            );
        }
        $tech888f_config['import_config'] = array(
            'demo_url' => 'http://posolo.web888.vn',
            'homepage_default' => 'Home',
            'blogpage_default' => 'Blog',
            'menu_replace' => 'Main Menu',
            'menu_locations' => array("Main Menu" => "primary"),
            'set_woocommerce_page' => 1
        );
        $tech888f_config['import_theme_option'] = '{"last_tab":"1","tech888f_header_page":"1365","tech888f_footer_page":"1397","tech888f_404_page":"","before_append_page":"","after_append_page":"","tech888f_show_breadrumb":"1","tech888f_bg_breadcrumb":{"background-color":"","background-repeat":"","background-size":"","background-attachment":"","background-position":"","background-image":"","media":{"id":"","height":"","width":"","thumbnail":""}},"breadcrumb_text":{"font-family":"","font-options":"","google":"1","font-weight":"","font-style":"","subsets":"","text-align":"","font-size":"","line-height":"","color":""},"breadcrumb_text_hover":{"font-family":"","font-options":"","google":"1","font-weight":"","font-style":"","subsets":"","text-align":"","font-size":"","line-height":"","color":""},"show_preload":"","preload_bg":{"color":"","alpha":"1","rgba":""},"preload_style":"","preload_img":{"url":"","id":"","height":"","width":"","thumbnail":"","title":"","caption":"","alt":"","description":""},"tech888f_icon_lib":"fontawesome","show_scroll_top":"","show_wishlist_notification":"","show_too_panel":"","session_page":"","body_bg":{"color":"","alpha":"1","rgba":""},"main_color":{"color":"","alpha":"1","rgba":""},"main_color2":{"color":"","alpha":"1","rgba":""},"container_width":"","map_api_key":"","post_single_share":{"post":"1","page":"","product":""},"post_single_share_list":[{"title":" Facebook","social":"facebook","number":"0"},{"title":"Twitter","social":"twitter","number":"0"},{"title":" Linkedin","social":"linkedin","number":"0"}],"disable_verify_notice":"","sv_menu_color":{"font-family":"","font-options":"","google":"1","font-weight":"","font-style":"","subsets":"","text-align":"","font-size":"","line-height":"","color":""},"sv_menu_color_hover":{"color":"","alpha":"1","rgba":""},"sv_menu_color_active":{"color":"","alpha":"1","rgba":""},"sv_menu_color2":{"font-family":"","font-options":"","google":"1","font-weight":"","font-style":"","subsets":"","text-align":"","font-size":"","line-height":"","color":""},"sv_menu_color_hover2":{"color":"","alpha":"1","rgba":""},"sv_menu_color_active2":{"color":"","alpha":"1","rgba":""},"before_append_post":"","after_append_post":"","tech888f_sidebar_position_blog":"left","tech888f_sidebar_blog":"woocommerce-sidebar","blog_default_style":"list","blog_style":"","blog_number_filter":"1","blog_number_filter_list":[{"title":" 12 item per page","number":"12"},{"title":" 16 item per page","number":" 16"},{"title":" 20 item per page","number":" 20"},{"title":"  24 item per page","number":" 24"},{"title":" ","number":" "}],"blog_type_filter":"1","post_list_size":"","post_list_item_style":"","post_grid_column":"3","post_grid_size":"","post_grid_excerpt":"80","post_grid_item_style":"","post_grid_type":"","tech888f_post_detail_style":"","tech888f_sidebar_position_post":"right","tech888f_sidebar_post":"","post_single_thumbnail":"1","post_single_size":"","post_single_meta":"1","post_single_author":"1","post_single_navigation":"1","post_single_related":"1","post_single_related_title":"","post_single_related_number":"4","post_single_related_item":"0:1,567:2","tech888f_sidebar_position_page":"no","tech888f_sidebar_page":"","tech888f_sidebar_position_page_archive":"","tech888f_sidebar_page_archive":"","tech888f_sidebar_position_page_search":"","tech888f_sidebar_page_search":"","tech888f_custom_typography":[{"title":" ","typo_area":"","typo_heading":"","typography_style":{"font-family":"","font-options":"","google":"1","font-weight":"","font-style":"","subsets":"","text-align":"","font-size":"","line-height":"","color":""}}],"tech888f_sidebar_position_woo":"","tech888f_sidebar_woo":"","shop_default_style":"","shop_gap_product":"","woo_shop_number":"12","sv_set_time_woo":"","shop_ajax":"","shop_number_filter":"1","shop_number_filter_list":[{"title":" ","number":" "}],"shop_type_filter":"1","shop_list_size":"","shop_list_item_style":"","shop_grid_column":"3","shop_grid_size":"","shop_grid_item_style":"","shop_grid_type":"","cart_page_style":"","checkout_page_style":"","tech888f_header_page_woo":"","tech888f_footer_page_woo":"","before_append_woo":"","after_append_woo":"","sv_sidebar_position_woo_single":"right","sv_sidebar_woo_single":"woocommerce-sidebar","product_tab_detail":"","show_excerpt":"1","show_latest":"0","show_upsell":"1","show_related":"1","show_single_number":"6","show_single_size":"","show_single_itemres":"0:1,480:2,990:3","show_single_item_style":"","before_append_woo_single":"","before_append_tab":"","after_append_tab":"","after_append_woo_single":"","tech888f_page_style":"","redux-backup":"1"}';
        $tech888f_config['import_widget'] = '{"blog-sidebar":{"tech888f_wg_get_mega_page-3":{"title":"","el_class":"","page_id":"2327"},"search-3":{"title":""},"categories-3":{"title":"","count":1,"hierarchical":0,"dropdown":0},"tag_cloud-2":{"title":"Browse Tags","count":0,"taxonomy":"post_tag"},"tech888f_listpostswidget-2":{"title":"Popular Post","posts_per_page":"5","category":"0","order":"desc","order_by":"none"}},"woocommerce-sidebar":{"woocommerce_product_search-1":{"title":""},"tech888f_category_fillter-2":{"title":"Product Categories","category":["solar-panel","grid-solar-panel","marine-solar-panel","portable-solar-panel"]},"tech888f_wg_get_mega_page-2":{"title":"Products","el_class":"","page_id":"1875"},"tech888f_wg_get_mega_page-4":{"title":"Instagram","el_class":"","page_id":"2341"},"tech888f_price_filter-2":{"title":"Price Filter"},"woocommerce_price_filter-1":{"title":"Filter by price"},"tech888f_full_fitler-2":{"title":"Attribute Filter","category":[],"attributes":["dimension","no-of-cells","weight"],"manufac":[],"cat_title":"","attribute_title":"","manufac_title":"","price_filter_title":""},"tech888f_attribute_filter-2":{"title":"Color Filter","attribute":"color-attr"}}}';
        $tech888f_config['import_category'] = '';

        /**************************************** PLUGINS ****************************************/

        $tech888f_config['require-plugin-begin'] = array(
            array(
                'name' => esc_html__('Tech888 Core', 'posolo'),
                'slug' => 'tech888-core',
                'required' => true,
                'source' => get_template_directory() . '/plugins/tech888-core.zip',
                'version' => '1.0',
            ),
        );

        $tech888f_config['require-plugin'] = array(
            array(
                'name' => esc_html__('Tech888 Core', 'posolo'),
                'slug' => 'tech888-core',
                'required' => true,
                'source' => get_template_directory() . '/plugins/tech888-core.zip',
                'version' => '1.0',
            ),
            array(
                'name' => esc_html__('Redux Framework', 'posolo'),
                'slug' => 'redux-framework',
                'required' => true,
            ),
            array(
                'name' => esc_html__('WpBakery Page Builder', 'posolo'),
                'slug' => 'js_composer',
                'required' => true,
                'source' => get_template_directory() . '/plugins/js_composer.zip',
                'version' => '5.7',
            ),
            array(
                'name' => esc_html__('WooCommerce', 'posolo'),
                'slug' => 'woocommerce',
                'required' => true,
            ),
            array(
                'name' => esc_html__('Meta box', 'posolo'),
                'slug' => 'meta-box',
                'required' => true,
            ),
            array(
                'name' => esc_html__('Contact Form 7', 'posolo'),
                'slug' => 'contact-form-7',
                'required' => false,
            ),
            array(
                'name' => esc_html__('MailChimp for WordPress Lite', 'posolo'),
                'slug' => 'mailchimp-for-wp',
                'required' => false,
            ),
            array(
                'name' => esc_html__('Yith Woocommerce Compare', 'posolo'),
                'slug' => 'yith-woocommerce-compare',
                'required' => false,
            ),
            array(
                'name' => esc_html__('Yith Woocommerce Wishlist', 'posolo'),
                'slug' => 'yith-woocommerce-wishlist',
                'required' => false,
            ),
        );

        /**************************************** PLUGINS ****************************************/
        $tech888f_config['theme-option'] = array(
            'sections' => array(
                array(
                    'id' => 'option_basic',
                    'title' => '<i class="fa fa-cog"></i>' . esc_html__(' Basic Settings', 'posolo')
                ),
                array(
                    'id' => 'option_menu',
                    'title' => '<i class="fa fa-align-justify"></i>' . esc_html__(' Menu Settings', 'posolo')
                ),
                array(
                    'id' => 'blog_post',
                    'title' => '<i class="fa fa-bold"></i>' . esc_html__(' Blog & Post', 'posolo')
                ),
                array(
                    'id' => 'option_layout',
                    'title' => '<i class="fa fa-columns"></i>' . esc_html__(' Layout Settings', 'posolo')
                ),
                array(
                    'id' => 'option_typography',
                    'title' => '<i class="fa fa-font"></i>' . esc_html__(' Typography', 'posolo')
                ),
                array(
                    'id' => 'option_lazyscript',
                    'title' => '<i class="fa fa-font"></i>' . esc_html__(' Lazy Script', 'posolo')
                )
            ),
            'settings' => array(
                /*----------------Begin Basic --------------------*/
                // header top 
                array(
                    'id' => 'tab_header_theme',
                    'type' => 'tab',
                    'section' => 'option_basic',
                    'label' => esc_html__('Header TOP Settings', 'posolo')
                ),
                array(
                    'id' => 'header_top_logo',
                    'type' => 'upload',
                    'section' => 'option_basic',
                    'label' => esc_html__('Logo', 'posolo')
                ),
                array(
                    'id' => 'header_text',
                    'type' => 'text',
                    'section' => 'option_basic',
                    'label' => esc_html__('Logo test', 'posolo')
                ),
                // array(
                //     'id' => 'header_top_address',
                //     'type' => 'textarea',
                //     'section' => 'option_basic',
                //     'label' => esc_html__('Address', 'posolo')
                // ), 
                // array(
                //     'id' => 'header_top_address_image',
                //     'type' => 'upload',
                //     'section' => 'option_basic',
                //     'label' => esc_html__('Address image', 'posolo')
                // ),
                
                // array(
                //     'id' => 'header_top_email',
                //     'type' => 'text',
                //     'section' => 'option_basic',
                //     'label' => esc_html__('Email', 'posolo')
                // ),
                // array(
                //     'id' => 'header_top_email_image',
                //     'type' => 'upload',
                //     'section' => 'option_basic',
                //     'label' => esc_html__('Email image', 'posolo')
                // ),
                // array(
                //     'id' => 'header_top_contact',
                //     'type' => 'text',
                //     'section' => 'option_basic',
                //     'label' => esc_html__('Contact', 'posolo')
                // ),
                // array(
                //     'id' => 'header_top_contact_image',
                //     'type' => 'upload',
                //     'section' => 'option_basic',
                //     'label' => esc_html__('Contact image', 'posolo')
                // ),
                //end header
                //footer
                
                array(
                    'id' => 'tab_footer_theme',
                    'type' => 'tab',
                    'section' => 'option_basic',
                    'label' => esc_html__('Footer settings', 'posolo')
                ),
                array(
                    'id' => 'background_footer',
                    'type' => 'upload',
                    'section' => 'option_basic',
                    'label' => esc_html__('Ảnh nền footer', 'posolo')
                ),
                // col 1
                array(
                    'id' => 'footer_col_1_title',
                    'type' => 'text',
                    'section' => 'option_basic',
                    'label' => esc_html__('Tiêu đề cột footer 1', 'posolo')
                ),
                array(
                    'id' => 'footer_col_1',
                    'label' => esc_html__('Cột 1', 'posolo'),
                    'type' => 'list-item',
                    'section' => 'option_basic',
                    'settings' => array(
                        array(
                            'id' => 'desc',
                            'label' => esc_html__('Tên dòng', 'posolo'),
                            'type' => 'text',
                        ),
                        array(
                            'id' => 'link',
                            'label' => esc_html__('Link', 'posolo'),
                            'type' => 'text',
                        ),
                    ),
                    'condition' => 'blog_number_filter:not(off)',
                ),
                // col 2
                array(
                    'id' => 'footer_col_2_title',
                    'type' => 'text',
                    'section' => 'option_basic',
                    'label' => esc_html__('Tiêu đề cột footer 2', 'posolo')
                ),
                array(
                    'id' => 'footer_col_2',
                    'label' => esc_html__('Cột 2', 'posolo'),
                    'type' => 'list-item',
                    'section' => 'option_basic',
                    'settings' => array(
                        array(
                            'id' => 'desc',
                            'label' => esc_html__('Tên dòng', 'posolo'),
                            'type' => 'text',
                        ),
                        array(
                            'id' => 'link',
                            'label' => esc_html__('Link', 'posolo'),
                            'type' => 'text',
                        ),
                    ),
                    'condition' => 'blog_number_filter:not(off)',
                ),
                // col 3
                array(
                    'id' => 'footer_col_3_title',
                    'type' => 'text',
                    'section' => 'option_basic',
                    'label' => esc_html__('Tiêu đề cột footer 3', 'posolo')
                ),
                array(
                    'id' => 'footer_col_3',
                    'label' => esc_html__('Cột 3', 'posolo'),
                    'type' => 'list-item',
                    'section' => 'option_basic',
                    'settings' => array(
                        array(
                            'id' => 'desc',
                            'label' => esc_html__('Tên dòng', 'posolo'),
                            'type' => 'text',
                        ),
                        array(
                            'id' => 'link',
                            'label' => esc_html__('Link', 'posolo'),
                            'type' => 'text',
                        ),
                    ),
                    'condition' => 'blog_number_filter:not(off)',
                ),
                //col 4
                array(
                    'id' => 'footer_col_4_title',
                    'type' => 'text',
                    'section' => 'option_basic',
                    'label' => esc_html__('Tiêu đề cột footer 4', 'posolo')
                ),
                array(
                    'id' => 'footer_col_4',
                    'label' => esc_html__('Cột 4', 'posolo'),
                    'type' => 'list-item',
                    'section' => 'option_basic',
                    'settings' => array(
                        array(
                            'id' => 'province',
                            'label' => esc_html__('Tên tỉnh thành', 'posolo'),
                            'type' => 'text',
                        ),
                        array(
                            'id' => 'desc',
                            'label' => esc_html__('Tên dòng', 'posolo'),
                            'type' => 'text',
                        ),
                    ),
                    'condition' => 'blog_number_filter:not(off)',
                ),
                // end footer
                array(
                    'id' => 'tab_general_theme',
                    'type' => 'tab',
                    'section' => 'option_basic',
                    'label' => esc_html__('General', 'posolo')
                ),
                array(
                    'id' => 'tech888f_header_page',
                    'label' => esc_html__('Header Page', 'posolo'),
                    'desc' => esc_html__('Include Header content. Go to Header in admin menu to edit/create header content. Note this value default for all pages of your site, If have any page/single page display other content pehaps you are set specific header for it', 'posolo'),
                    'type' => 'select',
                    'section' => 'option_basic',
                    'options' => tech888f_list_post_type('tech888f_header')
                ),
                array(
                    'id' => 'tech888f_footer_page',
                    'label' => esc_html__('Footer Page', 'posolo'),
                    'desc' => esc_html__('Include Footer content. Go to Footer in admin menu to edit/create footer content.  Note this value default for all pages of your site, If have any page/single page display other content pehaps you are set specific footer for it', 'posolo'),
                    'type' => 'select',
                    'section' => 'option_basic',
                    'options' => tech888f_list_post_type('tech888f_footer')
                ),
                array(
                    'id' => 'tech888f_404_page',
                    'label' => esc_html__('404 Page', 'posolo'),
                    'desc' => esc_html__('Include page to 404 page', 'posolo'),
                    'type' => 'select',
                    'section' => 'option_basic',
                    'options' => tech888f_list_post_type('tech888f_mega_item'),
                    //'choices'     => tech888f_list_post_type('tech888f_mega_item')
                ),
                array(
                    'id' => 'tech888f_404_page_style',
                    'label' => esc_html__('404 Style', 'posolo'),
                    'desc' => esc_html__('Choose a style to display.', 'posolo'),
                    'type' => 'select',
                    'section' => 'option_basic',
                    'choices' => array(
                        '' => 'Default',
                        'full-width' => esc_html__('FullWidth', 'posolo'),
                    ),
                    'condition' => 'tech888f_404_page:not()',
                ),
                array(
                    'id' => 'before_append_page',
                    'label' => esc_html__('Append content before page(default)', 'posolo'),
                    'type' => 'select',
                    'section' => 'option_basic',
                    'options' => tech888f_list_post_type('tech888f_mega_item'),
                    'desc' => esc_html__('Choose a mega page content append to before main content of page with template default.', 'posolo'),
                ),
                array(
                    'id' => 'after_append_page',
                    'label' => esc_html__('Append content after page(default)', 'posolo'),
                    'type' => 'select',
                    'section' => 'option_basic',
                    'options' => tech888f_list_post_type('tech888f_mega_item'),
                    'desc' => esc_html__('Choose a mega page content append to after main content of page with template default.', 'posolo'),
                ),
                array(
                    'id' => 'tab_breadcrumb',
                    'type' => 'tab',
                    'section' => 'option_basic',
                    'label' => esc_html__('Breadcumb', 'posolo')
                ),
                array(
                    'id' => 'tech888f_show_breadrumb',
                    'label' => esc_html__('Show BreadCrumb', 'posolo'),
                    'desc' => esc_html__('This allow you to show or hide BreadCrumb', 'posolo'),
                    'type' => 'on-off',
                    'section' => 'option_basic',
                    'std' => 'on'
                ),
                array(
                    'id' => 'tech888f_bg_breadcrumb',
                    'label' => esc_html__('Background Breadcrumb', 'posolo'),
                    'type' => 'background',
                    'section' => 'option_basic',
                    'condition' => 'tech888f_show_breadrumb:is(on)',
                    'desc' => esc_html__('Custom background for breadcrumb.', 'posolo'),
                ),
                array(
                    'id' => 'breadcrumb_text',
                    'label' => esc_html__('Breadcrumb text', 'posolo'),
                    'type' => 'typography',
                    'section' => 'option_basic',
                    'condition' => 'tech888f_show_breadrumb:is(on)',
                    'desc' => esc_html__('Custom font in breadcrumb.', 'posolo'),
                ),
                array(
                    'id' => 'breadcrumb_text_hover',
                    'label' => esc_html__('Breadcrumb text hover', 'posolo'),
                    'type' => 'typography',
                    'section' => 'option_basic',
                    'condition' => 'tech888f_show_breadrumb:is(on)',
                    'desc' => esc_html__('Custom font when you hover in text of breadcrumb.', 'posolo'),
                ),
                array(
                    'id' => 'tab_preload',
                    'type' => 'tab',
                    'section' => 'option_basic',
                    'label' => esc_html__('Preload', 'posolo')
                ),
                array(
                    'id' => 'show_preload',
                    'label' => esc_html__('Show Preload', 'posolo'),
                    'desc' => esc_html__('This allow you to show or hide preload', 'posolo'),
                    'type' => 'on-off',
                    'section' => 'option_basic',
                    'std' => 'off'
                ),
                array(
                    'id' => 'preload_bg',
                    'label' => esc_html__('Background', 'posolo'),
                    'type' => 'colorpicker-opacity',
                    'section' => 'option_basic',
                    'desc' => esc_html__('Change default body background.', 'posolo'),
                    'condition' => 'show_preload:is(on)',
                ),
                array(
                    'id' => 'preload_style',
                    'label' => esc_html__('Preload Style', 'posolo'),
                    'type' => 'select',
                    'std' => '',
                    'section' => 'option_basic',
                    'options' => array(
                        '' => esc_html__('Style 1', 'posolo'),
                        'style2' => esc_html__('Style 2', 'posolo'),
                        'style3' => esc_html__('Style 3', 'posolo'),
                        'style4' => esc_html__('Style 4', 'posolo'),
                        'style5' => esc_html__('Style 5', 'posolo'),
                        'style6' => esc_html__('Style 6', 'posolo'),
                        'style7' => esc_html__('Style 7', 'posolo'),
                    ),
                    'desc' => esc_html__('Choose default style for your site.', 'posolo'),
                    'condition' => 'show_preload:is(on)',
                ),
                array(
                    'id' => 'preload_img',
                    'label' => esc_html__('Preload Image', 'posolo'),
                    'type' => 'upload',
                    'section' => 'option_basic',
                    'desc' => esc_html__('Choose a image to display as preload.', 'posolo'),
                    'condition' => 'show_preload:is(on),preload_style:is(custom-image)',
                ),
                array(
                    'id' => 'tab_other',
                    'type' => 'tab',
                    'section' => 'option_basic',
                    'label' => esc_html__('Other', 'posolo')
                ),
                array(
                    'id' => 'tech888f_icon_lib',
                    'label' => esc_html__('Default icon', 'posolo'),
                    'type' => 'select',
                    'std' => 'fontawesome',
                    'section' => 'option_basic',
                    'options' => array(
                        'fontawesome' => esc_html__('Font Awesome', 'posolo'),
                        'openiconic' => esc_html__('Open Iconic', 'posolo'),
                        'typicons' => esc_html__('Typicons', 'posolo'),
                        'entypo' => esc_html__('Entypo', 'posolo'),
                        'monosocial' => esc_html__('Mono Social', 'posolo'),
                        'material' => esc_html__('Material', 'posolo'),
                        'ionicon' => esc_html__('Ion Icon', 'posolo')
                    ),
                    'desc' => esc_html__('Choose default style for pages.', 'posolo'),
                ),
                array(
                    'id' => 'show_scroll_top',
                    'label' => esc_html__('Show scroll top button', 'posolo'),
                    'desc' => esc_html__('This allow you to show or hide scroll top button', 'posolo'),
                    'type' => 'on-off',
                    'section' => 'option_basic',
                    'std' => 'off'
                ),
                array(
                    'id' => 'show_wishlist_notification',
                    'label' => esc_html__('Show wishlist notification', 'posolo'),
                    'desc' => esc_html__('This allow you to show or hide wishlist notification when add to wishlist.', 'posolo'),
                    'type' => 'on-off',
                    'section' => 'option_basic',
                    'std' => 'off'
                ),
                array(
                    'id' => 'show_too_panel',
                    'label' => esc_html__('Show tool panel', 'posolo'),
                    'desc' => esc_html__('This allow you to show or hide tool panel.', 'posolo'),
                    'type' => 'on-off',
                    'section' => 'option_basic',
                    'std' => 'off'
                ),
                array(
                    'id' => 'tool_panel_page',
                    'label' => esc_html__('Choose tool panel page', 'posolo'),
                    'desc' => esc_html__('Choose a mega page to display.', 'posolo'),
                    'type' => 'select',
                    'section' => 'option_basic',
                    'choices' => tech888f_list_post_type('tech888f_mega_item'),
                    'condition' => 'show_too_panel:is(on)',
                ),
                array(
                    'id' => 'session_page',
                    'label' => esc_html__('Session page', 'posolo'),
                    'desc' => esc_html__('Enable session page to auto load header,footer,main color in other pages.', 'posolo'),
                    'type' => 'on-off',
                    'section' => 'option_basic',
                    'std' => 'off'
                ),
                array(
                    'id' => 'body_bg',
                    'label' => esc_html__('Body Background', 'posolo'),
                    'type' => 'colorpicker-opacity',
                    'section' => 'option_basic',
                    'desc' => esc_html__('Change default body background.', 'posolo'),
                ),
                array(
                    'id' => 'main_color',
                    'label' => esc_html__('Main color', 'posolo'),
                    'type' => 'colorpicker-opacity',
                    'section' => 'option_basic',
                    'desc' => esc_html__('Change main color of your site.', 'posolo'),
                ),
                array(
                    'id' => 'main_color2',
                    'label' => esc_html__('Main color 2', 'posolo'),
                    'type' => 'colorpicker-opacity',
                    'section' => 'option_basic',
                    'desc' => esc_html__('Change main color 2 of your site.', 'posolo'),
                ),
                array(
                    'id' => 'tech888f_page_style',
                    'label' => esc_html__('Page Style', 'posolo'),
                    'type' => 'select',
                    'std' => '',
                    'section' => 'option_basic',
                    'choices' => array(
                        array(
                            'label' => esc_html__('Default', 'posolo'),
                            'value' => 'page-content-df',
                        ),
                        array(
                            'label' => esc_html__('Page boxed', 'posolo'),
                            'value' => 'page-content-box'
                        ),
                    ),
                    'desc' => esc_html__('Choose default style for pages.', 'posolo'),
                ),
                array(
                    'id' => 'container_width',
                    'label' => esc_html__('Custom container width(px)', 'posolo'),
                    'type' => 'text',
                    'section' => 'option_basic',
                    'desc' => esc_html__('You can custom width of container on your site. Default is 1200px.', 'posolo'),
                ),
                array(
                    'id' => 'map_api_key',
                    'label' => esc_html__('Map API key', 'posolo'),
                    'type' => 'text',
                    'section' => 'option_basic',
                    'std' => '',// ex: AIzaSyBX2IiEBg-0lQKQQ6wk6sWRGQnWI7iogf0
                    'desc' => esc_html__('Enter your Map API key to display your location on google maps element.', 'posolo') . ' </br><a target="_blank" href="//developers.google.com/maps/documentation/javascript/get-api-key">Get API</a>',
                ),
                array(
                    'id' => 'post_single_share',
                    'label' => esc_html__('Show share box', 'posolo'),
                    'type' => 'checkbox',
                    'section' => 'option_basic',
                    'choices' => array(
                        array(
                            'label' => esc_html__('Post', 'posolo'),
                            'value' => 'post',
                        ),
                        array(
                            'label' => esc_html__('Page', 'posolo'),
                            'value' => 'page',
                        ),
                        array(
                            'label' => esc_html__('Product', 'posolo'),
                            'value' => 'product'
                        ),
                    ),
                    'desc' => esc_html__('You can show/hide share box on post, page, product pages. ', 'posolo'),
                ),
                array(
                    'id' => 'post_single_share_list',
                    'label' => esc_html__('Add custom share box', 'posolo'),
                    'type' => 'list-item',
                    'section' => 'option_basic',
                    'std' => '',
                    'settings' => array(
                        array(
                            'id' => 'social',
                            'label' => esc_html__('Social', 'posolo'),
                            'type' => 'select',
                            'std' => 'h3',
                            'options' => array(
                                'total' => esc_html__('Total share', 'posolo'),
                                'facebook' => esc_html__('Facebook', 'posolo'),
                                'twitter' => esc_html__('Twitter', 'posolo'),
                                'google' => esc_html__('Google plus', 'posolo'),
                                'linkedin' => esc_html__('Linkedin', 'posolo'),
                                'pinterest' => esc_html__('Pinterest', 'posolo'),
                                'tumblr' => esc_html__('Tumblr', 'posolo'),
                                'envelope' => esc_html__('Mail', 'posolo'),
                            )
                        ),
                        array(
                            'id' => 'number',
                            'label' => esc_html__('Show number', 'posolo'),
                            'type' => 'on-off',
                            'std' => 'on',
                        ),
                    ),
                ),
                array(
                    'id' => 'disable_verify_notice',
                    'label' => esc_html__('Disable Verify Menu', 'posolo'),
                    'type' => 'on-off',
                    'std' => 'off',
                    'section' => 'option_basic',
                ),

                /*----------------End Basic ----------------------*/

                /*----------------Begin Menu --------------------*/
                array(
                    'id' => 'sv_menu_color',
                    'label' => esc_html__('Menu style', 'posolo'),
                    'type' => 'typography',
                    'section' => 'option_menu',
                ),
                array(
                    'id' => 'sv_menu_color_hover',
                    'label' => esc_html__('Hover color', 'posolo'),
                    'desc' => esc_html__('Choose color', 'posolo'),
                    'type' => 'colorpicker-opacity',
                    'section' => 'option_menu',
                ),
                array(
                    'id' => 'sv_menu_color_active',
                    'label' => esc_html__('Background Hover color', 'posolo'),
                    'desc' => esc_html__('Choose color', 'posolo'),
                    'type' => 'colorpicker-opacity',
                    'section' => 'option_menu',
                ),
                array(
                    'id' => 'sv_menu_color2',
                    'label' => esc_html__('Menu Sub style', 'posolo'),
                    'type' => 'typography',
                    'section' => 'option_menu',
                ),
                array(
                    'id' => 'sv_menu_color_hover2',
                    'label' => esc_html__('Hover Sub color', 'posolo'),
                    'desc' => esc_html__('Choose color', 'posolo'),
                    'type' => 'colorpicker-opacity',
                    'section' => 'option_menu',
                ),
                array(
                    'id' => 'sv_menu_color_active2',
                    'label' => esc_html__('Background Sub Hover color', 'posolo'),
                    'desc' => esc_html__('Choose color', 'posolo'),
                    'type' => 'colorpicker-opacity',
                    'section' => 'option_menu',
                ),
                /*----------------End Menu ----------------------*/

                /*----------------Begin Blog + Post --------------------*/
                array(
                    'id' => 'tab_blog_general',
                    'type' => 'tab',
                    'section' => 'blog_post',
                    'label' => esc_html__('General', 'posolo')
                ),
                array(
                    'id' => 'before_append_post',
                    'label' => esc_html__('Append content before post/blog/archive page', 'posolo'),
                    'type' => 'select',
                    'section' => 'blog_post',
                    'options' => tech888f_list_post_type('tech888f_mega_item'),
                    'desc' => esc_html__('Choose a mega page content append to before main content of post/blog/archive page.', 'posolo'),
                ),
                array(
                    'id' => 'after_append_post',
                    'label' => esc_html__('Append content after post/blog/archive page', 'posolo'),
                    'type' => 'select',
                    'section' => 'blog_post',
                    'options' => tech888f_list_post_type('tech888f_mega_item'),
                    'desc' => esc_html__('Choose a mega page content append to after main content of post/blog/archive page.', 'posolo'),
                ),
                array(
                    'id' => 'tech888f_sidebar_position_blog',
                    'label' => esc_html__('Sidebar Blog', 'posolo'),
                    'type' => 'select',
                    'section' => 'blog_post',
                    'desc' => esc_html__('Set sidebar position for your blog page. Left, Right, or No sidebar.', 'posolo'),
                    'options' => array(
                        'no' => esc_html__('No Sidebar', 'posolo'),
                        'left' => esc_html__('Left Sidebar', 'posolo'),
                        'right' => esc_html__('Right Sidebar', 'posolo'),
                    )
                ),
                array(
                    'id' => 'tech888f_sidebar_blog',
                    'label' => esc_html__('Sidebar select display in blog', 'posolo'),
                    'type' => 'sidebar-select',
                    'section' => 'blog_post',
                    'condition' => 'tech888f_sidebar_position_blog:not(no)',
                    'desc' => esc_html__('Choose a sidebar to display.', 'posolo'),
                ),
                array(
                    'id' => 'blog_default_style',
                    'label' => esc_html__('Default style', 'posolo'),
                    'type' => 'select',
                    'section' => 'blog_post',
                    'desc' => esc_html__('Choose a style to active display', 'posolo'),
                    'options' => array(
                        'list' => esc_html__('List', 'posolo'),
                        'grid' => esc_html__('Grid', 'posolo'),
                    )
                ),
                array(
                    'id' => 'blog_style',
                    'label' => esc_html__('Blog pagination', 'posolo'),
                    'type' => 'select',
                    'section' => 'blog_post',
                    'desc' => esc_html__('Choose a style to active display', 'posolo'),
                    'options' => array(
                        '' => esc_html__('Default', 'posolo'),
                        'load-more' => esc_html__('Load more Button', 'posolo'),
                    )
                ),
                array(
                    'id' => 'blog_number_filter',
                    'label' => esc_html__('Show number filter', 'posolo'),
                    'desc' => 'Show/hide number filter on blog page.',
                    'type' => 'on-off',
                    'section' => 'blog_post',
                    'std' => 'on',
                ),
                array(
                    'id' => 'blog_number_filter_list',
                    'label' => esc_html__('Add list number filter', 'posolo'),
                    'type' => 'list-item',
                    'section' => 'blog_post',
                    'desc' => esc_html__('Add custom list number to filter on the blog page.', 'posolo'),
                    'settings' => array(
                        array(
                            'id' => 'number',
                            'label' => esc_html__('Number', 'posolo'),
                            'type' => 'text',
                        ),
                    ),
                    'condition' => 'blog_number_filter:not(off)',
                ),
                array(
                    'id' => 'blog_type_filter',
                    'label' => esc_html__('Show type filter', 'posolo'),
                    'desc' => 'Show/hide type filter(list/grid) on blog page.',
                    'type' => 'on-off',
                    'section' => 'blog_post',
                    'std' => 'on',
                ),
                array(
                    'id' => 'post_thumbnail_default',
                    'label' => esc_html__('Post Thumbnail Default', 'posolo'),
                    'type' => 'upload',
                    'section' => 'blog_post',
                    'desc' => esc_html__('Choose post thumbnail default.', 'posolo'),
                ),
                //Tab list
                array(
                    'id' => 'tab_blog_list',
                    'type' => 'tab',
                    'section' => 'blog_post',
                    'label' => esc_html__('List Settings', 'posolo')
                ),
                array(
                    'id' => 'post_list_size',
                    'label' => esc_html__('Custom list thumbnail size', 'posolo'),
                    'type' => 'text',
                    'section' => 'blog_post',
                    'desc' => esc_html__('Enter size thumbnail to crop. [width]x[height]. Example is 300x300.', 'posolo')
                ),
                array(
                    'id' => 'post_list_item_style',
                    'label' => esc_html__('Blog List item style', 'posolo'),
                    'type' => 'select',
                    'section' => 'blog_post',
                    'desc' => esc_html__('Choose a style to active display', 'posolo'),
                    'std' => '',
                    'options' => tech888f_get_post_list_style('option')
                ),
                //Tab grid
                array(
                    'id' => 'tab_blog_grid',
                    'type' => 'tab',
                    'section' => 'blog_post',
                    'label' => esc_html__('Grid Settings', 'posolo')
                ),
                array(
                    'id' => 'post_grid_column',
                    'label' => esc_html__('Grid column', 'posolo'),
                    'type' => 'select',
                    'section' => 'blog_post',
                    'std' => '3',
                    'desc' => esc_html__('Choose a style to active display', 'posolo'),
                    'options' => array(
                        '2' => esc_html__('2 columns', 'posolo'),
                        '3' => esc_html__('3 columns', 'posolo'),
                        '4' => esc_html__('4 columns', 'posolo'),
                        '5' => esc_html__('5 columns', 'posolo'),
                        '6' => esc_html__('6 columns', 'posolo'),
                    )
                ),
                array(
                    'id' => 'post_grid_size',
                    'label' => esc_html__('Custom grid thumbnail size', 'posolo'),
                    'type' => 'text',
                    'section' => 'blog_post',
                    'desc' => esc_html__('Enter size thumbnail to crop. [width]x[height]. Example is 300x300.', 'posolo')
                ),
                array(
                    'id' => 'post_grid_excerpt',
                    'label' => esc_html__('Grid Sub string excerpt', 'posolo'),
                    'type' => 'text',
                    'section' => 'blog_post',
                    'std' => '80',
                    'desc' => esc_html__('Enter number of character want to get from excerpt content. Default is 0(hidden). Example is 80. Note: This value only apply for items style can be show excerpt.', 'posolo')
                ),
                array(
                    'id' => 'post_grid_item_style',
                    'label' => esc_html__('Grid item style', 'posolo'),
                    'type' => 'select',
                    'section' => 'blog_post',
                    'desc' => esc_html__('Choose a style to active display', 'posolo'),
                    'options' => tech888f_get_post_style('option')
                ),
                array(
                    'id' => 'post_grid_type',
                    'label' => esc_html__('Grid display', 'posolo'),
                    'type' => 'select',
                    'section' => 'blog_post',
                    'desc' => esc_html__('Choose a style to active display', 'posolo'),
                    'options' => array(
                        '' => 'Default',
                        'list-masonry' => 'Masory',
                    )
                ),
                //Post detail
                array(
                    'id' => 'tab_blog_post_detail',
                    'type' => 'tab',
                    'section' => 'blog_post',
                    'label' => esc_html__('Post detail Settings', 'posolo')
                ),

                array(
                    'id' => 'tech888f_post_detail_style',
                    'label' => esc_html__('Post style', 'posolo'),
                    'type' => 'select',
                    'section' => 'blog_post',
                    'desc' => esc_html__('Choose style to display.', 'posolo'),
                    'options' => array(
                        '' => esc_html__('Default', 'posolo'),
                        'style2' => esc_html__('Style 2', 'posolo')
                    )
                ),

                array(
                    'id' => 'tech888f_sidebar_position_post',
                    'label' => esc_html__('Sidebar Single Post', 'posolo'),
                    'type' => 'select',
                    'section' => 'blog_post',
                    'desc' => esc_html__('Set sidebar position for your post detail page. Left, Right, or No sidebar.', 'posolo'),
                    'options' => array(
                        'no' => 'No Sidebar',
                        'left' => 'Left Sidebar',
                        'right' => 'Right Sidebar'
                    )
//                    'options'     => array(
//                        array(
//                            'value'=>'no',
//                            'label'=>esc_html__('No Sidebar','posolo'),
//                        ),
//                        array(
//                            'value'=>'left',
//                            'label'=>esc_html__('Left','posolo'),
//                        ),
//                        array(
//                            'value'=>'right',
//                            'label'=>esc_html__('Right','posolo'),
//                        )
//                    )
                ),
                array(
                    'id' => 'tech888f_sidebar_post',
                    'label' => esc_html__('Sidebar select display in single post', 'posolo'),
                    'type' => 'sidebar-select',
                    'section' => 'blog_post',
                    'condition' => 'tech888f_sidebar_position_post:not(no)',
                    'desc' => esc_html__('Choose a sidebar to display.', 'posolo'),
                ),
                array(
                    'id' => 'post_single_thumbnail',
                    'label' => esc_html__('Show thumbnail/media', 'posolo'),
                    'desc' => 'Show/hide thumbnail image, gallery, media on post detail.',
                    'type' => 'on-off',
                    'section' => 'blog_post',
                    'std' => 'on',
                ),
                array(
                    'id' => 'post_single_size',
                    'label' => esc_html__('Custom single image size', 'posolo'),
                    'type' => 'text',
                    'section' => 'blog_post',
                    'desc' => esc_html__('Enter size thumbnail to crop. [width]x[height]. Example is 300x300.', 'posolo'),
                    'condition' => 'post_single_thumbnail:is(on)',
                ),
                array(
                    'id' => 'post_single_meta',
                    'label' => esc_html__('Show meta data', 'posolo'),
                    'desc' => 'Show/hide meta data(author, date, comments, categories, tags) on post detail.',
                    'type' => 'on-off',
                    'section' => 'blog_post',
                    'std' => 'on',
                ),
                array(
                    'id' => 'post_single_author',
                    'label' => esc_html__('Show author box', 'posolo'),
                    'desc' => 'Show/hide author box on post detail.',
                    'type' => 'on-off',
                    'section' => 'blog_post',
                    'std' => 'on',
                ),
                array(
                    'id' => 'post_single_navigation',
                    'label' => esc_html__('Show navigation post', 'posolo'),
                    'desc' => 'Show/hide navigation to next post or previous post on the post detail.',
                    'type' => 'on-off',
                    'section' => 'blog_post',
                    'std' => 'on',
                ),
                // Related section
                array(
                    'id' => 'post_single_related',
                    'label' => esc_html__('Show related post', 'posolo'),
                    'desc' => 'Show/hide related post on the post detail.',
                    'type' => 'on-off',
                    'section' => 'blog_post',
                    'std' => 'on',
                ),
                array(
                    'id' => 'post_single_related_title',
                    'label' => esc_html__('Related title', 'posolo'),
                    'desc' => 'Enter title of related section.',
                    'type' => 'text',
                    'section' => 'blog_post',
                    'condition' => 'post_single_related:is(on)',
                ),
                array(
                    'id' => 'post_single_related_number',
                    'label' => esc_html__('Related number post', 'posolo'),
                    'desc' => 'Enter number of related post to display.',
                    'type' => 'text',
                    'section' => 'blog_post',
                    'condition' => 'post_single_related:is(on)',
                ),
                array(
                    'id' => 'post_single_related_item',
                    'label' => esc_html__('Related custom number item responsive', 'posolo'),
                    'desc' => 'Enter item for screen width(px) format is width:value and separate values by ",". Example is 0:2,600:3,1000:4. Default is auto.',
                    'type' => 'text',
                    'section' => 'blog_post',
                    'condition' => 'post_single_related:is(on)',
                ),
                array(
                    'id' => 'post_single_related_item_style',
                    'label' => esc_html__('Related item style', 'posolo'),
                    'type' => 'select',
                    'section' => 'blog_post',
                    'desc' => esc_html__('Choose a style to active display', 'posolo'),
                    'choices' => tech888f_get_post_style('option'),
                    'condition' => 'post_single_related:is(on)',
                ),
                // End related

                /*----------------End Blog + Post ----------------------*/

                /*----------------Begin Layout --------------------*/
                array(
                    'id' => 'tech888f_sidebar_position_page',
                    'label' => esc_html__('Sidebar Page', 'posolo'),
                    'type' => 'select',
                    'section' => 'option_layout',
                    'desc' => esc_html__('Set sidebar position for your default page. Left, Right, or No sidebar.', 'posolo'),
                    'options' => array(
                        'no' => esc_html__('No Sidebar', 'posolo'),
                        'left' => esc_html__('Left', 'posolo'),
                        'right' => esc_html__('Right', 'posolo'),
                    )
                ),
                array(
                    'id' => 'tech888f_sidebar_page',
                    'label' => esc_html__('Sidebar select display in page', 'posolo'),
                    'type' => 'sidebar-select',
                    'section' => 'option_layout',
                    'condition' => 'tech888f_sidebar_position_page:not(no)',
                    'desc' => esc_html__('Choose a sidebar to display.', 'posolo'),
                ),
                /****end page****/
                array(
                    'id' => 'tech888f_sidebar_position_page_archive',
                    'label' => esc_html__('Sidebar Position on Page Archives:', 'posolo'),
                    'type' => 'select',
                    'section' => 'option_layout',
                    'desc' => esc_html__('Set sidebar position for your archives page(category/tag/author page...). Left, Right, or No sidebar.', 'posolo'),
                    'options' => array(
                        'no' => esc_html__('No Sidebar', 'posolo'),
                        'left' => esc_html__('Left', 'posolo'),
                        'right' => esc_html__('Right', 'posolo'),
                    )
                ),
                array(
                    'id' => 'tech888f_sidebar_page_archive',
                    'label' => esc_html__('Sidebar select display in page Archives', 'posolo'),
                    'type' => 'sidebar-select',
                    'section' => 'option_layout',
                    'condition' => 'tech888f_sidebar_position_page_archive:not(no)',
                    'desc' => esc_html__('Choose a sidebar to display.', 'posolo'),
                ),
                array(
                    'id' => 'tech888f_sidebar_position_page_search',
                    'label' => esc_html__('Sidebar Position on search page:', 'posolo'),
                    'type' => 'select',
                    'section' => 'option_layout',
                    'desc' => esc_html__('Set sidebar position for your search page. Left, Right, or No sidebar.', 'posolo'),
                    'options' => array(
                        'no' => esc_html__('No Sidebar', 'posolo'),
                        'left' => esc_html__('Left', 'posolo'),
                        'right' => esc_html__('Right', 'posolo'),
                    )
                ),
                array(
                    'id' => 'tech888f_sidebar_page_search',
                    'label' => esc_html__('Sidebar select display in page Archives', 'posolo'),
                    'type' => 'sidebar-select',
                    'section' => 'option_layout',
                    'condition' => 'tech888f_sidebar_position_page_search:not(no)',
                    'desc' => esc_html__('Choose a sidebar to display.', 'posolo'),
                ),
                // END
                /*----------------End Layout ----------------------*/

                /*----------------Begin Blog ----------------------*/


                /*----------------End BLOG----------------------*/

                /*----------------Begin Typography ----------------------*/
                array(
                    'id' => 'tech888f_custom_typography',
                    'label' => esc_html__('Add Settings', 'posolo'),
                    'type' => 'list-item',
                    'section' => 'option_typography',
                    'std' => '',
                    'settings' => array(
                        array(
                            'id' => 'typo_area',
                            'label' => esc_html__('Choose Area to style', 'posolo'),
                            'type' => 'select',
                            'std' => 'main',
                            'options' => array(
                                'body' => esc_html__('Body', 'posolo'),
                                'header' => esc_html__('Header', 'posolo'),
                                'header' => esc_html__('Main Content', 'posolo'),
                                'widget' => esc_html__('Widget', 'posolo'),
                                'footer' => esc_html__('Footer', 'posolo'),
                            )
                        ),
                        array(
                            'id' => 'typo_heading',
                            'label' => esc_html__('Choose heading Area', 'posolo'),
                            'type' => 'select',
                            'std' => '',
                            'options' => array(
                                '' => esc_html__('All', 'posolo'),
                                'h1' => esc_html__('H1', 'posolo'),
                                'h2' => esc_html__('H2', 'posolo'),
                                'h3' => esc_html__('H3', 'posolo'),
                                'h4' => esc_html__('H4', 'posolo'),
                                'h5' => esc_html__('H5', 'posolo'),
                            )
                        ),
                        array(
                            'id' => 'typography_style',
                            'label' => esc_html__('Add Style', 'posolo'),
                            'type' => 'typography',
                            'section' => 'option_typography',
                        ),
                    ),
                ),
                /*----------------End Typography ----------------------*/
                /*----------------Begin Lazy Script ----------------------*/
                array(
                    'id' => 'tech888f_lazy_script',
                    'label' => esc_html__('Lazy script', 'posolo'),
                    'type' => 'textarea',
                    'section' => 'option_lazyscript',
                    'desc' => esc_html__('Lazy script put here. Script will be loaded after 2 second after page loaded', 'posolo'),
                ),
                /*----------------Begin Lazy Script ----------------------*/
            )
        );
        if (class_exists('WooCommerce')) {
            // Add woo sections
            $woo_sections = array(
                array(
                    'id' => 'option_woo',
                    'title' => '<i class="fa fa-shopping-cart"></i>' . esc_html__(' Shop Settings', 'posolo')
                ),
                array(
                    'id' => 'option_product',
                    'title' => '<i class="fa fa-th-large"></i>' . esc_html__(' Product Settings', 'posolo')
                )
            );
            $tech888f_config['theme-option']['sections'] = array_merge($tech888f_config['theme-option']['sections'], $woo_sections);
            // End add sections

            // Add woo setting
            $woo_settings = array(
                array(
                    'id' => 'tab_shop_general',
                    'type' => 'tab',
                    'section' => 'option_woo',
                    'label' => esc_html__('General', 'posolo')
                ),
                array(
                    'id' => 'tech888f_sidebar_position_woo',
                    'label' => esc_html__('Sidebar Position WooCommerce page', 'posolo'),
                    'type' => 'select',
                    'section' => 'option_woo',
                    'desc' => esc_html__('Set sidebar position for your woocommerce page(Shop, Checkout, Cart, My Account, Product category/tag/taxonomy page...). Left, Right, or No sidebar.', 'posolo'),
                    'options' => array(
                        'no' => esc_html__('No', 'posolo'),
                        'left' => esc_html__('Left', 'posolo'),
                        'right' => esc_html__('Right', 'posolo')
                    )
                ),
                array(
                    'id' => 'tech888f_sidebar_woo',
                    'label' => esc_html__('Sidebar select WooCommerce page', 'posolo'),
                    'type' => 'sidebar-select',
                    'section' => 'option_woo',
                    'condition' => 'tech888f_sidebar_position_woo:not(no)',
                    'desc' => esc_html__('Choose one style of sidebar for WooCommerce page', 'posolo'),

                ),
                array(
                    'id' => 'shop_default_style',
                    'label' => esc_html__('Shop Default Item Style', 'posolo'),
                    'type' => 'select',
                    'section' => 'option_woo',
                    'desc' => esc_html__('Choose a style to active display', 'posolo'),
                    'options' => array(
                        'grid' => esc_html__('Grid', 'posolo'),
                        'list' => esc_html__('List', 'posolo'),
                    )
                ),
                array(
                    'id' => 'shop_gap_product',
                    'label' => esc_html__('Gap Products', 'posolo'),
                    'type' => 'select',
                    'section' => 'option_woo',
                    'desc' => esc_html__('Choose space. The space between the items on the shop page.', 'posolo'),
                    'options' => array(
                        'gap-0' => esc_html__('0', 'posolo'),
                        'gap-5' => esc_html__('5px', 'posolo'),
                        'gap-10' => esc_html__('10px', 'posolo'),
                        'gap-15' => esc_html__('15px', 'posolo'),
                        'gap-20' => esc_html__('20px', 'posolo'),

                    )
                ),
                array(
                    'id' => 'woo_shop_number',
                    'label' => esc_html__('Product Number', 'posolo'),
                    'type' => 'text',
                    'section' => 'option_woo',
                    'std' => '12',
                    'desc' => esc_html__('Enter number product to display per page. Default is 12.', 'posolo')
                ),
                array(
                    'id' => 'sv_set_time_woo',
                    'label' => esc_html__('Product new in(days)', 'posolo'),
                    'type' => 'text',
                    'section' => 'option_woo',
                    'desc' => esc_html__('Enter number to set time for product is new. Unit day. Default is 30.', 'posolo')
                ),
                array(
                    'id' => 'shop_style',
                    'label' => esc_html__('Shop pagination', 'posolo'),
                    'type' => 'select',
                    'section' => 'option_woo',
                    'desc' => esc_html__('Choose a style to active display', 'posolo'),
                    'choices' => array(
                        array(
                            'value' => '',
                            'label' => esc_html__('Default', 'posolo'),
                        ),
                        array(
                            'value' => 'load-more',
                            'label' => esc_html__('Load more', 'posolo'),
                        )
                    )
                ),
                array(
                    'id' => 'shop_ajax',
                    'label' => esc_html__('Shop ajax', 'posolo'),
                    'type' => 'on-off',
                    'section' => 'option_woo',
                    'std' => 'off',
                    'desc' => esc_html__('Enable ajax process for your shop page.', 'posolo'),
                ),
                array(
                    'id' => 'shop_thumb_animation',
                    'label' => esc_html__('Thumbnail animation', 'posolo'),
                    'type' => 'select',
                    'section' => 'option_woo',
                    'desc' => esc_html__('Choose a animation.', 'posolo'),
                    'choices' => tech888f_get_product_thumb_animation('option')
                ),
                array(
                    'id' => 'shop_number_filter',
                    'label' => esc_html__('Show number filter', 'posolo'),
                    'desc' => 'Show/hide number filter on shop page.',
                    'type' => 'on-off',
                    'section' => 'option_woo',
                    'std' => 'on',
                ),
                array(
                    'id' => 'shop_number_filter_list',
                    'label' => esc_html__('Add list number filter', 'posolo'),
                    'type' => 'list-item',
                    'section' => 'option_woo',
                    'desc' => esc_html__('Add custom list number to filter on the shop page.', 'posolo'),
                    'settings' => array(
                        array(
                            'id' => 'number',
                            'label' => esc_html__('Number', 'posolo'),
                            'type' => 'text',
                        ),
                    ),
                    'condition' => 'blog_number_filter:not(off)',
                ),
                array(
                    'id' => 'shop_type_filter',
                    'label' => esc_html__('Show type filter', 'posolo'),
                    'desc' => 'Show/hide type filter(list/grid) on shop page.',
                    'type' => 'on-off',
                    'section' => 'option_woo',
                    'std' => 'on',
                ),
                //Tab list
                array(
                    'id' => 'tab_shop_list',
                    'type' => 'tab',
                    'section' => 'option_woo',
                    'label' => esc_html__('List Settings', 'posolo')
                ),

                array(
                    'id' => 'shop_list_size',
                    'label' => esc_html__('Custom list thumbnail size', 'posolo'),
                    'type' => 'text',
                    'section' => 'option_woo',
                    'desc' => esc_html__('Enter size thumbnail to crop. [width]x[height]. Example is 300x300.', 'posolo')
                ),
                array(
                    'id' => 'shop_list_item_style',
                    'label' => esc_html__('Shop List item style', 'posolo'),
                    'type' => 'select',
                    'section' => 'option_woo',
                    'desc' => esc_html__('Choose a style to active display', 'posolo'),
                    'options' => tech888f_get_product_list_style('option')
                ),
                //Tab grid
                array(
                    'id' => 'tab_shop_grid',
                    'type' => 'tab',
                    'section' => 'option_woo',
                    'label' => esc_html__('Grid Settings', 'posolo')
                ),
                array(
                    'id' => 'shop_grid_column',
                    'label' => esc_html__('Grid column', 'posolo'),
                    'type' => 'select',
                    'section' => 'option_woo',
                    'std' => '3',
                    'desc' => esc_html__('Choose a style to active display', 'posolo'),
                    'options' => array(
                        '2' => esc_html__('2 columns', 'posolo'),
                        '3' => esc_html__('3 columns', 'posolo'),
                        '4' => esc_html__('4 columns', 'posolo'),
                        '5' => esc_html__('5 columns', 'posolo'),
                    )
                ),
                array(
                    'id' => 'shop_grid_size',
                    'label' => esc_html__('Custom grid thumbnail size', 'posolo'),
                    'type' => 'text',
                    'section' => 'option_woo',
                    'desc' => esc_html__('Enter size thumbnail to crop. [width]x[height]. Example is 300x300.', 'posolo')
                ),
                array(
                    'id' => 'shop_grid_item_style',
                    'label' => esc_html__('Grid item style', 'posolo'),
                    'type' => 'select',
                    'section' => 'option_woo',
                    'desc' => esc_html__('Choose a style to active display', 'posolo'),
                    'options' => tech888f_get_product_style('option')
                ),
                array(
                    'id' => 'shop_grid_type',
                    'label' => esc_html__('Grid display', 'posolo'),
                    'type' => 'select',
                    'section' => 'option_woo',
                    'desc' => esc_html__('Choose a style to active display', 'posolo'),
                    'options' => array(
                        '' => 'Default',
                        'list-masonry' => 'Masonry',
                    )
                ),
                array(
                    'id' => 'tab_shop_advanced',
                    'type' => 'tab',
                    'section' => 'option_woo',
                    'label' => esc_html__('Advanced', 'posolo')
                ),
                array(
                    'id' => 'cart_page_style',
                    'label' => esc_html__('Cart display', 'posolo'),
                    'type' => 'select',
                    'section' => 'option_woo',
                    'desc' => esc_html__('Choose a style to active display', 'posolo'),
                    'options' => array(
                        '' => esc_html__('Default', 'posolo'),
                        'style2' => esc_html__('Style 2', 'posolo'),
                    )
                ),
                array(
                    'id' => 'checkout_page_style',
                    'label' => esc_html__('Checkout display', 'posolo'),
                    'type' => 'select',
                    'section' => 'option_woo',
                    'desc' => esc_html__('Choose a style to active display', 'posolo'),
                    'options' => array(
                        '' => esc_html__('Default', 'posolo'),
                        'style2' => esc_html__('Style 2', 'posolo'),
                    )
                ),
                array(
                    'id' => 'tech888f_header_page_woo',
                    'label' => esc_html__('Header Woocommerce Page', 'posolo'),
                    'desc' => esc_html__('Include Header content. Go to Header in admin menu to edit/create header content. Note this value default for all pages of your site, If have any page/single page display other content pehaps you are set specific header for it', 'posolo'),
                    'type' => 'select',
                    'section' => 'option_woo',
                    'options' => tech888f_list_post_type('tech888f_header')
                ),
                array(
                    'id' => 'tech888f_footer_page_woo',
                    'label' => esc_html__('Footer Woocommerce Page', 'posolo'),
                    'desc' => esc_html__('Include Footer content. Go to Footer in admin menu to edit/create footer content.  Note this value default for all pages of your site, If have any page/single page display other content pehaps you are set specific footer for it', 'posolo'),
                    'type' => 'select',
                    'section' => 'option_woo',
                    'options' => tech888f_list_post_type('tech888f_footer')
                ),
                array(
                    'id' => 'before_append_woo',
                    'label' => esc_html__('Append content before Woocommerce page', 'posolo'),
                    'type' => 'select',
                    'section' => 'option_woo',
                    'options' => tech888f_list_post_type('tech888f_mega_item'),
                    'desc' => esc_html__('Choose a mega page content append to before main content of page/post.', 'posolo'),
                ),
                array(
                    'id' => 'after_append_woo',
                    'label' => esc_html__('Append content after Woocommerce page', 'posolo'),
                    'type' => 'select',
                    'section' => 'option_woo',
                    'options' => tech888f_list_post_type('tech888f_mega_item'),
                    'desc' => esc_html__('Choose a mega page content append to after main content of page/post.', 'posolo'),
                ),
                // END Shop config
                array(
                    'id' => 'tab_product_general',
                    'type' => 'tab',
                    'section' => 'option_product',
                    'label' => esc_html__('General', 'posolo')
                ),
                array(
                    'id' => 'sv_sidebar_position_woo_single',
                    'label' => esc_html__('Sidebar Position WooCommerce Single', 'posolo'),
                    'type' => 'select',
                    'section' => 'option_product',
                    'desc' => esc_html__('Left, or Right, or Center', 'posolo'),
                    'std' => 'no',
                    'options' => array(
                        'no' => esc_html__('No Sidebar', 'posolo'),
                        'left' => esc_html__('Left Sidebar', 'posolo'),
                        'right' => esc_html__('Right Sidebar', 'posolo'),
                    )
                ),
                array(
                    'id' => 'sv_sidebar_woo_single',
                    'label' => esc_html__('Sidebar select WooCommerce Single', 'posolo'),
                    'type' => 'sidebar-select',
                    'section' => 'option_product',
                    'condition' => 'sv_sidebar_position_woo_single:not(no)',
                    'desc' => esc_html__('Choose one style of sidebar for WooCommerce page', 'posolo'),
                ),
                array(
                    'id' => 'product_tab_detail',
                    'label' => esc_html__('Product tab style', 'posolo'),
                    'type' => 'select',
                    'section' => 'option_product',
                    'desc' => esc_html__('Choose a style to display', 'posolo'),
                    'options' => array(
                        'tab-normal' => esc_html__("Normal", 'posolo'),
                        'tab-style2' => esc_html__("Tab style 2", 'posolo'),
                    )
                ),
                array(
                    'id' => 'show_excerpt',
                    'label' => esc_html__('Show Excerpt', 'posolo'),
                    'type' => 'on-off',
                    'section' => 'option_product',
                    'std' => 'on'
                ),
                array(
                    'id' => 'tab_product_extra',
                    'type' => 'tab',
                    'section' => 'option_product',
                    'label' => esc_html__('Extra display', 'posolo')
                ),
                array(
                    'id' => 'show_latest',
                    'label' => esc_html__('Show latest products', 'posolo'),
                    'type' => 'on-off',
                    'section' => 'option_product',
                    'std' => 'on'
                ),
                array(
                    'id' => 'show_upsell',
                    'label' => esc_html__('Show upsell products', 'posolo'),
                    'type' => 'on-off',
                    'section' => 'option_product',
                    'std' => 'on'
                ),
                array(
                    'id' => 'show_related',
                    'label' => esc_html__('Show related products', 'posolo'),
                    'type' => 'on-off',
                    'section' => 'option_product',
                    'std' => 'on'
                ),
                array(
                    'id' => 'show_single_number',
                    'label' => esc_html__('Show Single Number', 'posolo'),
                    'type' => 'numeric-slider',
                    'min_max_step' => '1,100,1',
                    'section' => 'option_product',
                    'std' => '6'
                ),
                array(
                    'id' => 'show_single_size',
                    'label' => esc_html__('Show Single Size', 'posolo'),
                    'type' => 'text',
                    'section' => 'option_product',
                    'desc' => esc_html__('Custom size for related,upsell products. Enter size thumbnail to crop. [width]x[height]. Example is 300x300.', 'posolo'),
                ),
                array(
                    'id' => 'show_single_itemres',
                    'label' => esc_html__('Custom item devices', 'posolo'),
                    'type' => 'text',
                    'section' => 'option_product',
                    'desc' => esc_html__('Enter item for screen width(px) format is width:value and separate values by ",". Example is 0:2,600:3,1000:4. Default is auto.', 'posolo'),
                ),
                array(
                    'id' => 'show_single_item_style',
                    'label' => esc_html__('Single item style', 'posolo'),
                    'type' => 'select',
                    'section' => 'option_product',
                    'desc' => esc_html__('Choose a style to active display', 'posolo'),
                    'options' => tech888f_get_product_style('option')
                ),
                array(
                    'id' => 'tab_product_advanced',
                    'type' => 'tab',
                    'section' => 'option_product',
                    'label' => esc_html__('Advanced', 'posolo')
                ),
                array(
                    'id' => 'before_append_woo_single',
                    'label' => esc_html__('Append content before product page', 'posolo'),
                    'type' => 'select',
                    'section' => 'option_product',
                    'options' => tech888f_list_post_type('tech888f_mega_item'),
                    'desc' => esc_html__('Choose a mega page content append to before main content of page/post.', 'posolo'),
                ),
                array(
                    'id' => 'before_append_tab',
                    'label' => esc_html__('Append content before product tab', 'posolo'),
                    'type' => 'select',
                    'section' => 'option_product',
                    'options' => tech888f_list_post_type('tech888f_mega_item'),
                    'desc' => esc_html__('Choose a mega page content append to before product tab.', 'posolo'),
                ),
                array(
                    'id' => 'after_append_tab',
                    'label' => esc_html__('Append content after product tab', 'posolo'),
                    'type' => 'select',
                    'section' => 'option_product',
                    'options' => tech888f_list_post_type('tech888f_mega_item'),
                    'desc' => esc_html__('Choose a mega page content append to before product tab.', 'posolo'),
                ),
                array(
                    'id' => 'after_append_woo_single',
                    'label' => esc_html__('Append content after product page', 'posolo'),
                    'type' => 'select',
                    'section' => 'option_product',
                    'options' => tech888f_list_post_type('tech888f_mega_item'),
                    'desc' => esc_html__('Choose a mega page content append to after main content of page/post.', 'posolo'),
                ),
            );
            $tech888f_config['theme-option']['settings'] = array_merge($tech888f_config['theme-option']['settings'], $woo_settings);
            // End add settings
        }

    }
}
tech888f_set_theme_config();