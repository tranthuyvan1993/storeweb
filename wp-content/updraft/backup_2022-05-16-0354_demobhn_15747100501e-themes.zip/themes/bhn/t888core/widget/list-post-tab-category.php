<?php

/**
 * Created by Sublime Text 2.
 * User: thanhhiep992
 * Date: 12/08/15
 * Time: 10:20 AM
 */

if (!class_exists('tech888f_ListPostsWidgeTabCategory')) {
    class tech888f_ListPostsWidgeTabCategory extends WP_Widget
    {


        protected $default = array();

        static function _init()
        {
            add_action('widgets_init', array(__CLASS__, '_add_widget'));
        }

        static function _add_widget()
        {
            tech888f_reg_widget('tech888f_ListPostsWidgeTabCategory');
        }

        function __construct()
        {
            // Instantiate the parent object
            parent::__construct(
                false,
                esc_html__('List Posts Tab', 'posolo'),
                array('description' => esc_html__('Get List Posts Tab for Elementor', 'posolo'))
            );

            $this->default = array(
                'title'             => esc_html__('List Posts', 'posolo'),
                'posts_per_page'    => 16,
                'category__in'      => array(),
                'order'             => 'desc',
                'order_by'          => 'date',
            );
        }


        function getcheckboxCategoryHierarchy($catId = 0, $taxonomy = "category", $bEchoList = false, $categories_checked = array())
        {

            $args = array(
                "hide_empty" => 0,
                "hierarchical" => 1,
                "taxonomy" => $taxonomy,
                "parent" => $catId
            );

            $categories = get_categories($args);
            if (count($categories) > 0) {

                if ($bEchoList) echo "<ul>";

                foreach ($categories as $category) {
                    if ($bEchoList)
                        $checked =  (in_array((string)$category->term_id, $categories_checked)) ? 'checked' : '';
                    echo "<li><input " . $checked . " type='checkbox' value='" . $category->term_id . "' name='" . esc_attr($this->get_field_name('category__in')) . "[]' /> " . $category->cat_name . "</li>";
                    $cats[$category->cat_ID]["category"] =  $category;

                    $children = $this->getcheckboxCategoryHierarchy($category->cat_ID, $taxonomy, $bEchoList, $categories_checked);
                    if ($children)
                        $cats[$category->cat_ID]["children"] = $children;
                }
                if ($bEchoList) echo "</ul>";
            }
            return $cats;
        }




        function widget($args, $instance)
        {
            // Widget output
            if (empty($size)) $size = array(250, 155);
            echo apply_filters('tech888f_output_content', $args['before_widget']);
            if (!empty($instance['title'])) {
                echo apply_filters('tech888f_output_content', $args['before_title']) . apply_filters('widget_title', $instance['title']) . $args['after_title'];
            }

            $instance = wp_parse_args($instance, $this->default);
            extract($instance);
            $args_post = array(
                'post_type'         => 'post',
                'posts_per_page'    => $posts_per_page,
                'orderby'           => $order_by,
                'order'             => $order,
            );
            $html = '';
            // open widget
            $html .=    '<div class="widget-content widget-post-tab">';
            if (!empty($category__in)) {
                // open ul title
                $html .= '<nav>';
                $html .= '<div class="nav nav-tabs">';
                foreach ($category__in as $cat) {
                    $active = ($cat == $category__in[0]) ? 'active' : '';
                    $cat_obj = get_term_by('id', $cat, 'category');
                    $html .= '<a href="#tab-' . $cat_obj->term_id . '" data-toggle="tab" class="nav-item nav-link '.$active.'">' . $cat_obj->name . '</a>';
                }
                // close ul title
                $html .= '</div>';
                $html .= '</nav>';
                // open tab content
                $html .= '<div class="tab-content">';
                foreach ($category__in as $cat) {
                    $active = ($cat == $category__in[0]) ? ' active in' : '';
                    $args_post['tax_query'] = array(
                        'relation' => "AND",
                        array(
                            'taxonomy' => 'category',
                            'field' => 'id',
                            'terms' => $cat
                        )
                    );
                    $post_query = new WP_Query($args_post);
                    $html .= '<div class="tab-pane flex-wrap flex-wrap-wrap fade '. $active .'" id="tab-' . $cat . '">';
                    if ($post_query->have_posts()) {
                        while ($post_query->have_posts()) {
                            $post_query->the_post();
                            $html .= '<div class="item-post">';
                            $html .= '<div class="item-post-inner">';
                            $html .= '<div class="post-thumb">';
                            $html .= '<a href="' . get_the_permalink() . '">';
                            $html .= get_the_post_thumbnail(get_the_ID(), array(400, 300));
                            $html .= '</a>';
                            $html .= '</div>';
                            $html .= '<div class="post-info">'; 
                            $html .= '<h3 class="post-title text-center title16 font-bold"><a href="' . get_the_permalink() . '">' . get_the_title() . '</a></h3>';
                            $html .= '</div>';
                            $html .= '</div>';
                            $html .= '</div>';
                        }
                    }
                    $html .= '</div>';
                    wp_reset_postdata();
                }
                // close tab content
                $html .= '</div>';
            }
            // close widget
            $html .=    '</div>';

            echo apply_filters('tech888f_output_content', $html);
            echo apply_filters('tech888f_output_content', $args['after_widget']);
        }

        function update($new_instance, $old_instance)
        {

            // Save widget options
            $instance = array();
            $instance = wp_parse_args($instance, $this->default);
            $new_instance = wp_parse_args($new_instance, $instance);

            return $new_instance;
        }

        function form($instance)
        {
            // Output admin widget options form

            $instance = wp_parse_args($instance, $this->default);

            extract($instance);

?>
            <p>
                <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'posolo'); ?></label>
                <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>">
            </p>
            <p>
                <label for="<?php echo esc_attr($this->get_field_id('posts_per_page')); ?>"><?php esc_html_e('Post Number:', 'posolo'); ?></label>
                <input class="widefat" id="<?php echo esc_attr($this->get_field_id('posts_per_page')); ?>" name="<?php echo esc_attr($this->get_field_name('posts_per_page')); ?>" type="text" value="<?php echo esc_attr($posts_per_page); ?>">
            </p>
            <p>
                <label for="<?php echo esc_attr($this->get_field_id('order_by')); ?>"><?php esc_html_e('Order By:', 'posolo'); ?></label>

                <select class="widefat" id="<?php echo esc_attr($this->get_field_id('order_by')); ?>" name="<?php echo esc_attr($this->get_field_name('order_by')); ?>">
                    <?php echo tech888f_get_order_list($order_by, array('post_view' => esc_html__('Post View', 'posolo')), 'option'); ?>
                </select>
            </p>
            <p>
                <label for="<?php echo esc_attr($this->get_field_id('order')); ?>"><?php esc_html_e('Order:', 'posolo'); ?></label>

                <select class="widefat" id="<?php echo esc_attr($this->get_field_id('order')); ?>" name="<?php echo esc_attr($this->get_field_name('order')); ?>">
                    <option <?php selected('desc', $order) ?> value="desc"><?php esc_html_e("DESC", "'posolo") ?>
                    </option>
                    <option <?php selected('asc', $order) ?> value="asc"><?php esc_html_e("ASC", "'posolo") ?></option>

                </select>
            </p>
            <p>
                <label for="<?php echo esc_attr($this->get_field_id('category__in')); ?>"><?php esc_html_e('Category:', 'posolo'); ?></label>
            <div class="radio-box">
                <?php
                $lst_cate = $this->getcheckboxCategoryHierarchy(0, 'category', true, $instance['category__in']);
                ?>
            </div>
            </p>
<?php
        }
    }

    tech888f_ListPostsWidgeTabCategory::_init();
}
