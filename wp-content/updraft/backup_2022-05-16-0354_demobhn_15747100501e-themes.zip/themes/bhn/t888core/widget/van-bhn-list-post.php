<?php

/**
 * Created by Sublime Text 2.
 * User: thanhhiep992
 * Date: 12/08/15
 * Time: 10:20 AM
 */

if (!class_exists('tech888f_ListPostsWidget_Bhn')) {
    class tech888f_ListPostsWidget_Bhn extends WP_Widget
    {
        protected $default = array();

        static function _init()
        {
            add_action('widgets_init', array(__CLASS__, '_add_widget'));
        }

        static function _add_widget()
        {
            tech888f_reg_widget('tech888f_ListPostsWidget_Bhn');
        }

        function __construct()
        {
            // Instantiate the parent object
            parent::__construct(
                false,
                esc_html__('List Posts BHN', 'posolo'),
                array('description' => esc_html__('Get List Posts by multiple format', 'posolo'),)
            );

            $this->default = array(
                'title'             => esc_html__('List Posts BHN', 'posolo'),
                'style'             => '',
                'posts_per_page'    => 5,
                'category'          => '',
                'order'             => 'desc',
                'order_by'          => 'date',
            );
        }



        function widget($args, $instance)
        {
            // Widget output



            $instance = wp_parse_args($instance, $this->default);
            extract($instance);
            switch ($style) {
                default:
                case '':
                    $size = array(792, 420);
                    echo apply_filters('tech888f_output_content', $args['before_widget']);
                    if (!empty($instance['title'])) {
                        echo apply_filters('tech888f_output_content', '<div class="box-title text-center"><h3 class="news-heading mb-0">') . apply_filters('widget_title', $instance['title']) . '</h3></div>';
                    }
                    $args_post = array(
                        'post_type'         => 'post',
                        'posts_per_page'    => $posts_per_page,
                        'orderby'           => $order_by,
                        'order'             => $order,
                    );
                    if (!empty($category)) {
                        $args_post['tax_query'][] = array(
                            'taxonomy' => 'category',
                            'field' => 'id',
                            'terms' => $category
                        );
                    }
                    $html = '';
                    $html .=    '<div class="news-left"><div class="row news-list">';
                    $html2 = '<div class="col-lg-8 news-list-left"><div class="row">';
                    $post_query = new WP_Query($args_post);
                    // var_dump($post_query);
                    if ($post_query->have_posts()) {
                        
                        while ($post_query->have_posts()) {
                            $post_query->the_post();
                            $html2 .= '<div class="col-6 news-item">
                                            <a href="' . esc_url(get_the_permalink()) . '" class="images-form">
                                            ' . get_the_post_thumbnail('', $size) . '                                                                       
                                            </a>
                                            <div class="content-form">
                                                <h5 class="news-title"> 
                                                    <a class="color-text-primary" href="' . esc_url(get_the_permalink()) . '" title="' . esc_attr(get_the_title()) . '">' . get_the_title() . '</a>
                                                </h5>
                                                    <p class="color-gray">' . esc_attr(get_the_content()) . '</p>
                                                    <p class="news-date">' . get_the_date('d M Y') . '</p> 
                                                    <a class="news-view-more" href="' . esc_url(get_the_permalink()) . '">'.esc_html__( 'Xem thêm', 'posolo' ).'</a>
                                            </div>
                                        </div>
                                    ';
                        }
                    }
                    $html2 .= ' </div></div>';
                    $html3 = '<div class="col-lg-4 news-list-right">';
                    if ($post_query->have_posts()) {
                        while ($post_query->have_posts()) {
                            $post_query->the_post();
                            $html3 .= '<div class="news-item news-item">
                                            <a href="' . esc_url(get_the_permalink()) . '" class="images-form">
                                            ' . get_the_post_thumbnail('', $size) . '                                                                       
                                            </a>
                                            <div class="content-form">
                                                <h5 class="news-title"> 
                                                    <a class="color-text-primary" href="' . esc_url(get_the_permalink()) . '" title="' . esc_attr(get_the_title()) . '">' . get_the_title() . '</a>
                                                </h5>
                                            </div>
                                        </div>
                                    ';
                        }
                    }
                    $html3 .= '</div></div>';
                    wp_reset_postdata();
                    echo apply_filters('tech888f_output_content', $html.$html2.$html3);
                    echo apply_filters('tech888f_output_content', $args['after_widget']);
                    break;
                case 'style2':
                    $size = array(300, 200);
                    echo apply_filters('tech888f_output_content', $args['before_widget']);
                    echo '<div class="widget-style2-title">';
                    if (!empty($instance['title'])) {
                        echo apply_filters('tech888f_output_content', $args['before_title']) . apply_filters('widget_title', $instance['title']) . $args['after_title'];
                    }
                    echo '</div>';
                    $args_post = array(
                        'post_type'         => 'post',
                        'posts_per_page'    => $posts_per_page,
                        'orderby'           => $order_by,
                        'order'             => $order,
                    );
                    if (!empty($category)) {
                        $args_post['tax_query'][] = array(
                            'taxonomy' => 'category',
                            'field' => 'id',
                            'terms' => $category
                        );
                    }
                    $html = '';
                    $html .=    '<div class="widget-content widget-latest-post style2">
                                    ';
                    $post_query = new WP_Query($args_post);
                    if ($post_query->have_posts()) {
                        while ($post_query->have_posts()) {
                            $post_query->the_post();
                            $html .= '<div class="item-wg-post flex-wrap flex-wrap-wrap">
                                        <div class="item-wg-post-inner">
                                            <div class="post-thumb banner-advs zoom-image overlay-image">
                                            <a href="' . esc_url(get_the_permalink()) . '" class="adv-thumb-link">
                                            ' . get_the_post_thumbnail('', $size) . '                                                                       
                                            </a>
                                            </div>
                                            <div class="post-info">
                                                <h3 class="title18 font-bold"><a class="color-title black000" href="' . esc_url(get_the_permalink()) . '" title="' . esc_attr(get_the_title()) . '">' . get_the_title() . '</a></h3>
                                                <span class="title14">' . get_the_date('d M Y') . '</span>
                                            </div>
                                        </div></div>';
                        }
                    }
                    $html .= ' </div>';
                    wp_reset_postdata();
                    $html .= '<div class="btn-readmore-wrap text-center"><a href="'.get_category_link($category).'" class="btn-readmore">'.esc_html__( 'Xem thêm', 'posolo' ).'</a></div>';
                    echo apply_filters('tech888f_output_content', $html);
                    echo apply_filters('tech888f_output_content', $args['after_widget']);
                    break;
            }
        }

        function update($new_instance, $old_instance)
        {

            // Save widget options
            $instance = array();
            $instance = wp_parse_args($instance, $this->default);
            $new_instance = wp_parse_args($new_instance, $instance);

            return $new_instance;
        }

        function form($instance)
        {
            // Output admin widget options form

            $instance = wp_parse_args($instance, $this->default);

            extract($instance);

?>
            <p>
                <label for="<?php echo esc_attr($this->get_field_id('title')); ?>"><?php esc_html_e('Title:', 'posolo'); ?></label>
                <input class="widefat" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($title); ?>">
            </p>
            <p>
                <label for="<?php echo esc_attr($this->get_field_id('style')); ?>"><?php esc_html_e('Style:', 'posolo'); ?></label>
                <select class="widefat" id="<?php echo esc_attr($this->get_field_id('style')); ?>" name="<?php echo esc_attr($this->get_field_name('style')); ?>">
                    <option <?php selected('', $style) ?> value=""><?php esc_html_e("Default", "'posolo") ?></option>
                    <option <?php selected('style2', $style) ?> value="style2"><?php esc_html_e("Style 2 - Post Elementor", "'posolo") ?></option>
                </select>
            </p>
            <p>
                <label for="<?php echo esc_attr($this->get_field_id('posts_per_page')); ?>"><?php esc_html_e('Post Number:', 'posolo'); ?></label>
                <input class="widefat" id="<?php echo esc_attr($this->get_field_id('posts_per_page')); ?>" name="<?php echo esc_attr($this->get_field_name('posts_per_page')); ?>" type="text" value="<?php echo esc_attr($posts_per_page); ?>">
            </p>
            <p>
                <label for="<?php echo esc_attr($this->get_field_id('order_by')); ?>"><?php esc_html_e('Order By:', 'posolo'); ?></label>

                <select class="widefat" id="<?php echo esc_attr($this->get_field_id('order_by')); ?>" name="<?php echo esc_attr($this->get_field_name('order_by')); ?>">
                    <?php echo tech888f_get_order_list($order_by, array('post_view' => esc_html__('Post View', 'posolo')), 'option'); ?>
                </select>
            </p>
            <p>
                <label for="<?php echo esc_attr($this->get_field_id('order')); ?>"><?php esc_html_e('Order:', 'posolo'); ?></label>

                <select class="widefat" id="<?php echo esc_attr($this->get_field_id('order')); ?>" name="<?php echo esc_attr($this->get_field_name('order')); ?>">
                    <option <?php selected('desc', $order) ?> value="desc"><?php esc_html_e("DESC", "'posolo") ?></option>
                    <option <?php selected('asc', $order) ?> value="asc"><?php esc_html_e("ASC", "'posolo") ?></option>
                </select>
            </p>
            <p>
                <label for="<?php echo esc_attr($this->get_field_id('category')); ?>"><?php esc_html_e('Category:', 'posolo'); ?></label>

                <?php
                if (class_exists('Walker_CategoryDropdown')) {
                    wp_dropdown_categories(array(
                        'selected' => $category,
                        'show_option_all' => esc_html__('--- Select ---', 'posolo'),
                        'name'  => $this->get_field_name('category'),
                        'class'              => 'widefat',
                    ));
                } ?>
            </p>


<?php
        }
    }

    tech888f_ListPostsWidget_Bhn::_init();
}
