<?php
/**
 * Created by Sublime Text 2.
 * User: thanhhiep992
 * Date: 12/08/15
 * Time: 10:20 AM
 */

/******************************************Core Function******************************************/

//Get option
if (!function_exists('tech888f_get_option')) {
    function tech888f_get_option($key, $default = NULL)
    {
        if (class_exists('Redux')) {
            $value = tech888f_get_redux_option($key);
            if (empty($value) && $default !== NULL && $value !== "0") $value = $default;
            return $value;
        } else {
            if (function_exists('ot_get_option')) {
                $value = ot_get_option($key, $default);
                if (empty($value) && $default) $value = $default;
                return $value;
            }
        }

        return $default;
    }
}

    if(!function_exists('tech888f_get_meta')){
        function tech888f_get_meta($field_id,$default = null){
            if(class_exists('RWMB_Field')){
                $obj = rwmb_meta( $field_id);
                return $obj;
            }else{
                return $default;
            }

        }
    }

if(!function_exists('tech888f_get_meta_arg')){
    function tech888f_get_meta_arg($field_id,$args = null,$post_id = null,$default = null){
        if(class_exists('RWMB_Field')){
            $obj = rwmb_meta( $field_id,$args,$post_id);
            return $obj;
        }else{
            return $default;
        }

    }
}

//Get list post type
if (!function_exists('tech888f_list_post_type')) {
    function tech888f_list_post_type($post_type = 'page', $type = true)
    {
        global $post;
        $post_temp = $post;
        $page_list = array();
        if($type){
            $page_list[] = array();
        }
        else $page_list[] = esc_html__('-- Choose One --','posolo');

        if (is_admin()) {
            $pages = get_posts(array('post_type' => $post_type, 'posts_per_page' => -1, 'orderby' => 'title', 'order' => 'ASC'));
            if (!empty($pages)) {
                if (is_array($pages) & count($pages) > 0) {
                    foreach ($pages as $page) {
                        $page_list[$page->ID] =  $page->post_title;
                    }
                }
            }
        }
        return $page_list;
    }
}

//Get list sidebar
if (!function_exists('tech888f_get_sidebar_ids')) {
    function tech888f_get_sidebar_ids($for_option = false)
    {
        global $wp_registered_sidebars;
        $r = array();
        $r[] = esc_html__('--Select--', 'posolo');
        if (!empty($wp_registered_sidebars)) {
            foreach ($wp_registered_sidebars as $key => $value) {

                if ($for_option) {
                    $r[] = array(
                        'value' => $value['id'],
                        'label' => $value['name']
                    );
                } else {
                    $r[$value['id']] = $value['name'];
                }
            }
        }
        return $r;
    }
}

//Get order list
if (!function_exists('tech888f_get_order_list')) {
    function tech888f_get_order_list($current = false, $extra = array(), $return = 'array')
    {
        $default = array(
            esc_html__('None', 'posolo') => 'none',
            esc_html__('ID', 'posolo') => 'ID',
            esc_html__('Author', 'posolo') => 'author',
            esc_html__('Title', 'posolo') => 'title',
            esc_html__('Name', 'posolo') => 'name',
            esc_html__('Date', 'posolo') => 'date',
            esc_html__('Last Modified Date', 'posolo') => 'modified',
            esc_html__('Post Parent', 'posolo') => 'parent',
        );

        if (!empty($extra) and is_array($extra)) {
            $default = array_merge($default, $extra);
        }

        if ($return == "array") {
            return $default;
        } elseif ($return == 'option') {
            $html = '';
            if (!empty($default)) {
                foreach ($default as $key => $value) {
                    $selected = selected($key, $current, false);
                    $html .= "<option {$selected} value='{$value}'>{$key}</option>";
                }
            }
            return $html;
        }
    }
}

// Get sidebar
if (!function_exists('tech888f_get_sidebar')) {
    function tech888f_get_sidebar()
    {
        $default = array(
            'position' => 'right',
            'id' => 'blog-sidebar'
        );
        if (class_exists("woocommerce") && tech888f_is_woocommerce_page()) $default['id'] = 'woocommerce-sidebar';
        return apply_filters('tech888f_get_sidebar', $default);
    }
}
// Check sidebar
if (!function_exists('tech888f_check_sidebar')) {
    function tech888f_check_sidebar()
    {
        $sidebar = tech888f_get_sidebar();
        if ($sidebar['position'] == 'no') return false;
        else return true;
    }
}

//Fill css background
if (!function_exists('tech888f_fill_css_background')) {
    function tech888f_fill_css_background($data)
    {
        $string = '';
        if (!empty($data['background-color'])) $string .= 'background-color:' . $data['background-color'] . ';';
        if (!empty($data['background-repeat'])) $string .= 'background-repeat:' . $data['background-repeat'] . ';';
        if (!empty($data['background-attachment'])) $string .= 'background-attachment:' . $data['background-attachment'] . ';';
        if (!empty($data['background-position'])) $string .= 'background-position:' . $data['background-position'] . ';';
        if (!empty($data['background-size'])) $string .= 'background-size:' . $data['background-size'] . ';';
        if (!empty($data['background-image'])) $string .= 'background-image:url("' . $data['background-image'] . '");';
        if (!empty($string)) return tech888f_Assets::build_css($string);
        else return false;
    }
}
if (!function_exists('tech888f_fill_css_typography')) {
    function tech888f_fill_css_typography($data, $important = '')
    {
        $style = '';
        if (!empty($data['color'])) $style .= 'color:' . $data['color'] . $important . ';';
        if (!empty($data['font-family'])) $style .= 'font-family:' . $data['font-family'] . $important . ';';
        if (!empty($data['font-size'])) $style .= 'font-size:' . $data['font-size'] . $important . ';';
        if (!empty($data['font-style'])) $style .= 'font-style:' . $data['font-style'] . $important . ';';
        if (!empty($data['font-variant'])) $style .= 'font-variant:' . $data['font-variant'] . $important . ';';
        if (!empty($data['font-weight'])) $style .= 'font-weight:' . $data['font-weight'] . $important . ';';
        if (!empty($data['letter-spacing'])) $style .= 'letter-spacing:' . $data['letter-spacing'] . $important . ';';
        if (!empty($data['line-height'])) $style .= 'line-height:' . $data['line-height'] . $important . ';';
        if (!empty($data['text-decoration'])) $style .= 'text-decoration:' . $data['text-decoration'] . $important . ';';
        if (!empty($data['text-transform'])) $style .= 'text-transform:' . $data['text-transform'] . $important . ';';
        if (!empty($data['text-align'])) $style .= 'text-align:' . $data['text-align'] . $important . ';';
        return $style;
    }
}

// Get list menu
if (!function_exists('tech888f_list_menu_name')) {
    function tech888f_list_menu_name()
    {
        $menu_nav = wp_get_nav_menus();
        $menu_list = array('Default' => '');
        if (is_array($menu_nav) && !empty($menu_nav)) {
            foreach ($menu_nav as $item) {
                if (is_object($item)) {
                    $menu_list[$item->name] = $item->slug;
                }
            }
        }
        return $menu_list;
    }
}

//Custom BreadCrumb
if (!function_exists('tech888f_breadcrumb')) {
    function tech888f_breadcrumb($step = '')
    {
        global $post;
        if (is_home() && !is_front_page()) echo '<a href="' . esc_url(home_url('/')) . '">' . esc_html__('Home', 'posolo') . '</a>' . $step . '<span>' . esc_html__('Blog', 'posolo') . '</span>';
        else echo '<a href="' . esc_url(home_url('/')) . '">' . esc_html__('Home', 'posolo') . '</a>';
        if (is_single()) {
            echo apply_filters('tech888f_output_content', $step);
            echo get_the_category_list($step);
            echo apply_filters('tech888f_output_content', $step) . '<span>' . get_the_title() . '</span>';
        } elseif (is_page()) {
            if ($post->post_parent) {
                $anc = get_post_ancestors(get_the_ID());
                $title = get_the_title();
                foreach ($anc as $ancestor) {
                    $output = $step . '<a href="' . esc_url(get_permalink($ancestor)) . '" title="' . get_the_title($ancestor) . '">' . get_the_title($ancestor) . '</a>';
                }
                echo apply_filters('tech888f_output_content', $output);
                echo '<span>' . $title . '</span>';
            } else {
                echo '<span>' . get_the_title() . '</span>';
            }
        } elseif (is_archive()) echo "<span>" . get_the_archive_title() . "</span>";
        elseif (is_search()) echo "<span>" . esc_html__("Search Results for: ", "posolo") . get_search_query() . '</span>';
        elseif (is_404()) echo "<span>" . esc_html__("404 ", "posolo") . "</span>";
    }
}
//Don't Show popup
if (!is_admin() && session_status() == PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['dont_show_popup'])) $_SESSION['dont_show_popup'] = false;
add_action('wp_ajax_set_dont_show', 'tech888f_set_dont_show');
add_action('wp_ajax_nopriv_set_dont_show', 'tech888f_set_dont_show');
if (!function_exists('sv_set_dont_show')) {
    function tech888f_set_dont_show()
    {
        $checked = $_POST['checked'];
        if ($checked) {
            session_start();
            $_SESSION['dont_show_popup'] = $checked;
        } else {
            unset($_SESSION['dont_show_popup']);
            session_destroy();
        }
    }
}
//Get current ID
if (!function_exists('tech888f_get_current_id')) {
    function tech888f_get_current_id()
    {
        $id = get_the_ID();
        if (is_front_page() && is_home()) $id = (int)get_option('page_on_front');
        if (!is_front_page() && is_home()) $id = (int)get_option('page_for_posts');
        if (is_archive() || is_search()) $id = 0;
        if (class_exists('woocommerce')) {
            if (is_shop()) $id = (int)get_option('woocommerce_shop_page_id');
            if (is_cart()) $id = (int)get_option('woocommerce_cart_page_id');
            if (is_checkout()) $id = (int)get_option('woocommerce_checkout_page_id');
            if (is_account_page()) $id = (int)get_option('woocommerce_myaccount_page_id');
        }
        return $id;
    }
}
//Get page value by ID
if (!function_exists('tech888f_get_value_by_id')) {
    function tech888f_get_value_by_id($key, $meta_empty = false)
    {
        if (!empty($key)) {
            $id = tech888f_get_current_id();
            $value = get_post_meta($id, $key, true);
            if (isset($value['rgba']) && isset($value['color'])) {
                if ($value['alpha'] != '1') $value = $value['rgba'];
                else $value = $value['color'];
            }
            if (empty($value) && !$meta_empty) $value = tech888f_get_option($key);
            $session_page = tech888f_get_option('session_page');
            if ($session_page == '1') {
                if ($key == 'tech888f_header_page' || $key == 'tech888f_footer_page' || $key == 'main_color' || $key == 'main_color2') {
                    $val_meta = get_post_meta($id, $key, true);
                    if (!empty($val_meta)) $_SESSION[$key] = $val_meta;
                    if (isset($_SESSION[$key])) $session_val = $_SESSION[$key];
                    else $session_val = '';
                    if (!empty($session_val)) $value = $session_val;
                }
            }
            return $value;
        } else return 'Missing a variable of this funtion';
    }
}

//Check woocommerce page
if (!function_exists('tech888f_is_woocommerce_page')) {
    function tech888f_is_woocommerce_page()
    {
        if (function_exists("is_woocommerce") && is_woocommerce()) {
            return true;
        }
        $woocommerce_keys = array("woocommerce_shop_page_id",
            "woocommerce_terms_page_id",
            "woocommerce_cart_page_id",
            "woocommerce_checkout_page_id",
            "woocommerce_pay_page_id",
            "woocommerce_thanks_page_id",
            "woocommerce_myaccount_page_id",
            "woocommerce_edit_address_page_id",
            "woocommerce_view_order_page_id",
            "woocommerce_change_password_page_id",
            "woocommerce_logout_page_id",
            "woocommerce_lost_password_page_id");
        foreach ($woocommerce_keys as $wc_page_id) {
            if (get_the_ID() == get_option($wc_page_id, 0)) {
                return true;
            }
        }
        return false;
    }
}

//navigation
if (!function_exists('tech888f_paging_nav')) {
    function tech888f_paging_nav($query = false, $style = '', $echo = true)
    {
        if ($query) {
            $big = 999999999;
            $paged = (get_query_var('paged')) ? absint(get_query_var('paged')) : 1;
            $links = array(
                'base' => str_replace($big, '%#%', esc_url(get_pagenum_link($big))),
                'format' => '&page=%#%',
                'current' => max(1, $paged),
                'total' => $query->max_num_pages,
                'end_size' => 2,
                'mid_size' => 1
            );
        } else {
            if ($GLOBALS['wp_query']->max_num_pages < 2) {
                return;
            }

            $paged = get_query_var('paged') ? intval(get_query_var('paged')) : 1;
            $pagenum_link = html_entity_decode(get_pagenum_link());
            $query_args = array();
            $url_parts = explode('?', $pagenum_link);

            if (isset($url_parts[1])) {
                wp_parse_str($url_parts[1], $query_args);
            }

            $pagenum_link = remove_query_arg(array_keys($query_args), $pagenum_link);
            $pagenum_link = trailingslashit($pagenum_link) . '%_%';

            $format = $GLOBALS['wp_rewrite']->using_index_permalinks() && !strpos($pagenum_link, 'index.php') ? 'index.php/' : '';
            $format .= $GLOBALS['wp_rewrite']->using_permalinks() ? user_trailingslashit('page/%#%', 'paged') : '?paged=%#%';

            // Set up paginated links.
            $links = array(
                'base' => $pagenum_link,
                'format' => $format,
                'total' => $GLOBALS['wp_query']->max_num_pages,
                'current' => $paged,
                'end_size' => 2,
                'mid_size' => 1,
                'add_args' => array_map('urlencode', $query_args),
            );
        }
        $data = array(
            'links' => $links,
            'style' => $style,
        );
        $html = tech888f_get_template('paging-nav', false, $data, $echo);
        if (!$echo) return $html;
    }
}

//Set post view
if (!function_exists('tech888f_set_post_view')) {
    function tech888f_set_post_view($post_id = false)
    {
        if (!$post_id) $post_id = get_the_ID();
        $view = (int)get_post_meta($post_id, 'post_views', true);
        $view++;
        update_post_meta($post_id, 'post_views', $view);
    }
}

if (!function_exists('tech888f_get_post_view')) {
    function tech888f_get_post_view($post_id = false)
    {
        if (!$post_id) $post_id = get_the_ID();
        return (int)get_post_meta($post_id, 'post_views', true);
    }
}

//remove attr embed
if (!function_exists('tech888f_remove_w3c')) {
    function tech888f_remove_w3c($embed_code)
    {
        $embed_code = str_replace('webkitallowfullscreen', '', $embed_code);
        $embed_code = str_replace('mozallowfullscreen', '', $embed_code);
        $embed_code = str_replace('frameborder="0"', '', $embed_code);
        $embed_code = str_replace('frameborder="no"', '', $embed_code);
        $embed_code = str_replace('scrolling="no"', '', $embed_code);
        $embed_code = str_replace('&', '&amp;', $embed_code);
        return $embed_code;
    }
}

// MetaBox
if (!function_exists('tech888f_display_metabox')) {
    function tech888f_display_metabox($type = '')
    {
        switch ($type) {
            case 'blog':
                break;

            default:
                ?>
                <ul class="list-inline-block post-meta-data title14 text-uppercase font-bold">
                    <li><i class="fa fa-user color" aria-hidden="true"></i><a class="color" href="<?php echo esc_url(get_author_posts_url(get_the_author_meta('ID'))); ?>"><?php echo get_the_author(); ?></a>
                    </li>
                    <li><i class="fa fa-clock-o title17 color"></i><span class="color"><?php echo get_the_date() ?></span></li>
                    <li><i aria-hidden="true" class="fa fa-comment-o title17 color"></i>
                        <a class="color" href="<?php echo esc_url(get_comments_link()); ?>"><?php echo get_comments_number(); ?>
                            <?php
                            if (get_comments_number() != 1) esc_html_e('Comments', 'posolo');
                            else esc_html_e('Comment', 'posolo');
                            ?>
                        </a>
                    </li>
                </ul>
                <?php
                break;
        }
    }
}
if (!function_exists('tech888f_get_main_class')) {
    function tech888f_get_main_class()
    {
        $sidebar = tech888f_get_sidebar();
        $sidebar_pos = $sidebar['position'];
        $main_class = 'content-wrap col-md-12 col-sm-12 col-xs-12';
        if ($sidebar_pos != 'no' && is_active_sidebar($sidebar['id'])) $main_class = 'content-wrap content-sidebar-' . $sidebar_pos . ' col-md-9 col-sm-8 col-xs-12';
        return apply_filters('tech888f_main_class', $main_class);
    }
}
if (!function_exists('tech888f_output_sidebar')) {
    function tech888f_output_sidebar($position)
    {
        $sidebar = tech888f_get_sidebar();
        $sidebar_pos = $sidebar['position'];
        if ($sidebar_pos == $position) get_sidebar();
    }
}
if (!function_exists('tech888f_get_import_category')) {
    function tech888f_get_import_category($taxonomy = 'product_cat')
    {
        $cats = get_terms($taxonomy);
        $data_json = '{';
        foreach ($cats as $key => $term) {
            $thumb_cat_id = get_woocommerce_term_meta($term->term_id, 'thumbnail_id', true);
            $term_pa = get_term_by('id', $term->parent, $taxonomy);
            if (isset($term_pa->slug)) $slug_pa = $term_pa->slug;
            else $slug_pa = '';
            if ($key > 0) $data_json .= ',';
            $data_json .= '"' . $term->slug . '":{"thumbnail":"' . $thumb_cat_id . '","parent":"' . $slug_pa . '"}';
        }
        $data_json .= '}';
        echo apply_filters('tech888f_output_content', $data_json);
    }
}
if (!function_exists('tech888f_fix_import_category')) {
    function tech888f_fix_import_category($taxonomy)
    {
        global $tech888f_config;
        $data = $tech888f_config['import_category'];
        if (!empty($data)) {
            $data = json_decode($data, true);
            if (is_array($data)) {
                foreach ($data as $cat => $value) {
                    $parent_id = 0;
                    $term = get_term_by('slug', $cat, $taxonomy);
                    if (isset($term->term_id)) {
                        $term_parent = get_term_by('slug', $value['parent'], $taxonomy);
                        if (isset($term_parent->term_id)) $parent_id = $term_parent->term_id;
                        if ($parent_id) wp_update_term($term->term_id, $taxonomy, array('parent' => $parent_id));
                        if ($value['thumbnail']) {
                            if ($taxonomy == 'product_cat') update_woocommerce_term_meta($term->term_id, 'thumbnail_id', $value['thumbnail']);
                            else {
                                update_term_meta($term->term_id, 'thumbnail_id', $value['thumbnail']);
                            }
                        }
                    }
                }
            }
        }
    }
}
if (!function_exists('tech888f_get_google_link')) {
    function tech888f_get_google_link()
    {
        $font_url = '';
        $fonts = array(
            'Open+Sans:wght@300;400;700',
//            'Philosopher:wght@400;700',
            'Roboto+Slab:wght@400;700',

        );
        if ('off' !== _x('on', 'Google font: on or off', 'posolo')) {
            $fonts_url = add_query_arg(array(
                'family' => implode('&family=', $fonts),
            ), "//fonts.googleapis.com/css2");
        }

        return $fonts_url;
    }
}

// get list taxonomy
if (!function_exists('tech888f_list_taxonomy')) {
    function tech888f_list_taxonomy($taxonomy, $show_all = true)
    {
        if ($show_all) $list = array(esc_html__('--Select--', 'posolo') => '');
        else $list = array();
        if (!isset($taxonomy) || empty($taxonomy)) $taxonomy = 'category';
        $tags = get_terms($taxonomy);
        if (is_array($tags) && !empty($tags)) {
            foreach ($tags as $tag) {
                $list[$tag->name] = $tag->slug;
            }
        }
        return $list;
    }
}
if (!function_exists('tech888f_check_enqueue')) {
    function tech888f_check_enqueue($elements)
    {
        global $post;
        $page_header = tech888f_get_value_by_id('tech888f_header_page');
        $page_header = get_post($page_header);
        $page_footer = tech888f_get_value_by_id('tech888f_footer_page');
        $page_footer = get_post($page_footer);
        $content = '';
        if (isset($page_header->post_content)) $content .= $page_header->post_content;
        if (isset($post->post_content)) $content .= $post->post_content;
        if (isset($page_footer->post_content)) $content .= $page_footer->post_content;
        $elements = explode(',', $elements);
        $check = false;
        foreach ($elements as $element) {
            if (!empty($element) && strpos($content, '[' . $element)) $check = true;
        }
        return $check;
    }
}
if (!function_exists('tech888f_substr')) {
    function tech888f_substr($string = '', $start = 0, $end = 1)
    {
        $output = '';
        if (!empty($string)) {
            $string = strip_tags($string);
            if ($end < strlen($string)) {
                if ($string[$end] != ' ') {
                    for ($i = $end; $i < strlen($string); $i++) {
                        if ($string[$i] == ' ' || $string[$i] == '.' || $i == strlen($string) - 1) {
                            $end = $i;
                            break;
                        }
                    }
                }
            }
            $output = substr($string, $start, $end);
        }
        return $output;
    }
}
if (!function_exists('tech888f_get_template')) {
    function tech888f_get_template($view_name, $slug = false, $data = array(), $echo = FALSE)
    {
        $html = tech888f_Template::load_view($view_name, $slug, $data, $echo);
        if (!$echo) return $html;
    }
}
if (!function_exists('tech888f_get_template_post')) {
    function tech888f_get_template_post($view_name, $slug = false, $data = array(), $echo = FALSE)
    {
        $view_name = 'posts/' . $view_name;
        $html = tech888f_Template::load_view($view_name, $slug, $data, $echo);
        if (!$echo) return $html;
    }
}
if (!function_exists('tech888f_get_template_image_gallery')) {
    function tech888f_get_template_image_gallery($view_name, $slug = false, $data = array(), $echo = FALSE)
    {
        $view_name = 'images-gallery/' . $view_name;
        $html = tech888f_Template::load_view($view_name, $slug, $data, $echo);
        if (!$echo) return $html;
    }
}

if (!function_exists('tech888f_get_template_project')) {
    function tech888f_get_template_project($view_name, $slug = false, $data = array(), $echo = FALSE)
    {
        $view_name = 'projects/' . $view_name;
        $html = tech888f_Template::load_view($view_name, $slug, $data, $echo);
        if (!$echo) return $html;
    }
}
if (!function_exists('tech888f_get_template_custom_product')) {
    function tech888f_get_template_custom_product($view_name, $slug = false, $data = array(), $echo = FALSE)
    {
        $view_name = 'custom-products/' . $view_name;
        $html = tech888f_Template::load_view($view_name, $slug, $data, $echo);
        if (!$echo) return $html;
    }
}
if (!function_exists('tech888f_get_template_element')) {
    function tech888f_get_template_element($view_name, $slug = false, $data = array(), $echo = FALSE)
    {
        $view_name = 'elements/' . $view_name;
        $html = tech888f_Template::load_view($view_name, $slug, $data, $echo);
        if (!$echo) return $html;
    }
}
if (!function_exists('tech888f_get_template_product')) {
    function tech888f_get_template_product($view_name, $slug = false, $data = array(), $echo = FALSE)
    {
        $view_name = 'products/' . $view_name;
        $html = tech888f_Template::load_view($view_name, $slug, $data, $echo);
        if (!$echo) return $html;
    }
}
if (!function_exists('tech888f_get_template_woocommerce')) {
    function tech888f_get_template_woocommerce($view_name, $slug = false, $data = array(), $echo = FALSE)
    {
        $view_name = 'woocommerce/' . $view_name;
        $html = tech888f_Template::load_view($view_name, $slug, $data, $echo);
        if (!$echo) return $html;
    }
}
if (!function_exists('tech888f_get_template_widget')) {
    function tech888f_get_template_widget($view_name, $slug = false, $data = array(), $echo = FALSE)
    {
        $view_name = 'widgets/' . $view_name;
        $html = tech888f_Template::load_view($view_name, $slug, $data, $echo);
        if (!$echo) return $html;
    }
}
//get type url
if (!function_exists('tech888f_get_filter_url')) {
    function tech888f_get_filter_url($key, $value)
    {
        if (function_exists('tech888f_get_current_url')) $current_url = tech888f_get_current_url();
        else {
            if (function_exists('wc_get_page_id')) $current_url = get_permalink(wc_get_page_id('shop'));
            else $current_url = get_permalink();
        }
        $current_url = get_pagenum_link();
        if (isset($_GET[$key])) {
            $current_val_string = sanitize_text_field($_GET[$key]);
            if ($current_val_string == $value) {
                $current_url = str_replace('&' . $key . '=' . $_GET[$key], '', $current_url);
                if (strpos($current_url, '&') > -1) $current_url = str_replace('?' . $key . '=' . $_GET[$key], '?', $current_url);
                else $current_url = str_replace('?' . $key . '=' . $_GET[$key], '', $current_url);
            }
            if (strpos($current_val_string, ',') > -1) $current_val_key = explode(',', $current_val_string);
            else $current_val_key = explode('%2C', $current_val_string);
            $val_encode = str_replace(',', '%2C', $current_val_string);
            if (!empty($current_val_string)) {
                if (!in_array($value, $current_val_key)) $current_val_key[] = $value;
                else {
                    $pos = array_search($value, $current_val_key);
                    unset($current_val_key[$pos]);
                }
                $new_val_string = implode('%2C', $current_val_key);
                $current_url = str_replace($key . '=' . $val_encode, $key . '=' . $new_val_string, $current_url);
                if (strpos($current_url, '?') == false) $current_url = str_replace('&', '?', $current_url);
            } else $current_url = str_replace($key . '=', $key . '=' . $value, $current_url);
        } else {
            if (strpos($current_url, '?') > -1) {
                $current_url .= '&amp;' . $key . '=' . $value;
            } else {
                $current_url .= '?' . $key . '=' . $value;
            }
        }
        return $current_url;
    }
}
//get type url
if (!function_exists('tech888f_get_key_url')) {
    function tech888f_get_key_url($key, $value)
    {
        if (function_exists('tech888f_get_current_url')) $current_url = tech888f_get_current_url();
        else {
            if (function_exists('wc_get_page_id')) $current_url = get_permalink(wc_get_page_id('shop'));
            else $current_url = get_permalink();
        }
        $current_url = get_pagenum_link();
        if (isset($_GET[$key])) {
            $current_url = str_replace('&' . $key . '=' . $_GET[$key], '', $current_url);
            if (strpos($current_url, '&') > -1) $current_url = str_replace('?' . $key . '=' . $_GET[$key], '?', $current_url);
            else $current_url = str_replace('?' . $key . '=' . $_GET[$key], '', $current_url);
        }
        if (strpos($current_url, '?') > -1) {
            $current_url .= '&amp;' . $key . '=' . $value;
        } else {
            $current_url .= '?' . $key . '=' . $value;
        }
        return $current_url;
    }
}
if (!function_exists('tech888f_get_post_style')) {
    function tech888f_get_post_style($style = 'element')
    {
        $list = apply_filters('tech888f_post_item_style', array(
            esc_html__('Default - Post Related', 'posolo') => '' ,
            esc_html__('Post style 2 - Post list', 'posolo') => 'style2',
            esc_html__('Post grid 3', 'posolo') => 'style3',
        ));
        
        return $list;
    }
}
if (!function_exists('tech888f_get_post_list_style')) {
    function tech888f_get_post_list_style($style = 'element')
    {
        $list = apply_filters('tech888f_post_list_item_style', array(
            esc_html__('Default', 'posolo') =>  '' ,
            esc_html__('Post List 2', 'posolo') => 'style2',
        ));
        
        return $list;
    }
}
if (!function_exists('tech888f_get_product_list_style')) {
    function tech888f_get_product_list_style($style = 'element')
    {
        $list = apply_filters('tech888f_product_list_item_style', array(
            '' => esc_html__('Default', 'posolo'),
            'style2' =>  esc_html__('Product list 2', 'posolo'),
        ));
        
        return $list;
    }
}
if (!function_exists('tech888f_get_product_style')) {
    function tech888f_get_product_style($style = 'element')
    {
        $list = apply_filters('tech888f_product_item_style', array(
             esc_html__('Default', 'posolo') => '',
            esc_html__('Product grid 2', 'posolo')  =>  'style2',
            esc_html__('Product grid 3', 'posolo') => 'style3',
        ));
        return $list;
    }
}
if (!function_exists('tech888f_get_product_thumb_animation')) {
    function tech888f_get_product_thumb_animation($style = 'element')
    {
        $list = apply_filters('tech888f_product_item_style', array(
            esc_html__('None', 'posolo') => '',
            esc_html__('Light Soft', 'posolo') => 'light-soft-thumb',
            esc_html__('Zoom', 'posolo') => 'zoom-thumb',
            esc_html__('Rotate', 'posolo') => 'rotate-thumb',
            esc_html__('Zoom Out', 'posolo') => 'zoomout-thumb',
            esc_html__('Translate', 'posolo') => 'translate-thumb',
        ));
        if ($style != 'element') {
            $temp = array();
            foreach ($list as $key => $value) {
                $temp[] = array(
                    'value' => $value,
                    'label' => $key,
                );
            }
            $list = $temp;
        }
        return $list;
    }
}
//Share calculate
add_action('wp_ajax_update_share', 'tech888f_update_share');
add_action('wp_ajax_nopriv_update_share', 'tech888f_update_share');
if (!function_exists('tech888f_update_share')) {
    function tech888f_update_share()
    {
        $social = $_POST['social'];
        $id = $_POST['id'];
        $number = (int)get_post_meta($id, 'total_share_' . $social, true);
        $total = (int)get_post_meta($id, 'total_share', true);
        $number++;
        $total++;
        update_post_meta($id, 'total_share_' . $social, $number);
        update_post_meta($id, 'total_share', $total);
        die();
    }
}
if (!function_exists('tech888f_filter_price')) {
    function tech888f_filter_price($min, $max, $filtered_posts = array())
    {
        global $wpdb;
        $matched_products = array(0);
        $matched_products_query = apply_filters('woocommerce_price_filter_results', $wpdb->get_results($wpdb->prepare("
            SELECT DISTINCT ID, post_parent, post_type FROM $wpdb->posts
            INNER JOIN $wpdb->postmeta ON ID = post_id
            WHERE post_type IN ( 'product', 'product_variation' ) AND post_status = 'publish' AND meta_key = %s AND meta_value BETWEEN %d AND %d
        ", '_price', $min, $max), OBJECT_K), $min, $max);

        if ($matched_products_query) {
            foreach ($matched_products_query as $product) {
                if ($product->post_type == 'product')
                    $matched_products[] = $product->ID;
                if ($product->post_parent > 0 && !in_array($product->post_parent, $matched_products))
                    $matched_products[] = $product->post_parent;
            }
        }

        // Filter the id's
        if (sizeof($filtered_posts) == 0) {
            $filtered_posts = $matched_products;
        } else {
            $filtered_posts = array_intersect($filtered_posts, $matched_products);
        }
        return $filtered_posts;
    }
}
if (!function_exists('tech888f_size_random')) {
    function tech888f_size_random($size)
    {
        if (count($size) > 2) {
            $sizes = array();
            if (is_array($size)) {
                foreach ($size as $key => $value) {
                    $i = $key + 1;
                    if ($i % 2 == 1 && isset($size[$i])) $sizes[] = array($value, $size[$i]);
                }
            }
            $k = array_rand($sizes);
            $size = $sizes[$k];
        }
        return $size;
    }
}
if (!function_exists('tech888f_get_list_taxonomy')) {
    function tech888f_get_list_taxonomy($taxonomy = 'product_cat')
    {
        $result = array();
        $tags = get_terms($taxonomy);
        if (is_array($tags) && !empty($tags)) {
            foreach ($tags as $tag) {
                $list[$tag->name] = $tag->slug;
                $result[] = array(
                    'value' => $tag->slug,
                    'label' => $tag->name,
                );
            }
        }
        return $result;
    }
}
if (!function_exists('tech888f_get_attr_content')) {
    function tech888f_get_attr_content($content, $default = array(), $list = array('vc_tta_section'))
    {

        $result = array();
        $tab_info = array();
        foreach ($list as $shortcode) {
            preg_match_all('/' . $shortcode . '([^\]]+)/i', $content, $matches, PREG_OFFSET_CAPTURE);
            if (isset($matches[1])) $tab_info = array_merge($tab_info, $matches[1]);
        }
        $item_content = explode('[/vc_tta_section]', $content);
        if (is_array($tab_info) && !empty($tab_info)) {
            foreach ($tab_info as $key => $value) {
                $string = $value[0];
                $string = str_replace('=" ', '="', $string);
                $data = explode('" ', $string);
                foreach ($data as $item) {
                    $item_data = explode('=', $item);
                    if (isset($item_data[0]) && isset($item_data[1])) {
                        $item_key = trim(str_replace('"', '', $item_data[0]));
                        $item_val = trim(str_replace('"', '', $item_data[1]));
                        $result[$key][$item_key] = $item_val;
                        $result[$key]['tab_content'] = $item_content[$key];
                    }
                }
                $result[$key] = array_merge($default, $result[$key]);
            }
        }
        return $result;
    }
}
if (!function_exists('tech888f_add_attr_content')) {
    function tech888f_add_attr_content($content, $attr = '', $list = array('vc_tta_section'))
    {
        foreach ($list as $shortcode) {

            $content = str_replace('[' . $shortcode, '[' . $shortcode . ' ' . $attr, $content);
        }
        return $content;
    }
}
//Get all page
if (!function_exists('tech888f_list_all_page')) {
    function tech888f_list_all_page($complete = false)
    {
        global $post;
        if (!$complete) {
            $page_list = array(
                esc_html__('-- Choose One --', 'posolo') => '',
            );
        } else $page_list = array();
        $pages = get_pages();
        foreach ($pages as $page) {
            if (!$complete) $page_list[$page->post_title] = $page->ID;
            else {
                $page_list[] = array(
                    'value' => $page->ID,
                    'label' => $page->post_title,
                );
            }
        }
        return $page_list;
    }
}
if (!function_exists('tech888f_get_sidebar_list')) {
    function tech888f_get_sidebar_list()
    {
        global $wp_registered_sidebars;
        $sidebars = array(
            esc_html__('--Select--', 'posolo') => ''
        );
        foreach ($wp_registered_sidebars as $id => $sidebar) {
            $sidebars[$sidebar['name']] = $id;
        }
        return $sidebars;
    }
}
if (!function_exists('tech888f_preload')) {
    function tech888f_preload()
    {
        $preload = tech888f_get_option('show_preload');
        if ($preload == '1'):
            $preload_style = tech888f_get_option('preload_style');
            $preload_bg = tech888f_get_option('preload_bg');
            $preload_img = tech888f_get_option('preload_img');
            if (isset($preload_img['url'])) $preload_img = $preload_img['url'];
            ?>
            <div id="loading" class="preload-loading preload-style-<?php echo esc_attr($preload_style) ?>">
                <div id="loading-center">
                    <?php
                    switch ($preload_style) {
                        case 'style2':
                            ?>
                            <div id="loading-center-absolute">
                                <div id="object<?php echo esc_attr($preload_style) ?>"></div>
                            </div>
                            <?php
                            break;

                        case 'style3':
                            ?>
                            <div id="loading-center-absolute<?php echo esc_attr($preload_style) ?>">
                                <div class="object<?php echo esc_attr($preload_style) ?>"
                                     id="object_one<?php echo esc_attr($preload_style) ?>"></div>
                                <div class="object<?php echo esc_attr($preload_style) ?>"
                                     id="object_two<?php echo esc_attr($preload_style) ?>"></div>
                                <div class="object<?php echo esc_attr($preload_style) ?>"
                                     id="object_three<?php echo esc_attr($preload_style) ?>"></div>
                                <div class="object<?php echo esc_attr($preload_style) ?>"
                                     id="object_four<?php echo esc_attr($preload_style) ?>"></div>
                            </div>
                            <?php
                            break;

                        case 'style4':
                            ?>
                            <div id="loading-center-absolute<?php echo esc_attr($preload_style) ?>">
                                <div class="object<?php echo esc_attr($preload_style) ?>"
                                     id="object_one<?php echo esc_attr($preload_style) ?>"></div>
                                <div class="object<?php echo esc_attr($preload_style) ?>"
                                     id="object_two<?php echo esc_attr($preload_style) ?>"></div>
                                <div class="object<?php echo esc_attr($preload_style) ?>"
                                     id="object_three<?php echo esc_attr($preload_style) ?>"></div>
                            </div>
                            <?php
                            break;

                        case 'style5':
                            ?>
                            <div id="loading-center-absolute<?php echo esc_attr($preload_style) ?>">
                                <div class="object<?php echo esc_attr($preload_style) ?>"
                                     id="first_object<?php echo esc_attr($preload_style) ?>"></div>
                                <div class="object<?php echo esc_attr($preload_style) ?>"
                                     id="second_object<?php echo esc_attr($preload_style) ?>"></div>
                            </div>
                            <?php
                            break;

                        case 'style6':
                            ?>
                            <div id="loading-center-absolute<?php echo esc_attr($preload_style) ?>">
                                <div class="object<?php echo esc_attr($preload_style) ?>"
                                     id="object_one<?php echo esc_attr($preload_style) ?>"></div>
                                <div class="object<?php echo esc_attr($preload_style) ?>"
                                     id="object_two<?php echo esc_attr($preload_style) ?>"></div>
                                <div class="object<?php echo esc_attr($preload_style) ?>"
                                     id="object_three<?php echo esc_attr($preload_style) ?>"></div>
                                <div class="object<?php echo esc_attr($preload_style) ?>"
                                     id="object_four<?php echo esc_attr($preload_style) ?>"></div>
                                <div class="object<?php echo esc_attr($preload_style) ?>"
                                     id="object_five<?php echo esc_attr($preload_style) ?>"></div>
                            </div>
                            <?php
                            break;

                        case 'style7':
                            ?>
                            <div id="loading-center-absolute<?php echo esc_attr($preload_style) ?>">
                                <div class="object<?php echo esc_attr($preload_style) ?>"
                                     id="object_one<?php echo esc_attr($preload_style) ?>"></div>
                            </div>
                            <?php
                            break;

                        case 'custom-image':
                            ?>
                            <div id="loading-center-absolute-image">
                                <img src="<?php echo esc_url($preload_img) ?>"
                                     alt="<?php esc_attr_e("preload-image", "posolo"); ?>"/>
                            </div>
                            <?php
                            break;

                        default:
                            ?>
                            <div id="loading-center-absolute">
                                <div class="object" id="object_four"></div>
                                <div class="object" id="object_three"></div>
                                <div class="object" id="object_two"></div>
                                <div class="object" id="object_one"></div>
                            </div>
                            <?php
                            break;
                    }
                    ?>
                </div>
            </div>
        <?php endif;
    }
}
//Compare URL
if (!function_exists('tech888f_compare_url')) {
    function tech888f_compare_url($icon = '', $id = false, $text = '', $class = 'silver')
    {
        $html = '';
        if (empty($text)) $text = esc_html__("Compare", "posolo");
        if (empty($icon)) $icon = '<i aria-hidden="true" class="li li-3d-rotate title16"></i>';
        if (class_exists('YITH_Woocompare')) {
            if (!$id) $id = get_the_ID();
            $cp_link = str_replace('&', '&amp;', add_query_arg(array('action' => 'yith-woocompare-add-product', 'id' => $id)));
            $html = '<a href="' . esc_url($cp_link) . '" class="product-compare compare compare-link ' . esc_attr($class) . '" data-product_id="' . get_the_ID() . '">' . $icon . '<span>' . $text . '</span></a>';
        }
        return $html;
    }
}
if (!function_exists('tech888f_wishlist_url')) {
    function tech888f_wishlist_url($icon = '', $text = '', $class = 'silver')
    {
        $html = '';
        if (empty($text)) $text = esc_html__("Wishlist", "posolo");
        if (empty($icon)) $icon = '<i class="li li-heart" aria-hidden="true"></i>';
        if (class_exists('YITH_WCWL')) $html = '<a href="' . esc_url(str_replace('&', '&amp;', add_query_arg('add_to_wishlist', get_the_ID()))) . '" class="add_to_wishlist wishlist-link ' . esc_attr($class) . '" rel="nofollow" data-product-id="' . get_the_ID() . '" data-product-title="' . esc_attr(get_the_title()) . '">' . $icon . '<span>' . $text . '</span></a>';
        return $html;
    }
}
if (!function_exists('tech888f_default_icon_lib')) {
    function tech888f_default_icon_lib()
    {
        $lib = tech888f_get_option('tech888f_icon_lib', 'fontawesome');
        return $lib;
    }
}

if (!function_exists('tech888f_get_size_crop')) {
    function tech888f_get_size_crop($size = '', $default = '')
    {
        if (!empty($size) && strpos($size, 'x')) {
            $size = str_replace('|', 'x', $size);
            $size = str_replace(',', 'x', $size);
            $size = explode('x', $size);
        }
        if (empty($size) && !empty($default)) $size = $default;
        return $size;
    }
}

if (!function_exists('tech888f_get_terms_filter')) {
    function tech888f_get_terms_filter($taxonomy)
    {
        $get_terms_args = array('hide_empty' => '1');

        $orderby = wc_attribute_orderby($taxonomy);

        switch ($orderby) {
            case 'name' :
                $get_terms_args['orderby'] = 'name';
                $get_terms_args['menu_order'] = false;
                break;
            case 'id' :
                $get_terms_args['orderby'] = 'id';
                $get_terms_args['order'] = 'ASC';
                $get_terms_args['menu_order'] = false;
                break;
            case 'menu_order' :
                $get_terms_args['menu_order'] = 'ASC';
                break;
        }

        $terms = get_terms($taxonomy, $get_terms_args);

        if (0 === count($terms)) {
            return;
        }

        switch ($orderby) {
            case 'name_num' :
                usort($terms, '_wc_get_product_terms_name_num_usort_callback');
                break;
            case 'parent' :
                usort($terms, '_wc_get_product_terms_parent_usort_callback');
                break;
        }
        return $terms;
    }
}
if (!function_exists('tech888f_get_list_attribute')) {
    function tech888f_get_list_attribute()
    {
        $result = array();
        $attributes = wc_get_attribute_taxonomies();
        if (!empty($attributes)) {
            foreach ($attributes as $attribute) {
                $result[$attribute->attribute_label] = $attribute->attribute_name;
            }
        }
        return $result;
    }
}
//get roles wp
if (!function_exists('tech888f_get_list_role')) {
    function tech888f_get_list_role()
    {
        global $wp_roles;
        $roles = array();
        if (isset($wp_roles->roles)) {
            $roles_data = $wp_roles->roles;
            if (is_array($roles_data)) {
                foreach ($roles_data as $key => $value) {
                    $roles[$value['name']] = $key;
                }
            }
        }
        return $roles;
    }
}
if (!function_exists('tech888f_is_vendor_page')) {
    function tech888f_is_vendor_page()
    {
        $check = false;
        $array_page = array(
            'wcvendors_vendor_dashboard_page_id',
            'wcvendors_shop_settings_page_id',
            'wcvendors_product_orders_page_id',
            'wcvendors_vendors_page_id',
            'wcvendors_vendor_terms_page_id',
        );
        $page_ids = [];
        foreach ($array_page as $value) {
            $page_ids[] = (int)get_option($value);
        }
        $id = tech888f_get_current_id();
        if (in_array($id, $page_ids)) $check = true;
        return $check;
    }
}
if (!function_exists('tech888f_login_form')) {
    function tech888f_login_form($redirect_to = '')
    {
        if (empty($redirect_to)) $redirect_to = apply_filters('login_redirect', home_url('/'));
        ?>
        <div class="login-form popup-form active">
            <div class="form-header">
                <h2><?php esc_html_e('Log In', 'posolo'); ?></h2>
                <div class="desc"><?php esc_html_e('Become a part of our community!', 'posolo'); ?></div>
                <div class="message ms-done ms-default"><?php esc_html_e('Registration complete. Please check your email.', 'posolo'); ?></div>
            </div>
            <form name="loginform" id="loginform"
                  action="<?php echo esc_url(site_url('wp-login.php', 'login_post')); ?>" method="post">
                <?php do_action('woocommerce_login_form_start'); ?>
                <div class="form-field">
                    <input type="text" name="log" id="user_login" class="input" size="20" autocomplete="off"/>
                    <label for="user_login"><?php esc_html_e('Username or Email Address', 'posolo'); ?></label>
                    <div class="input-focus-line"></div>
                </div>
                <div class="form-field">
                    <input type="password" name="pwd" id="user_pass" class="input" value="" size="20"
                           autocomplete="off"/>
                    <label for="user_pass"><?php esc_html_e('Password', 'posolo'); ?></label>
                    <div class="input-focus-line"></div>
                </div>
                <div class="extra-field">
                    <?php
                    if (class_exists("woocommerce")) do_action('woocommerce_login_form');
                    else do_action('login_form');
                    ?>
                </div>
                <div class="forgetmenot">
                    <input name="rememberme" type="checkbox" id="remembermep" value="forever"/>
                    <label class="rememberme" for="remembermep"><?php esc_html_e('Remember Me', 'posolo'); ?></label>
                </div>
                <div class="submit">
                    <input type="submit" name="wp-submit" class="button button-primary button-large"
                           value="<?php esc_attr_e('Log In', 'posolo'); ?>"/>
                    <input type="hidden" name="redirect_to1" value="<?php echo esc_attr($redirect_to); ?>"/>
                </div>
                <?php do_action('woocommerce_login_form_end'); ?>
            </form>
            <div class="nav-form">
                <?php if (get_option('users_can_register')) :
                    echo '<a href="#registerform" class="popup-redirect register-link">' . esc_html__("Register", "posolo") . '</a>';
                endif;
                echo '<a href="#lostpasswordform" class="popup-redirect lostpass-link">' . esc_html__("Lost your password?", "posolo") . '</a>';
                ?>
            </div>
        </div>
        <?php
    }
}
if (!function_exists('tech888f_register_form')) {
    function tech888f_register_form($redirect_to = '')
    {
        if (empty($redirect_to)) $redirect_to = apply_filters('registration_redirect', wp_login_url());
        ?>
        <div class="register-form popup-form">
            <div class="form-header">
                <h2><?php esc_html_e('Create an account', 'posolo'); ?></h2>
                <div class="desc"><?php esc_html_e('Welcome! Register for an account', 'posolo'); ?></div>
                <div class="message login_error ms-error ms-default"><?php esc_html_e('The user name or email address is not correct.', 'posolo'); ?></div>

            </div>
            <form name="registerform" id="registerform"
                  action="<?php echo esc_url(site_url('wp-login.php?action=register', 'login_post')); ?>" method="post"
                  novalidate="novalidate">
                <?php do_action('woocommerce_register_form_start'); ?>
                <div class="form-field">
                    <input type="text" name="user_login" id="user_loginr" class="input" value="" size="20"
                           autocomplete="off"/>
                    <label for="user_login"><?php esc_html_e('Username', 'posolo') ?></label>
                    <div class="input-focus-line"></div>
                </div>
                <div class="form-field">
                    <input type="email" name="user_email" id="user_email" class="input" value="" size="25"
                           autocomplete="off"/>
                    <label for="user_email"><?php esc_html_e('Email', 'posolo') ?></label>
                    <div class="input-focus-line"></div>
                </div>
                <?php if ('no' === get_option('woocommerce_registration_generate_password')) { ?>
                    <div class="form-field">
                        <input type="password" name="password" id="reg_passwordp" autocomplete="new-password"/>
                        <label for="reg_passwordp"><?php esc_html_e('Password', 'posolo'); ?></label>
                        <div class="input-focus-line"></div>
                    </div>
                <?php } ?>
                <div class="extra-field">
                    <?php
                    if (class_exists("woocommerce")) do_action('woocommerce_register_form');
                    else do_action('register_form');
                    ?>
                    <input type="hidden" name="redirect_to1" value="<?php echo esc_attr($redirect_to); ?>"/>
                </div>
                <?php if ('no' != get_option('woocommerce_registration_generate_password')) { ?>
                    <div id="reg_passmail">
                        <?php esc_html_e('Registration confirmation will be emailed to you.', 'posolo'); ?>
                    </div>
                <?php } ?>
                <div class="submit"><input type="submit" name="wp-submit" class="button button-primary button-large"
                                           value="<?php esc_attr_e('Register', "posolo"); ?>"/></div>
                <?php do_action('woocommerce_register_form_end'); ?>
            </form>

            <div class="nav-form">
                <a href="#loginform" class="popup-redirect login-link"><?php esc_html_e('Log in', 'posolo'); ?></a>
                <a href="#lostpasswordform"
                   class="popup-redirect lostpass-link"><?php esc_html_e('Lost your password?', 'posolo'); ?></a>
            </div>
        </div>
        <?php
    }
}
if (!function_exists('tech888f_lostpass_form')) {
    function tech888f_lostpass_form($redirect_to = '')
    {
        if (empty($redirect_to)) $redirect_to = apply_filters('login_redirect', home_url('/'));
        ?>
        <div class="lostpass-form popup-form">
            <div class="form-header">
                <h2><?php esc_html_e('Reset password', 'posolo'); ?></h2>
                <div class="desc"><?php esc_html_e('Recover your password', 'posolo'); ?></div>
                <div class="message ms-default ms-done"><?php esc_html_e('Password reset email has been sent.', 'posolo'); ?></div>
                <div class="message login_error ms-error ms-default"><?php esc_html_e('The email could not be sent.
Possible reason: your host may have disabled the mail function.', 'posolo'); ?></div>
            </div>
            <form name="lostpasswordform" id="lostpasswordform"
                  action="<?php echo esc_url(network_site_url('wp-login.php?action=lostpassword', 'login_post')); ?>"
                  method="post">
                <div class="form-field">
                    <input type="text" name="user_login" id="user_loginlp" class="input" value="" size="20"
                           autocomplete="off"/>
                    <label for="user_login"><?php esc_html_e('Username or Email Address', 'posolo'); ?></label>
                    <div class="input-focus-line"></div>
                </div>
                <div class="extra-field">
                    <?php do_action('lostpassword_form'); ?>
                    <input type="hidden" name="redirect_to1" value="<?php echo esc_attr($redirect_to); ?>"/>
                </div>
                <div class="submit"><input type="submit" name="wp-submit" class="button button-primary button-large"
                                           value="<?php esc_attr_e('Get New Password', 'posolo'); ?>"/></div>
                <div class="desc note"><?php esc_html_e('A password will be e-mailed to you.', 'posolo'); ?></div>
            </form>

            <div class="nav-form">
                <a href="#loginform" class="popup-redirect login-link"><?php esc_html_e('Log in', "posolo") ?></a>
                <?php
                if (get_option('users_can_register')) :
                    echo '<a href="#registerform" class="popup-redirect register-link">' . esc_html__("Register", "posolo") . '</a>';
                endif;
                ?>
            </div>
        </div>
        <?php
    }
}
if (!function_exists('tech888f_content_form_popup')) {
    function tech888f_content_form_popup()
    {
        if (!is_user_logged_in()):
            ?>
            <div class="login-popup-content-wrap">
                <div class="login-popup-content">
                    <?php
                    tech888f_login_form();
                    tech888f_register_form();
                    tech888f_lostpass_form();
                    ?>
                    <a href="#" class="close-login-form">×</a>
                </div>
                <div class="popup-overlay"></div>
            </div>
        <?php
        endif;
    }
}
if (!function_exists('tech888f_add_html_attr')) {
    function tech888f_add_html_attr($value, $echo = false, $attr = 'style')
    {
        $output = '';
        if (!empty($attr)) {
            $output = $attr . '="' . $value . '"';
        }
        if ($echo) echo apply_filters('tech888f_output_content', $output);
        else return $output;
    }
}
if (!function_exists('tech888f_add_style_tag')) {
    function tech888f_add_style_tag($value, $echo = false, $tag = 'style')
    {
        $output = '';
        if (!empty($tag)) {
            $output = '<' . $tag . '>' . $value . '</style>';
        }
        if ($echo) echo apply_filters('tech888f_output_content', $output);
        else return $output;
    }
}
if (!function_exists('tech888f_get_responsive_default_atts')) {
    function tech888f_get_responsive_default_atts()
    {
        $default = array(
            'bb_tab_container' => '',
            'tech888f_x_large_css' => '',
            'tech888f_x_large_csstypo' => '',
            'tech888f_x_large_cssshow_hide' => 'yes',
            'tech888f_large_css' => '',
            'tech888f_large_csstypo' => '',
            'tech888f_large_cssshow_hide' => 'yes',
            'tech888f_medium_css' => '',
            'tech888f_medium_csstypo' => '',
            'tech888f_medium_cssshow_hide' => 'yes',
            'tech888f_small_css' => '',
            'tech888f_small_csstypo' => '',
            'tech888f_small_cssshow_hide' => 'yes',
            'tech888f_s_small_css' => '',
            'tech888f_s_small_csstypo' => '',
            'tech888f_s_small_cssshow_hide' => 'yes',
        );
        return apply_filters('tech888f_responsive_default_atts', $default);
    }
}


/***************************************END Core Function***************************************/


/***************************************Add Theme Function***************************************/

/*convert image URL to Image ID*/
function tech888f_get_attachment_id_from_url($attachment_url = '')
{

    global $wpdb;
    $attachment_id = false;

    // If there is no url, return.
    if ('' == $attachment_url)
        return;

    // Get the upload directory paths
    $upload_dir_paths = wp_upload_dir();

    // Make sure the upload path base directory exists in the attachment URL, to verify that we're working with a media library image
    if (false !== strpos($attachment_url, $upload_dir_paths['baseurl'])) {

        // If this is the URL of an auto-generated thumbnail, get the URL of the original image
        $attachment_url = preg_replace('/-\d+x\d+(?=\.(jpg|jpeg|png|gif)$)/i', '', $attachment_url);

        // Remove the upload path base directory from the attachment URL
        $attachment_url = str_replace($upload_dir_paths['baseurl'] . '/', '', $attachment_url);

        // Finally, run a custom database query to get the attachment ID from the modified attachment URL
        $attachment_id = $wpdb->get_var($wpdb->prepare("SELECT wposts.ID FROM $wpdb->posts wposts, $wpdb->postmeta wpostmeta WHERE wposts.ID = wpostmeta.post_id AND wpostmeta.meta_key = '_wp_attached_file' AND wpostmeta.meta_value = '%s' AND wposts.post_type = 'attachment'", $attachment_url));

    }

    return $attachment_id;
}

if(!function_exists('tech888f_show_wishlist')){
    function tech888f_show_wishlist(){
        if( defined( 'YITH_WCWL' )){
            /* single product */
            echo '<div class="wishlist-wrap  flex-wrap flex-wrap-wrap">';
            echo do_shortcode('[yith_wcwl_add_to_wishlist label="Add to Wishlist" icon="" link_classes="add_to_wishlist wishlist-link" ]');
            echo tech888f_compare_url();
            echo '</div>';
        }
    }
}

add_action( 'wp_ajax_load_more_image_gallery', 'tech888f_load_more_image_gallery' );
add_action( 'wp_ajax_nopriv_load_more_image_gallery', 'tech888f_load_more_image_gallery' );
if(!function_exists('tech888f_load_more_image_gallery')){
    function tech888f_load_more_image_gallery() {
        $paged = sanitize_text_field($_POST['paged']);
        $load_data = sanitize_text_field($_POST['load_data']);
        $load_data = str_replace('\"', '"', $load_data);
        $load_data = str_replace('\/', '/', $load_data);
        $load_data = json_decode($load_data,true);
        extract($load_data);
        extract($attr);
        $args["post_type"] = 'img_library';
        $args['posts_per_page'] = $number;
        $args['paged'] = $paged + 1;
        $query = new WP_Query($args);
        $count = 1;
        $count_query = $query->post_count;
        $slug = $item_style;
        if($style == 'list') $slug = $item_style_list;
        if($query->have_posts()) {
            while($query->have_posts()) {
                $query->the_post();
                tech888f_get_template_image_gallery($style.'/'.$style,$slug,$attr,true);
                $count++;
            }
        }
        wp_reset_postdata();
        die();
    }
}

add_action( 'wp_ajax_get_data_lazy_script', 'tech888f_get_data_lazy_script' );
add_action( 'wp_ajax_nopriv_get_data_lazy_script', 'tech888f_get_data_lazy_script' );
if(!function_exists('tech888f_get_data_lazy_script')){
    function tech888f_get_data_lazy_script() {
        $data_script = tech888f_get_option("tech888f_lazy_script");
        wp_send_json_success($data_script);
        die();
    }
}
function replace_last_string_in_class($search, $replace, $subject)
{
    $last_str = substr($subject,-1);
    if($last_str == $search)
    {
        $subject = substr_replace($subject, $replace.'"', -1, strlen($search));
    }

    return $subject;
}

function tech888f_get_elementor_content($page_id = '')
{
	if (class_exists("\\Elementor\\Plugin")) {
		$pluginElementor = \Elementor\Plugin::instance();
		$contentElementor = $pluginElementor->frontend->get_builder_content($page_id);
		return $contentElementor;
	}
	else
	{
		return '';
	}
}

function getCategoryHierarchy($catId=0, $taxonomy="category", $bEchoList = false ){

    $args = array(
        "hide_empty" => 0,
        "hierarchical" => 1,
        "taxonomy"=> $taxonomy,
        "parent" => $catId
    );

    $categories = get_categories($args);

    if(count($categories) > 0){

        if ($bEchoList) echo "<ul>";

        foreach ($categories as $category) {
            if ($bEchoList)
                echo "<li>".$category->cat_name."</li>";

            $cats[$category->cat_ID]["category"] =  $category;

            $children = getCategoryHierarchy($category->cat_ID, $taxonomy, $bEchoList );
            if ($children)
                $cats[$category->cat_ID]["children"] = $children;
        }
        if ($bEchoList) echo "</ul>";
    }
    return $cats;
}

/***************************************END Theme Function***************************************/
