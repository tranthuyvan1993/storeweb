<?php
/**
 * Created by Sublime Text 2.
 * User: thanhhiep992
 * Date: 12/08/15
 * Time: 10:20 AM
 */
if(!class_exists('tech888f_Images_LibraryController'))
{
    class tech888f_Images_LibraryController{

        static function _init()
        {
            if(function_exists('stp_reg_post_type'))
            {
                //add_action('init', 'icl_theme_register_custom', 0);
                add_action('init',array(__CLASS__,'_add_post_type'));
            }
        }

        static function _add_post_type()
        {
            $labels = array(
                'name'               => esc_html__('Ảnh Thư Viện','camranh'),
                'singular_name'      => esc_html__('Ảnh Thư Viện','camranh'),
                'menu_name'          => esc_html__('Ảnh Thư Viện','camranh'),
                'name_admin_bar'     => esc_html__('Ảnh Thư Viện','camranh'),
                'add_new'            => esc_html__('Add New','camranh'),
                'add_new_item'       => esc_html__( 'Add New Ảnh Thư Viện','camranh' ),
                'new_item'           => esc_html__( 'New Ảnh Thư Viện', 'camranh' ),
                'edit_item'          => esc_html__( 'Edit Ảnh Thư Viện', 'camranh' ),
                'view_item'          => esc_html__( 'View Ảnh Thư Viện', 'camranh' ),
                'all_items'          => esc_html__( 'All Ảnh Thư Viện', 'camranh' ),
                'search_items'       => esc_html__( 'Search Ảnh Thư Viện', 'camranh' ),
                'parent_item_colon'  => esc_html__( 'Parent Ảnh Thư Viện:', 'camranh' ),
                'not_found'          => esc_html__( 'No Ảnh Thư Viện found.', 'camranh' ),
                'not_found_in_trash' => esc_html__( 'No Ảnh Thư Viện found in Trash.', 'camranh' )
            );

            $args = array(
                'labels'             => $labels,
                'public'             => true,
                'publicly_queryable' => true,
                'show_ui'            => true,
                'show_in_menu'       => true,
                'query_var'          => true,
                'rewrite'            => array( 'slug' => 'thu-vien' ),
                'capability_type'    => 'post',
                'has_archive'        => true,
                'hierarchical'       => false,
                'menu_position'      => null,
                'supports'           => array( 'thumbnail','title' )
            );

            stp_reg_post_type('img_library',$args);
            //self::tech888f_add_custom_taxonomy();
        }
    }

    tech888f_Images_LibraryController::_init();

}
