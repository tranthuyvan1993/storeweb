<?php
/*
 * Template Name: Product action
 *
 *
 * */

get_header();

    if(!function_exists('tech888f_update_product')){
        function tech888f_update_product($update = 'thumbnail',$value,$post_type = 'product',$cats = '') {    
            if(isset($_GET['update_product'])){
                $args = array(
                    'post_type'         => $post_type,
                    'posts_per_page'    => -1,
                    );
                if(!empty($cats)) {
                    $custom_list = explode(",",$cats);
                    $args['tax_query'][]=array(
                        'taxonomy'=>'product_cat',
                        'field'=>'slug',
                        'terms'=> $custom_list
                    );
                }
                $product_query = new WP_Query($args);
                // var_dump($product_query);
                $count = 0;
                if($product_query->have_posts()) {
                    while($product_query->have_posts()) {
                        $product_query->the_post();
                        // var_dump($product_query);
                        switch ($update) {
                            case 'thumb_hover':
                                if(is_array($value)){
                                    $count++;
                                    update_post_meta( get_the_ID(), 'product_thumb_hover', wp_get_attachment_image_url($value[$count],'full'));
                                    if($count == count($value)) $count = -1;
                                }
                                else update_post_meta( get_the_ID(), 'product_thumb_hover',  wp_get_attachment_image_url($value,'full'));
                                break;

                            case 'feature':
                                $check = rand(1,3);
                                if($check % 2 == 0) update_post_meta( get_the_ID(), '_featured', 1);
                                break;

                            case 'cats':
                                wp_set_object_terms( get_the_ID() , $value , 'product_cat' );
                                break;

                            case 'tags':
                                if(is_array($value)){
                                    $tags_key = array_rand($value,3);
                                    $tags = array_intersect_key($value,array_flip($tags_key));
                                }
                                else $tags = $value;
                                wp_set_object_terms( get_the_ID() , $tags , 'product_tag' );
                                break;

                            case 'excerpt':
                                $my_post = array(
                                    'ID'                => get_the_ID(),
                                    'post_excerpt'      => $value,
                                );
                                wp_update_post( $my_post );
                                break;

                            case 'content':
                                $my_post = array(
                                    'ID'                => get_the_ID(),
                                    'post_content'      => $value,
                                );
                                wp_update_post( $my_post );
                                break;

                            case 'title':
                                
                                break;

                            case 'gallery':
                                $gallery = array_rand($value,3);
                                $gallery = array_intersect_key($value,array_flip($gallery));
                                $gallery = implode(',', $gallery);
                                update_post_meta( get_the_ID(), '_product_image_gallery', $gallery);
                                break;

                            case 'thumbnail':
                                if(is_array($value)){
                                    update_post_meta( get_the_ID(), '_thumbnail_id', $value[$count]);
                                    $count++;
                                    if($count == count($value)) $count = 0;
                                }
                                else update_post_meta( get_the_ID(), '_thumbnail_id', $value);
                                break;

                            default:
                                
                                break;
                        }
                    }
                }
                wp_reset_postdata();
            }
        }
    }

    if(!function_exists('tech888f_create_products')){
        function tech888f_create_products($name = array(),$number = 10,$post_type = 'product',$content = '',$excerpt = '') {
            if(isset($_GET['add_product'])){            
                $index = $key_index = 0;
                $products = array();
                if(is_array($name) && !empty($name)){
                    $key_array = array();
                    for ($i=0; $i < $number; $i++) {
                        foreach ($name as $key => $value) {
                            if(isset($value[$key_index])) $products[] = $value[$key_index];
                        }
                        $key_index++;
                        if($key_index == 5) $key_index = 0;
                    }
                    foreach ($name as $key => $value) {
                        $key_array[] = $key;
                    }
                    foreach ($products as $key => $value) {
                        $post = array(
                            'post_content'  => $content,
                            'post_excerpt'  => $excerpt,
                            'post_status'   => "publish",
                            'post_title'    => $value,
                            'post_type'     => $post_type,
                        );
                        $post_id = wp_insert_post( $post );
                        if($post_type == 'product'){
                            $price = rand(50,500);
                            $price_sale = '';
                            $sku = 'No-'.rand(1000,9999).'-'.rand(1,99);
                            if($price % 2 == 0){
                                $price_sale = $price - rand(5,$price-30) % 100;
                            }
                            update_post_meta( $post_id, '_regular_price', $price );
                            update_post_meta( $post_id, '_sale_price', $price_sale );
                            update_post_meta( $post_id, '_sku', $sku);
                            wp_set_object_terms( $post_id, $key_array[$index], 'product_cat' );
                        }
                        $index++;
                        if($index == count($key_array)) $index = 0;
                    }
                }
                else{
                    for ($i=0; $i < $number; $i++) {
                        $post = array(
                            'post_content'  => $content,
                            'post_excerpt'  => $excerpt,
                            'post_status'   => "publish",
                            'post_title'    => $name,
                            'post_type'     => $post_type,
                        );
                        $post_id = wp_insert_post( $post );
                        if($post_type == 'product'){
                            $price = rand(50,500);
                            $price_sale = '';
                            $sku = 'No-'.rand(1000,9999).'-'.rand(1,99);
                            if($price % 2 == 0){
                                $price_sale = $price - rand(5,$price-30) % 100;
                            }
                            update_post_meta( $post_id, '_regular_price', $price );
                            update_post_meta( $post_id, '_sale_price', $price_sale );
                            update_post_meta( $post_id, '_sku', $sku);
                            wp_set_object_terms( $post_id, $key_array[$index], 'product_cat' );
                        }
                    }
                }
            }
        }
    }
    $ids = array(643,644,645,646,657,648,649,650,651);
    $content = '';
    $excerpt = '';
    $tags = array("Fresh","Model","Color full","Beauty","Collection","New trend","Healthy","Funny","Juice","Coffee","Drinks");
    // $ids_foods = array(595,596,597,598,599,600,601,602);
    //  tech888f_update_product('content',$content,'post','');
     //tech888f_update_product('gallery',$ids,'product','foods');
    // tech888f_update_product('thumb_hover',$ids,'product','foods');

    $ids_sweat = array(174,175,176,177,178,179,180,181,182,183,184,185,186,187,188,189);
    //tech888f_update_product('thumbnail',$ids_sweat,'post','');
    // tech888f_update_product('gallery',$ids,'product','sweat-cloth');
    // tech888f_update_product('thumb_hover',$ids,'product','sweat-cloth');

    // $ids_furniture = array(609,610,611,612,613,614,615,616);
    // tech888f_update_product('thumbnail',$ids,'product','furniture');
    // tech888f_update_product('gallery',$ids,'product','furniture');
    // tech888f_update_product('thumb_hover',$ids,'product','furniture');

    // $ids_electronics = array(617,618,619,620,621,622,623);
    // tech888f_update_product('thumbnail',$ids,'product','electronics');
    // tech888f_update_product('gallery',$ids,'product','electronics');
    // tech888f_update_product('thumb_hover',$ids,'product','electronics');

    // $ids_fashions = array(624,625,626,627,628,629,630,631);
    // tech888f_update_product('thumbnail',$ids,'product','fashions');
    // tech888f_update_product('gallery',$ids,'product','fashions');
    // tech888f_update_product('thumb_hover',$ids,'product','fashions');

    // $ids_flowers = array(632,633,634,635,636,637,638,639);
    // tech888f_update_product('thumbnail',$ids);
    // tech888f_update_product('gallery',$ids);
    // tech888f_update_product('thumb_hover',$ids);

    // tech888f_update_product('excerpt',$excerpt);
    // tech888f_update_product('content',$content);
    // tech888f_update_product('tags',$tags);
    // $gallery = '2568,2569,2570';
    // update_post_meta( 2506, '_product_image_gallery', $gallery);
    $name = array(
        "news"  => array(
            "In ấn túi giấy couche",
            "In ấn túi ivory",
            "In ấn túi giấy kraft nâu",
            "In ấn túi giấy kraft trắng",
            "In ấn hộp cứng",
            "In ấn hộp giấy",
            "In ấn hộp giấy thời trang",
            ),
        );
    $number = 16; //number product each category
    // tech888f_create_products($name,$number);
    $content_post = '<img class="alignnone wp-image-651 size-full aligncenter" src="http://demohp.web888.vn/wp-content/uploads/2022/04/in-an-tui-ivory-10-768x1024-1.jpg" alt="" width="768" height="1024" />
    <p style="text-align: center;"><img class="alignnone wp-image-650 size-full" src="http://demohp.web888.vn/wp-content/uploads/2022/04/in-an-tui-ivory-8-768x768-1.jpg" alt="" width="768" height="768" /></p>
    <p style="text-align: center;"><img class="alignnone wp-image-648 size-full" src="http://demohp.web888.vn/wp-content/uploads/2022/04/in-an-tui-ivory-4-768x576-1.jpg" alt="" width="768" height="576" /></p>
    <p style="text-align: center;"><img class="alignnone wp-image-649 size-full" src="http://demohp.web888.vn/wp-content/uploads/2022/04/in-an-tui-ivory-6.jpg" alt="" width="720" height="540" /></p>
    <p style="text-align: center;"><img class="alignnone wp-image-647 size-full" src="http://demohp.web888.vn/wp-content/uploads/2022/04/in-an-tui-ivory-3.jpg" alt="" width="640" height="960" /></p>
    <p style="text-align: center;"><img class="alignnone wp-image-646 size-full" src="http://demohp.web888.vn/wp-content/uploads/2022/04/in-an-tui-ivory-2-768x509-1.jpg" alt="" width="768" height="509" /></p>
    <p style="text-align: center;"><img class="alignnone wp-image-645 size-full" src="http://demohp.web888.vn/wp-content/uploads/2022/04/in-an-tui-coucher-7.jpg" alt="" width="720" height="540" /></p>
    <p style="text-align: center;"><img class="alignnone wp-image-644 size-full" src="http://demohp.web888.vn/wp-content/uploads/2022/04/in-an-tui-coucher-5-768x576-1.jpg" alt="" width="768" height="576" /></p>
    <p style="text-align: center;"><img class="alignnone wp-image-643 size-full" src="http://demohp.web888.vn/wp-content/uploads/2022/04/in-an-tui-coucher-3-768x576-1.jpg" alt="" width="768" height="576" /></p>';
    $excerpt_post = '';
    // tech888f_create_products($name,$number,'custom_product',$content_post,$excerpt_post);
    //$ids = array(246,247,248,249,250,251);
    tech888f_update_product('thumbnail',$ids,'custom_product','');
get_footer();