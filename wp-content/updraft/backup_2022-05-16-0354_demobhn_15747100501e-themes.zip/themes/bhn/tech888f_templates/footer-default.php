<?php
$page_id = apply_filters('tech888f_footer_page_id', tech888f_get_value_by_id('tech888f_footer_page'));
$footer_col_1_title = tech888f_get_option('footer_col_1_title');
$footer_col_1 = tech888f_get_option('footer_col_1');
$background_footer = tech888f_get_option('background_footer');
$footer_col_2_title = tech888f_get_option('footer_col_2_title');
$footer_col_2_subtitle = tech888f_get_option('footer_col_2_subtitle');
$footer_col_2 = tech888f_get_option('footer_col_2');
$footer_col_3_title = tech888f_get_option('footer_col_3_title');
$footer_col_3 = tech888f_get_option('footer_col_3');
$footer_col_4 = tech888f_get_option('footer_col_4');
$footer_col_3_media = tech888f_get_option('footer_col_3_media');
$footer_col_4_title = tech888f_get_option('footer_col_4_title');
$footer_col_4_fb = tech888f_get_option('footer_col_4_fb');
if (!empty($page_id)) { ?>
    <div id="footer" class="footer-page">
        <div class="container">
            <?php echo Tech888f_Template::get_vc_pagecontent($page_id); ?>
        </div>
    </div>
<?php
} else {
?>
    
    <div id="fb-root"></div>
    <script async defer crossorigin="anonymous" src="https://connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v13.0" nonce="6R1V1KsD"></script>
    <div id="footer" class="footer-default hp-footer white relative" style="background: url('<?= $background_footer['url'] ?>') no-repeat top center; ">
        <div class="container hp-footer-top ">
            <div class="row">
                <div class="col-md-3 col-sm-6 padding-bottom-15">
                    <h5 class="footer-title"><?= $footer_col_1_title ?></h5>
                    <div id="header-widget-area" class="chw-widget-area widget-area" role="complementary">
                        <div class="chw-widget">
                            <div class="textwidget">
                                <ul>
                                    <li class="flex align-center item1">
                                    <a title="<?= $footer_col_1[0]['desc'] ?>" href="<?= $footer_col_1[0]['link'] ?>" rel="nofollow"><?= $footer_col_1[0]['desc'] ?></a>
                                    </li>
                                    <li class="flex align-center item1">
                                    <a title="<?= $footer_col_1[1]['desc'] ?>" href="<?= $footer_col_1[1]['link'] ?>" rel="nofollow"><?= $footer_col_1[1]['desc'] ?></a>
                                    </li>
                                    <li class="flex align-center item1">
                                    <a title="<?= $footer_col_1[2]['desc'] ?>" href="<?= $footer_col_1[2]['link'] ?>" rel="nofollow"><?= $footer_col_1[2]['desc'] ?></a>
                                    </li>
                                    <li class="flex align-center item1">
                                    <a title="<?= $footer_col_1[3]['desc'] ?>" href="<?= $footer_col_1[3]['link'] ?>" rel="nofollow"><?= $footer_col_1[3]['desc'] ?></a>
                                    </li>
                                    <li class="flex align-center item1">
                                    <a title="<?= $footer_col_1[4]['desc'] ?>" href="<?= $footer_col_1[4]['link'] ?>" rel="nofollow"><?= $footer_col_1[4]['desc'] ?></a>
                                    </li>
                                    <li class="flex align-center item1">
                                    <a title="<?= $footer_col_1[5]['desc'] ?>" href="<?= $footer_col_1[5]['link'] ?>" rel="nofollow"><?= $footer_col_1[5]['desc'] ?></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 padding-bottom-15">
                    <h5 class="footer-title"><?= $footer_col_2_title ?></h5>
                    <div id="header-widget-area" class="chw-widget-area widget-area" role="complementary">
                        <div class="chw-widget">
                            <div class="textwidget">
                                <ul>
                                    <li class="flex align-center item1">
                                    <a title="<?= $footer_col_2[0]['desc'] ?>" href="<?= $footer_col_2[0]['link'] ?>" rel="nofollow"><?= $footer_col_2[0]['desc'] ?></a>
                                    </li>
                                    <li class="flex align-center item1">
                                    <a title="<?= $footer_col_2[1]['desc'] ?>" href="<?= $footer_col_2[1]['link'] ?>" rel="nofollow"><?= $footer_col_2[1]['desc'] ?></a>
                                    </li>
                                    <li class="flex align-center item1">
                                    <a title="<?= $footer_col_2[2]['desc'] ?>" href="<?= $footer_col_2[2]['link'] ?>" rel="nofollow"><?= $footer_col_2[2]['desc'] ?></a>
                                    </li>
                                    <li class="flex align-center item1">
                                    <a title="<?= $footer_col_2[3]['desc'] ?>" href="<?= $footer_col_2[3]['link'] ?>" rel="nofollow"><?= $footer_col_2[3]['desc'] ?></a>
                                    </li>
                                    <li class="flex align-center item1">
                                    <a title="<?= $footer_col_2[4]['desc'] ?>" href="<?= $footer_col_2[4]['link'] ?>" rel="nofollow"><?= $footer_col_2[4]['desc'] ?></a>
                                    </li>
                                    <li class="flex align-center item1">
                                    <a title="<?= $footer_col_2[5]['desc'] ?>" href="<?= $footer_col_2[5]['link'] ?>" rel="nofollow"><?= $footer_col_2[5]['desc'] ?></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-sm-12 padding-bottom-15">
                    <h5 class="footer-title"><?= $footer_col_3_title ?></h5>
                    <div class="chw-widget">
                        <div class="textwidget">
                            <ul class="row">
                                <li class="col-sm-6"><a title="" href="<?= $footer_col_3[0]['link'] ?>"><?= $footer_col_3[0]['desc'] ?></a></li>
                                <li class="col-sm-6"><a title="" href="<?= $footer_col_3[1]['link'] ?>"><?= $footer_col_3[1]['desc'] ?></a></li>
                                <li class="col-sm-6"><a title="" href="<?= $footer_col_3[2]['link'] ?>"><?= $footer_col_3[2]['desc'] ?></a></li>
                                <li class="col-sm-6"><a title="" href="<?= $footer_col_3[3]['link'] ?>"><?= $footer_col_3[3]['desc'] ?></a></li>
                                <li class="col-sm-6"><a title="" href="<?= $footer_col_3[4]['link'] ?>"><?= $footer_col_3[4]['desc'] ?></a></li>
                                <li class="col-sm-6"><a title="" href="<?= $footer_col_3[5]['link'] ?>"><?= $footer_col_3[5]['desc'] ?></a></li>
                                <li class="col-sm-6"><a title="" href="<?= $footer_col_3[6]['link'] ?>"><?= $footer_col_3[6]['desc'] ?></a></li>
                                <li class="col-sm-6"><a title="" href="<?= $footer_col_3[7]['link'] ?>"><?= $footer_col_3[7]['desc'] ?></a></li>
                                <li class="col-sm-6"><a title="" href="<?= $footer_col_3[8]['link'] ?>"><?= $footer_col_3[8]['desc'] ?></a></li>
                                <li class="col-sm-6"><a title="" href="<?= $footer_col_3[9]['link'] ?>"><?= $footer_col_3[9]['desc'] ?></a></li>
                                <li class="col-sm-6"><a title="" href="<?= $footer_col_3[10]['link'] ?>"><?= $footer_col_3[10]['desc'] ?></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="footer-address">
                <h5 class="footer-title"><?= $footer_col_4_title ?></h5>
                <div id="header-widget-area" class="chw-widget-area widget-area" role="complementary">
                    <div class="chw-widget">
                        <div class="textwidget">
                            <div class="row">
                                <div class="address-item col-lg-3 col-md-6">
                                    <p class="province mb-0"><?= $footer_col_4[0]['province'] ?></p>
                                    <p class="mb-0"><?= $footer_col_4[0]['desc'] ?></p>
                                </div>
                                <div class="address-item col-lg-3 col-md-6">
                                    <p class="province mb-0"><?= $footer_col_4[1]['province'] ?></p>
                                    <p class="mb-0"><?= $footer_col_4[1]['desc'] ?></p>
                                </div>
                                <div class="address-item col-lg-3 col-md-6">
                                    <p class="province mb-0"><?= $footer_col_4[1]['province'] ?></p>
                                    <p class="mb-0"><?= $footer_col_4[1]['desc'] ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="bg-mainbold white padding-top-bottom-5 text-center italic">© Bản quyền thuộc tech888.vn - Thiết kế bởi Toanngo9222</div>
<?php
}
?>