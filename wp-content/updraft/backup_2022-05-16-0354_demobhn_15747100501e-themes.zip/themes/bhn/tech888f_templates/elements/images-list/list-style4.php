<?php
if(empty($itemres)) $itemres = '0:1,360:2,767:3,990:4,1024:5,1199:6';
?>
<div class="images anh_style2">
    <?php
    if(!empty($title)) echo '<h3 class="block-title">'.esc_html($title).'</h3>';
    if(!empty($des)) echo '<p class="desc">'.esc_html($des).'</p>';
    ?>
    <div class="wrap-item">
        <div class="block-payment text-center">
            <?php if ($display == "slider") { ?>
                <div class="item-image-list-slider wrap-item smart-slider" data-item="<?php echo esc_attr($item)?>" data-speed="<?php echo esc_attr($speed)?>"
                     data-itemres="<?php echo esc_attr($itemres)?>"
                     data-prev="" data-next=""
                     data-pagination="" data-navigation="true">
                    <?php
                    if(is_array($data)){
                        foreach ($data as $key => $value) {
                            $value = array_merge($default_val,$value);
                            $attr_item = array(
                                'title' => $value['title'],
                                'alt' => $value['des'],
                            );
                            ?>
                            <div class="brand_list">
                                <?php echo wp_get_attachment_image($value['image'],$size,false,$attr_item);?>
                            </div>


                        <?php }
                    }?>
                </div>
            <?php } else { ?>
                <ul class="item-image-list img_1">
                    <?php
                    if(is_array($data)){
                        foreach ($data as $key => $value) {
                            $value = array_merge($default_val,$value);
                            $attr_item = array(
                                'title' => $value['title'],
                                'alt' => $value['des'],
                            );
                            ?>
                            <li class="mota">
                                <div class="img">
                                    <?php echo wp_get_attachment_image($value['image'],$size,false,$attr_item);?>
                                </div>
                                <div class="text-mota">
                                    <div class="title">
                                        <?php if(!empty($value['link'])):?>
                                        <a href="<?php echo esc_url($value['link']);?>" title="<?php echo esc_attr($value['title']);?>" class="adv-thumb-link">
                                            <?php endif;?>
                                            <h4 class="mota_tieude"><?php echo esc_html($value['title']); ?></h4>
                                            <?php if(!empty($value['link'])):?>
                                        </a>
                                    <?php endif;?>
                                    </div>
                                    <div class="mota_des"><p><?php echo esc_html($value['des']); ?></p></div>
                                </div>
                            </li>
                        <?php }
                    }?>
                </ul>
            <?php } ?>
        </div>
    </div>
</div>