<?php
if(empty($itemres)) $itemres = '0:1,360:2,767:3,990:4,1000:5,1299:6';
?>
<div class="images-slider <?php echo esc_attr($el_class);?>">
    <?php
    if(!empty($title)) echo '<h3 class="block-title">'.esc_html($title).'</h3>';
    if(!empty($des)) echo '<p class="desc">'.esc_html($des).'</p>';
    ?>
    <div class="wrap-item smart-slider owl-carousel owl-theme navi-nav-style"
         data-item="" data-speed="<?php echo esc_attr($speed);?>"
         data-itemres="<?php echo esc_attr($itemres)?>"
         data-prev='' data-next=''
         data-pagination="" data-navigation="">
        <?php
        if(is_array($data)){
            foreach ($data as $key => $value) {
                $value = array_merge($default_val,$value);
                $attr_item = array(
                    'title' => $value['title'],
                    'alt' => $value['des'],
                );
                if(empty($size)) $size = "full";
                ?>
                <div class="item-image-list">
                    <div class="banner-advs text-center">
                        <div class="img-outer">
                            <?php if(!empty($value['link'])):?>
                            <a href="<?php echo esc_url($value['link']);?>" title="<?php echo esc_attr($value['title']);?>" class="adv-thumb-link round img-wrap">
                                <?php endif;?>
                                <?php echo wp_get_attachment_image($value['image'],$size,false,$attr_item);?>
                                <?php if(!empty($value['link'])):?>
                            </a>
                        <?php endif;?>
                        </div>
                    </div>
                </div>
            <?php }
        }?>
    </div>
</div>