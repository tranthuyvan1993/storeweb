<?php
$attr = array(
    'size' => $size,
    'column' => $column,
    'style' => 'grid',
    'item_style_list' => '',
);
if (empty($item)) $item = '3';
if (empty($itemres)) $itemres = '0:1,840:2,990:3';
?>

<?php if ($display == 'grid') {

    ?>
    <div class="block-element <?php echo esc_attr($el_class); ?> js-content-wrap"
         data-column="<?php echo esc_attr($column) ?>">
        <?php
        if (!empty($title)) echo '<h3 class="intr-cate-title title24 fontosw font-bold text-uppercase fixlh"><span class="black222">' . esc_html($title) . '</span></h3>';
        ?>
        <div class="js-content-main list-service-wrap row">
            <?php foreach ($data as $key => $value) {
                $par_cate_url = '#';
                if (!empty($value['link'])) {
                    $par_cate_url = $value['link'];
                }
                ?>
                <div class="list-col-item list-<?php echo esc_html($column); ?>-item">
                    <div class="intr-cate intr-cate-default <?php if(!empty($value['custom_class'])) echo esc_attr($value['custom_class']) ?>" data-href="<?php if (!empty($par_cate_url)) echo esc_url($par_cate_url); ?>">
                        <h3 class="title-wrap text-uppercase title14 fixlh font-400">
                            <a class="black000 service-title" href="<?php if (!empty($par_cate_url)) echo esc_url($par_cate_url); ?>">
                                <?php if (!empty($value["title_1"])) echo esc_html($value['title_1']) ?></a>
                            <a class="black000 service-title" href="<?php if (!empty($par_cate_url)) echo esc_url($par_cate_url); ?>">
                                <?php if (!empty($value["title_2"])) echo esc_html($value['title_2']) ?></a>
                        </h3>
                        <div class="img-wrap"><?php if(!empty($value["image"])) echo wp_get_attachment_image($value["image"]) ?></div>
                        <div class="desciption title15">
                            <div class="desc desc1 white"><?php if (!empty($value['des'])) echo esc_html($value['des']) ?></div>
                            <div class="desc desc2 white"><?php if (!empty($value['des2'])) echo esc_html($value['des2']) ?></div>
                            <div class="desc desc3 white"><?php if (!empty($value['des3'])) echo esc_html($value['des3']) ?></div>
                        </div>
                    </div>
                </div>
                <?php
            } ?>
        </div>
    </div>

<?php } elseif ($display == 'slider') {

} ?>
