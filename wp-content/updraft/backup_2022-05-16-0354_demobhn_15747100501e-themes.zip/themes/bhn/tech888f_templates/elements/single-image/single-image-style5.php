<?php
/**
 * Created by PhpStorm.
 * User: dell3537
 * Date: 12/18/2019
 * Time: 11:32 PM
 */

if (empty($size)){
    $size = "full";
}
else{
    $size  = explode("x",$size);
}
?>
<div class="single-image-wrap style5 overflow-hidden pst-relative <?php echo esc_attr($el_class) ?>">
    <div class="bg-overlay  parallax-background pst-absolute">
        <div class="parallax-inner" style="background:url(<?php echo wp_get_attachment_url($image,$size,false) ?>)">
            <?php echo wp_get_attachment_image($image,$size,false,"");?>
        </div>
    </div>
    <?php
    if (!empty($url)) echo '<a class="img-wrap" href="' . esc_url($url) . '">'; else echo '<div class="img-wrap">';
    if (!empty($image)) echo wp_get_attachment_image($image, $size, false, '');
    if (!empty($url)) echo "</a>"; else echo '</div>';
    ?>
</div>
