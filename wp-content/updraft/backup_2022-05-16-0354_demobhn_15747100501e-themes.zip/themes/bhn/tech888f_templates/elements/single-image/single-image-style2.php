<?php
/**
 * Created by PhpStorm.
 * User: dell3537
 * Date: 12/18/2019
 * Time: 11:35 PM
 */

if (empty($size)) $size = "full";
?>
<div class="single-image-style2-wrap <?php echo esc_attr($el_class) ?>">
    <div class="img-wrap overflow-hidden">
        <?php
        if (!empty($url)) echo '<a class="hvr-grow" href="' . esc_url($url) . '">';
        if (!empty($image)) echo wp_get_attachment_image($image, $size, false, '');
        if (!empty($url)) echo "</a>";
        ?>
    </div>
    <div class="img-info">
        <?php if (!empty($title)) echo '<h3 class="img-title title18 black000 font-bold text-uppercase text-center">' . esc_html($title) . '</h3>' ?>
        <?php if (!empty($email)) echo '<div class="img-email text-center"><a href="'.esc_url($url).'">'.esc_html($email).'</a></div>' ?>
    </div>
</div>