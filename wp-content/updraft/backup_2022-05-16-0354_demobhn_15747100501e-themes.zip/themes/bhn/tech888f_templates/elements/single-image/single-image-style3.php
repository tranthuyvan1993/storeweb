<?php
/**
 * Created by PhpStorm.
 * User: dell3537
 * Date: 12/18/2019
 * Time: 11:35 PM
 */

if (empty($size)) $size = "full";
?>
<div class="single-image-style3-wrap <?php echo esc_attr($el_class) ?>">
    <div class="img-wrap overflow-hidden pst-relative">
        <?php
        if (!empty($video)) echo '<a class="hvr-grow" data-fancybox="youtube-fancy" href="' . esc_url($video) . '">';
        if (!empty($video)) echo '<i class="fa fa-play-circle title72 pst-absolute color"></i>';
        if (!empty($image)) echo wp_get_attachment_image($image, $size, false, '');
        if (!empty($video)) echo "</a>";
        ?>
    </div>
</div>