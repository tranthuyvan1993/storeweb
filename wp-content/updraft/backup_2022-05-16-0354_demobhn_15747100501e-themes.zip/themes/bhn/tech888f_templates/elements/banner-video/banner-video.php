<?php
/**
 * Created by PhpStorm.
 * User: windear
 * Date: 11/6/2018
 * Time: 10:06 AM
 */

switch ($style) {
    default:
        $html .=    '<div class="banner-video '.esc_attr($style).'">
                                <a class="video-button" href="'.esc_url("#").'" title="'.esc_attr__('Play', 'posolo' ).'">
                                    <i class="la la-play-circle"></i>
                                </a>
                                <video '.$settings.' oncontextmenu="return false;" class="video-play">
                                    <source src="'.esc_url($video_link).'" type="video/mp4">
                                </video>
                            </div>';

        break;
}
return $html;