<?php
$attr = array(
    'size' => $size,
    'column' => $column,
    'excerpt' => $excerpt,
    'item_style' => $item_style,
    'style' => 'grid',
    'item_style_list' => '',
);
?>
<div class="block-element <?php echo esc_attr($el_class); ?> js-content-wrap"
     data-column="<?php echo esc_attr($column) ?>">
    <?php
    if (!empty($title)) echo '<h3 class="title18 font-bold text-uppercase">' . esc_html($title) . '</h3>';
    if (!empty($des)) echo '<p class="desc-block">' . esc_html($des) . '</p>';
    ?>
    <div class="js-content-main list-project-wrap row">
        <?php
        if ($post_query->have_posts()) {
            while ($post_query->have_posts()) {
                $post_query->the_post();
                tech888f_get_template_project('grid/grid', $item_style, $attr, true);
            }
        }
        ?>
        <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="return-cate-wrap">
                <a href="<?php echo get_post_type_archive_link('project') ?>" class="return-category">
                    <?php echo esc_html__("VIEW ALL PROJECTS", "posolo"); ?>
                </a>
            </div>
        </div>
    </div>
</div>