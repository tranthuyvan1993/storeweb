<div class=" tech888f-progess-bar <?php echo esc_attr($el_class)?>">
    <?php if(!empty($title)):?><h3 class="title18 font-bold"><?php echo esc_html($title)?></h3><?php endif;?>
    <div class="pb-content-wrap">
        <?php
        if(is_array($data)){
            foreach ($data as $key => $value){
                echo '<div class="pb-content-item">';
                $value = array_merge($default_val,$value);
                ?>
                <div class="progess-bar-wrap">
                    <div class="bg-progessbar" <?php if(!empty($value['bgcolor'])):?> style="background: <?php echo esc_attr($value['bgcolor']) ?>" <?php endif; ?> >
                        <span data-value="<?php if(!empty($value['value'])) : echo esc_attr($value['value']); else : echo esc_attr("0"); endif;  ?>" class="single-bar" <?php if(!empty($value['color']) && !empty($value['value'])):?> style="background: <?php echo esc_attr($value['color']).esc_attr(";") ?>" <?php endif; ?>></span>
                    </div>
                </div>
                <?php
                echo '<div class="label-wrap flex-wrap jtf-content-space-between">';
                if(!empty($value['label'])): ?> <span class="pb-label"><?php echo esc_html($value['label']) ?></span><?php endif;
                if(!empty($value['value'])): ?> <span class="pb-value pb-value font-bold color title18"><?php echo esc_html($value['value']).esc_html("%") ?></span><?php endif;
                echo '</div>';
                echo '</div>';
            }
        }
        ?>
    </div>
</div>