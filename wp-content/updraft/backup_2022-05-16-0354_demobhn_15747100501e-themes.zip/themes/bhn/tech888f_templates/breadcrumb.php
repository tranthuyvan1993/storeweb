<?php
if(!isset($breadcrumb)) $breadcrumb = tech888f_get_option('tech888f_show_breadrumb','1');
if(!isset($el_class)) $el_class = '';
if($breadcrumb == '1' && !(is_tax('project-service'))):
    $b_class = tech888f_fill_css_background(tech888f_get_option('tech888f_bg_breadcrumb'));
	$step = '';
?>

<?php endif;?>