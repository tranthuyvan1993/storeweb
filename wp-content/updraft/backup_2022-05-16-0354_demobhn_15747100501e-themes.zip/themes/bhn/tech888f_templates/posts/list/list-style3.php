<?php
if(empty($size_list)) $size_list = 'full';
global $post;
?>
<div class="col-md-12 col-sm-12 col-xs-12">
    <?php  ?>
    <div class="item-post item-post-large item-default">
        <div class="row">
            <?php if(has_post_thumbnail()):?>
                <div class="col-md-5 col-sm-6 col-xs-12">
                    <div class="post-thumb banner-advs zoom-image overlay-image">
                        <a href="<?php echo esc_url(get_the_permalink())?>" class="adv-thumb-link">
                            <?php echo get_the_post_thumbnail(get_the_ID(),$size_list)?>
                        </a>
                    </div>
                </div>
            <?php endif;?>
            <div class="col-md-4 col-sm-6 col-xs-12">
                <div class="post-info">
                    <div class="date-wrap"><?php echo get_the_date() ?></div>
                    <h3 class="title14 text-uppercase font-normal post-title">
                        <a href="<?php echo esc_url(get_the_permalink()); ?>">
                            <?php the_title()?>
                            <?php echo (is_sticky()) ? '<i class="fa fa-star"></i>':''?>
                        </a>
                    </h3>
                    <?php if(has_excerpt() || !empty($post->post_content)):?><p class="desc"><?php echo tech888f_substr(get_the_excerpt(),0,250);?></p><?php endif;?>
                    <a href="<?php echo esc_url(get_the_permalink()); ?>" class="readmore"><?php esc_html_e("Read more","posolo")?></a>
                </div>
            </div>
            <?php tech888f_output_sidebar('right')?>
        </div>
    </div>
</div>