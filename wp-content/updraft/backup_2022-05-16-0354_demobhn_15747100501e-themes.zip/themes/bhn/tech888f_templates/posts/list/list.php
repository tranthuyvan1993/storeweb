<?php
if (empty($size_list)) $size_list = array(300, 200);
global $post;
?>
<div class="col-md-12 col-sm-12 col-xs-12">
    <div class="item-post item-post-list item-list-default flex-wrap">
        <?php if (has_post_thumbnail()) : ?>
            <div class="post-thumb">
                <a href="<?php echo esc_url(get_the_permalink()) ?>" class="img-wrap display-block overflow-hidden">
                    <?php echo get_the_post_thumbnail(get_the_ID(), $size_list) ?>
                </a>
            </div>
        <?php
        else :
        ?>
            <div class="post-thumb">
                <a href="<?php echo esc_url(get_the_permalink()) ?>" class="img-wrap display-block overflow-hidden">
                    <img src="<?php echo esc_url(get_template_directory_uri() . '/assets/css/images/thumbnail.jpg') ?>" />
                </a>
            </div>
        <?php
        endif;
        ?>
        <div class="post-info">
            <h3 class="title18 post-title"><a class="black000 font-bold" href="<?php echo esc_url(get_the_permalink()); ?>"><?php the_title() ?></a></h3>
            <?php // tech888f_display_metabox(); ?>
            <?php if (has_excerpt() || !empty($post->post_content)) : ?><p class="desc"><?php echo get_the_excerpt(); ?></p><?php endif; ?>
            <a href="<?php echo esc_url(get_the_permalink()); ?>" class="readmore"><?php esc_html_e("Xem thêm", "posolo") ?></a>
        </div>
    </div>
</div>