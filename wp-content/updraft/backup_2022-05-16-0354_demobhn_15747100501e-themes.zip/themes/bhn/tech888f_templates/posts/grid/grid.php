<?php
if(empty($size)) $size = array(350,200);
$size = tech888f_size_random($size);
$post_date = get_the_date( 'F j, Y' );
?>
<?php if(isset($column)):?><div class="list-col-item list-<?php echo esc_attr($column)?>-item"><?php endif;?>
<div class="item-post item-post-default grid-item-default">
    <div class="post-thumb banner-advs zoom-image overlay-image">
        <a href="<?php echo esc_url(get_the_permalink()) ?>" class="adv-thumb-link">
            <?php echo get_the_post_thumbnail(get_the_ID(),$size);?>
        </a>
    </div>
    <div class="post-info text-center">
        <div class="post-date font-bold text-uppercase"><a class="color" href="<?php echo esc_url(get_the_permalink()) ?>"><?php echo $post_date; ?></a></div>
        <h3 class="post-title"><a class="font-bold title16 black000" href="<?php echo esc_url(get_the_permalink()) ?>"><?php the_title()?></a></h3>
    </div>
</div>
<?php if(isset($column)):?></div><?php endif;?>