<?php
if (empty($size)) $size = array(450, 300);
$size = tech888f_size_random($size);
$post_date = get_the_date('F j, Y');
?>
<?php if (isset($column)): ?><div class="list-col-item list-<?php echo esc_attr($column) ?>-item"><?php endif; ?>
    <div class="item-post item-post-style-2 flex-wrap flex-wrap-wrap align-items-center">
        <div class="post-thumb banner-advs zoom-image overlay-image">
            <a href="<?php echo esc_url(get_the_permalink()) ?>" class="adv-thumb-link">
                <?php echo get_the_post_thumbnail(get_the_ID(), $size); ?>
            </a>
        </div>
        <div class="post-info">
            <h3 class="title20 post-title no-margin"><a class="fontphilo blackmain"
                                                        href="<?php echo esc_url(get_the_permalink()) ?>"><?php the_title() ?></a>
            </h3>
            <?php if (get_the_content()) echo '<p class="desc">' . tech888f_substr(strip_shortcodes(get_the_content()), 0, 500) . ' [...]</p>'; ?>
            <a href="<?php echo esc_url(get_the_permalink()) ?>"
               class="btn-readmore text-uppercase color flex-wrap flex-wrap-wrap align-items-center font-bold"><span><?php echo esc_html__("Xem thêm", "posolo") ?></span><i
                        class="fa fa-angle-double-right title18"></i></a>
        </div>
    </div>
<?php if (isset($column)): ?></div><?php endif; ?>