<?php
$data = '';
global $post;
if (empty($size)) $size = 'full';
$tech888f_image_blog = get_post_meta(get_the_ID(), 'format_image', true);
if($check_thumb == '1'){
    if(isset($tech888f_image_blog['id'])){
        $data .='<div class="single-post-thumb banner-advs">
                    '.wp_get_attachment_image($tech888f_image_blog['id'],'full').'
                </div>';
    }
    else{
        if (has_post_thumbnail()) {
            $data .= '<div class="single-post-thumb banner-advs">
                        '.get_the_post_thumbnail(get_the_ID(),$size).'
                    </div>';
        }
    }
}
/*$list_img_obj = rwmb_meta('post_image_lst_mtb');*/
$post_style = tech888f_get_option('tech888f_post_detail_style', '');
?>
<div class="content-single-blog <?php echo (is_sticky()) ? 'sticky' : '' ?>">
    <?php if (!empty($data)) echo apply_filters('tech888f_output_content', $data); ?>
    <div class="content-post-default ">
            <div class="single-post-default-wrap">
                    <div class="single-post-info">
                        <h2 class="title30 black000 post-detail-title font-900 ">
                            <?php the_title() ?>
                        </h2>
                        <?php tech888f_display_metabox();?>
                        <div class="detail-content-wrap clearfix"><?php the_content(); ?></div>
                    </div>
            </div>
    </div>
</div>