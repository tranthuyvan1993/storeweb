<?php
$check_navigation   = tech888f_get_option('post_single_navigation','1');
if($check_navigation == '1'):
	$previous_post = get_previous_post();
	$next_post = get_next_post();
?>
<div class="post-control">
	<div class="row">
		<div class="col-md-6 col-sm-6 col-xs-6">
			<?php if(!empty( $previous_post )):?>
            <h3 class="title14 text-left"><a href="<?php echo esc_url(get_permalink( $previous_post->ID )); ?>" class="prev-post flex-wrap align-items-center"><i class="li li-arrow-left"></i> <span><?php echo esc_html__("Previous Post","posolo")?></span></a></h3>
            <?php endif;?>
		</div>
		<div class="col-md-6 col-sm-6 col-xs-6">
			<?php if(!empty( $next_post )):?>
            <h3 class="title14 text-right"><a href="<?php echo esc_url(get_permalink( $next_post->ID )); ?>" class="next-post flex-wrap align-items-center"> <span><?php echo esc_html__("Next Post","posolo")?></span><i class="li li-arrow-right"></i> </a></h3>
            <?php endif;?>
		</div>
	</div>
</div>
<?php endif;?>