<?php
$id = get_the_ID();
if (is_front_page() && is_home()) $id = (int)get_option('page_on_front');
if (!is_front_page() && is_home()) $id = (int)get_option('page_for_posts');
if ($id) $title = get_the_title($id);
else $title = esc_html__("Blog", "posolo");
if (is_archive()) $title = get_the_archive_title();
if (is_search()) $title = esc_html__("Search Result", "posolo");
if (tech888f_is_woocommerce_page()) $title = woocommerce_page_title(false);
?>

<?php if ($check_type == '1' || $check_number == '1'): ?>
    <div class="top-filter clearfix">
        <ul class="sort-pagi-bar list-inline-block pull-right">
            <?php
            global $post, $wp_query;
            if (!isset($check_order)) $check_order = false;
            if (function_exists('is_shop')) if (is_shop()) $check_order = true;
            if (isset($post->post_content)) if (strpos($post->post_content, '[sv_shop')) $check_order = true;
            if ($check_order == true) $add_class = 'load-shop-ajax';
            else $add_class = '';
            $orderby = apply_filters('woocommerce_default_catalog_orderby', get_option('woocommerce_default_catalog_orderby'));
            if (isset($_GET['orderby'])) $orderby = sanitize_text_field($_GET['orderby']);
            if ($check_order):?>
                <li>
                    <div class="sort-by">
                        <div class="select-box inline-block">
                            <?php tech888f_catalog_ordering($wp_query, $orderby, true, $add_class); ?>
                        </div>
                    </div>
                </li>
            <?php endif;
            ?>
            <?php if ($check_number == '1'):
                $source = 'blog';
                if (tech888f_is_woocommerce_page()) $source = 'shop';
                $list = tech888f_get_option($source . '_number_filter_list');
                if (empty($list)) {
                    $list = array(12, 16, 20, 24);
                } else {
                    $temp = array();
                    foreach ($list as $value) {
                        $temp[] = (int)$value['number'];
                    }
                    $list = $temp;
                }
                $number_df = get_option('posts_per_page');
                if (!in_array((int)$number_df, $list)) $list = array_merge(array((int)$number_df), $list);
                if (!in_array((int)$number, $list)) $list = array_merge(array((int)$number), $list);
                if (isset($wp_query->query_vars['posts_per_page'])) $number = $wp_query->query_vars['posts_per_page'];
                if (isset($_GET['number'])) $number = sanitize_text_field($_GET['number']);
                ?>
                <li>
                    <div class="dropdown-box show-by">
                        <a href="#" class="dropdown-link"><span
                                    class="silver number"><?php echo esc_html((int)$number) ?><?php echo esc_html__(" items per page", "posolo") ?></span></a>
                        <ul class="dropdown-list list-none">
                            <?php
                            if (is_array($list)) {
                                foreach ($list as $key => $value) {
                                    if ($value == 0) {
                                        unset($list[$key]);
                                    }
                                }
                                foreach ($list as $value) {
                                    if ($value == $number) $active = ' active';
                                    else $active = '';
                                    echo '<li><a data-number="' . esc_attr($value) . '" class="' . esc_attr($add_class . $active) . '" href="' . esc_url(tech888f_get_key_url('number', $value)) . '">' . $value . ' ' . esc_html__("items per page", "posolo") . '</a></li>';
                                }
                            }
                            ?>
                        </ul>
                    </div>
                </li>
            <?php endif; ?>
            <?php if ($check_type == '1'): ?>
                <li>
                    <div class="view-type">
                        <a data-type="grid" href="<?php echo esc_url(tech888f_get_key_url('type', 'grid')) ?>"
                           class="grid-view <?php echo esc_attr($add_class) ?> <?php if ($style == 'grid') echo 'active' ?>"><i
                                    class="fa fa-th-large"></i></a>
                        <a data-type="list" href="<?php echo esc_url(tech888f_get_key_url('type', 'list')) ?>"
                           class="list-view <?php echo esc_attr($add_class) ?> <?php if ($style == 'list') echo 'active' ?>"><i
                                    class="fa fa-reorder"></i></a>
                    </div>
                </li>
            <?php endif; ?>
        </ul>
    </div>
<?php endif; ?>
