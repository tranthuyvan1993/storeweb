<?php
$scroll_top = tech888f_get_value_by_id('show_scroll_top');
if($scroll_top == '1'):?>
<a href="#" class="scroll-top dark"><i class="fa fa-angle-up" aria-hidden="true"></i></a>
<?php endif;