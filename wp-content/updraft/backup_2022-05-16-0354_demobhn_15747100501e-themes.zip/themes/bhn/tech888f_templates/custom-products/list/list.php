<?php
if(empty($size)) $size = array(222,288);
//$size = tech888f_size_random($size);
?>
<div class="item-project-wrapper">
    <div class="item-project">
        <div class="post-thumb">
            <a href="<?php echo esc_url(get_the_permalink()) ?>" class="image-thumb">
                <?php echo get_the_post_thumbnail(get_the_ID(),$size);?>
            </a>
        </div>
        <div class="post-info">
            <h3 class="no-margin text-uppercase title11 post-title"><a href="<?php echo esc_url(get_the_permalink()) ?>"><?php the_title()?></a></h3>
        </div>
    </div>
</div>
