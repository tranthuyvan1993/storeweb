<?php
$page_id = apply_filters('tech888f_header_page_id', tech888f_get_value_by_id('tech888f_header_page'));
$address = tech888f_get_option('header_top_address');
$address_img = tech888f_get_option('header_top_address_image');
$email = tech888f_get_option('header_top_email');
$email_img = tech888f_get_option('header_top_email_image');
$contact = tech888f_get_option('header_top_contact');
$contact_img = tech888f_get_option('header_top_contact_image');
$logo = tech888f_get_option('header_top_logo');
?>

<?php
if (!empty($page_id)) {
?>
    <div id="header" class="header-page">
        <div class="container">
            <?php echo Tech888f_Template::get_vc_pagecontent($page_id); ?>
        </div>
    </div>
<?php
} else { ?>
    <div id="header" class="header header-default header-page">
        <div class="header-top-default hd1-row1">
            <div class="logo">
                <a class="display-block" href="<?php echo home_url( '/'); ?>"><img src="<?php echo $logo['url']; ?>" alt="" width="100"></a>
                <!-- <a class="display-block" href="" alt="" width="100"><img src="https://www.kiotviet.vn/wp-content/themes/kiotviet/images/kiotvietLogo.svg" alt="" width="100"></a> -->
            </div>
            <div class="bg-mainbold">
                <?php if (has_nav_menu('primary')) { ?>
                    <div class="text-center">
                        <nav class="main-nav">
                            <?php wp_nav_menu(
                                array(
                                    'theme_location'    => 'primary',
                                    'container'         => false,
                                    'menu_class'      => 'list-none',
                                    'walker'            => new Tech888f_Walker_Nav_Menu(),
                                )
                            ); ?>
                            <a href="#" class="toggle-mobile-menu"><span></span></a>
                        </nav>
                    </div>
                <?php } ?>
            </div>
            <div class="login-form">
                <ul class="flex justify-end font16">
                    <li class=""><a class="btn btn-outline-primary btn-sm" href="">Đăng ký</a></li>
                    <li class=""><a class="btn btn-primary btn-sm" href="">Đăng nhập</a></li>
                </ul>
            </div>
        </div>
    </div>
<?php
}
?>