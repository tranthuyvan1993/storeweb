<?php
$page_id = apply_filters('tech888f_header_page_id', tech888f_get_value_by_id('tech888f_header_page'));
?>

<?php
if (!empty($page_id)) {
?>
    <div id="header" class="header-page">
        <div class="container">
            <?php echo Tech888f_Template::get_vc_pagecontent($page_id); ?>
        </div>
    </div>
<?php
} else { ?>
    <div id="header" class="header header-default header-page">
        <div class="header-top-default hd1-row1">
            <div class="container">
                <div class="row">
                    <div class="col-logo col-md-2 col-sm-6 col-xs-6">
                        <div class="logo pull-right">
                            <div class="logo">
                                <div class="text-logo">
                                    <a>
                                        <div class="namelogo fontwo title45 font-300" href="<?php echo esc_url(home_url('/')); ?>" title="<?php echo esc_attr__("logo", "posolo"); ?>">
                                            <?php $tech888f_logo = tech888f_get_option('logo'); ?>
                                            <?php if ($tech888f_logo != '') {
                                                echo '<h1 class="hidden">' . get_bloginfo('name', 'display') . '</h1><img src="' . esc_url($tech888f_logo) . '" alt="' . esc_attr__("logo", "posolo") . '">';
                                            } else {
                                                echo '<h1 class="title45 fontwo font-300">' . get_bloginfo('name', 'display') . '</h1>';
                                            }
                                            ?>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="col-menu col-md-10 col-sm-6 col-xs-6">
                        <?php if (has_nav_menu('primary')) { ?>
                            <div class="text-center">
                                <nav class="main-nav">
                                    <?php wp_nav_menu(
                                        array(
                                            'theme_location'    => 'primary',
                                            'container'         => false,
                                            'menu_class'      => 'list-none',
                                            'walker'            => new Tech888f_Walker_Nav_Menu(),
                                        )
                                    ); ?>
                                    <a href="#" class="toggle-mobile-menu"><span></span></a>
                                </nav>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php
}
?>