<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 18/11/2016
 * Time: 9:18 SA
 */
if ( !class_exists('WC_Product') ) {
    return;
}

if(!class_exists('Tech888f_Widget_Price_Filter')) {
    class Tech888f_Widget_Price_Filter extends WC_Widget
    {
        static function _init()
        {
            add_action('widgets_init', array(__CLASS__, '_add_widget'));
        }

        static function _add_widget()
        {
            tech888f_reg_widget('Tech888f_Widget_Price_Filter');
        }

        /**
         * Constructor.
         */
        public function __construct()
        {
            $this->widget_cssclass = 'woocommerce widget widget-filter tech888f-widget-price-filter';
            $this->widget_description = esc_html__('Display a slider to filter products in your store by price.', 'posolo');
            $this->widget_id = 'tech888f_price_filter';
            $this->widget_name = esc_html__('T888 Filter by Price', 'posolo');

            parent::__construct();
        }

        /**
         * Updates a particular instance of a widget.
         *
         * @see WP_Widget->update
         *
         * @param array $new_instance
         * @param array $old_instance
         *
         * @return array
         */
        public function update($new_instance, $old_instance)
        {
            $this->init_settings();

            return parent::update($new_instance, $old_instance);
        }

        public function form($instance)
        {
            $this->init_settings();

            parent::form($instance);
        }

        /**
         * Init settings after post types are registered.
         */
        public function init_settings()
        {

            $this->settings =array(
                'title' => array(
                    'type' => 'text',
                    'std' => esc_html__('Filter by', 'posolo'),
                    'label' => esc_html__('Title', 'posolo')
                ),
            );
        }

        /**
         * Output widget.
         *
         * @see WP_Widget
         *
         * @param array $args
         * @param array $instance
         */
        public function widget($args, $instance)
        { global $post;
            if( empty($post)){
                return;
            }
            if (  ! is_shop() && ! is_product_taxonomy() &&  !strpos($post->post_content, '[tech888f_shop')) {
                return;
            }
            echo wp_kses_post($args['before_widget']);
            extract($instance); ?>
            <div class="widget-content-filter-product woocommerce">
                <?php
                global $wp;
                if ( '' === get_option( 'permalink_structure' ) ) {
                    $form_action = remove_query_arg( array( 'page', 'paged' ), add_query_arg( $wp->query_string, '', home_url( $wp->request ) ) );
                } else {
                    $form_action = preg_replace( '%\/page/[0-9]+%', '', home_url( trailingslashit( $wp->request ) ) );
                }
                ?>

                <div class="widget-filter-price">
                    <?php
                    if ( ! empty( $instance['title'] ) ) {
                        echo wp_kses_post($args['before_title']) . apply_filters( 'widget_title', $instance['title'] ). $args['after_title'];
                    }
                    $min_max = tech888f_get_price_arange();
                    if(!empty($_GET['min_price'])) $min = $_GET['min_price']; else $min = $min_max['min'];
                    if(!empty($_GET['max_price'])) $max = $_GET['max_price']; else $max = $min_max['max']; ?>
                    <form method="get" action="<?php echo esc_url($form_action)?>">
                        <div class="range-filter">
                            <div class="slider-range" data-min="<?php echo esc_attr($min)?>" data-max="<?php echo esc_attr($max)?>" data-pricemin="<?php echo esc_attr($min_max['min'])?>" data-pricemax="<?php echo esc_attr($min_max['max'])?>" data-currencysymbol="<?php echo esc_attr(get_woocommerce_currency_symbol()); ?>"></div>
                            <div class="attr-price-filter">
                                <div class="price-amount-wrap black30">
                                <label><?php esc_html_e("Price:", "posolo"); ?></label>
                                <span class="amount">
                                            <?php echo get_woocommerce_currency_symbol() ?> <span class="element-get-min"><?php echo esc_html($min); ?></span>
                                    <?php echo esc_html("-") ?>
                                    <?php echo get_woocommerce_currency_symbol() ?> <span class="element-get-max"><?php echo esc_html($max); ?></span></span>
                                </div>
                                <div class="btn-filter-wrap">
                                <button type="button" class="button shop-button white bg-color font-bold pst-relative"><?php echo  esc_html__( 'Filter', 'posolo' )  ?></button>
                                </div>
                            </div>
                            <div class="input-filter">
                                <input type="text" class="hide" id="min_price" name="min_price" value="<?php echo esc_attr($min)?>" />
                                <input type="text" class="hide" id="max_price" name="max_price" value="<?php echo esc_attr($max)?>" />
                            </div>

                            <div>
                                <?php echo wc_query_string_form_fields( null, array( 'min_price', 'max_price' ), '', true ); ?>
                            </div>
                        </div>
                    </form>
                </div>

            </div>

            <?php
            echo wp_kses_post($args['after_widget']);
        }


    }
    Tech888f_Widget_Price_Filter::_init();
}