<?php
/**
 * Created by Sublime Text 2.
 * User: thanhhiep992
 * Date: 12/08/15
 * Time: 10:20 AM
 */
if(!class_exists('tech888f_CustomProductController'))
{
    class tech888f_CustomProductController{

        static function _init()
        {
            if(function_exists('stp_reg_post_type'))
            {
                //add_action('init', 'icl_theme_register_custom', 0);
                add_action('init',array(__CLASS__,'_add_post_type'));
            }
        }

        static function _add_post_type()
        {
            $labels = array(
                'name'               => esc_html__('Sản phẩm','posolo'),
                'singular_name'      => esc_html__('Sản phẩm','posolo'),
                'menu_name'          => esc_html__('Sản phẩm','posolo'),
                'name_admin_bar'     => esc_html__('Sản phẩm','posolo'),
                'add_new'            => esc_html__('Add New','posolo'),
                'add_new_item'       => esc_html__( 'Add New Sản phẩm','posolo' ),
                'new_item'           => esc_html__( 'New Sản phẩm', 'posolo' ),
                'edit_item'          => esc_html__( 'Edit Sản phẩm', 'posolo' ),
                'view_item'          => esc_html__( 'View Sản phẩm', 'posolo' ),
                'all_items'          => esc_html__( 'All Sản phẩm', 'posolo' ),
                'search_items'       => esc_html__( 'Search Sản phẩm', 'posolo' ),
                'parent_item_colon'  => esc_html__( 'Parent Sản phẩm:', 'posolo' ),
                'not_found'          => esc_html__( 'No Sản phẩm found.', 'posolo' ),
                'not_found_in_trash' => esc_html__( 'No Sản phẩm found in Trash.', 'posolo' )
            );

            $args = array(
                'labels'             => $labels,
                'public'             => true,
                'publicly_queryable' => true,
                'show_ui'            => true,
                'show_in_menu'       => true,
                'query_var'          => true,
                'rewrite'            => array( 'slug' => 'san-pham' ),
                'capability_type'    => 'post',
                'has_archive'        => true,
                'hierarchical'       => false,
                'menu_position'      => null,
                'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt' )
            );

            stp_reg_post_type('custom_product',$args);
            //self::tech888f_add_custom_taxonomy();
      //      self::tech888f_add_custom_meta_box();
        }



        // static function tech888f_add_custom_meta_box (){
        //     $my_meta_box = array(
        //         'id'        => 'Custom_Product_option',
        //         'title'     => esc_html__(  'Sản phẩm Option' , 'posolo' ),
        //         'desc'      => '',
        //         'pages'     => array( 'custom_product' ),
        //         'context'   => 'normal',
        //         'priority'  => 'high',
        //         'fields'    => array(                    
        //             array(
        //                 'id'                => 'icon',
        //                 'label'             => esc_html__('Choose icon', 'posolo'),
        //                 'desc'              => esc_html__('Choose font awesome icon','posolo'),
        //                 'type'              => 'text',
        //                 'class'             => 'sv_iconpicker'
        //             ),
        //             array(
        //                 'id'                => 'featured_special',
        //                 'label'             => esc_html__('Special Featured Image', 'posolo'),
        //                 'desc'              => esc_html__('Upload Image','posolo'),
        //                 'type'              => 'upload'
        //             )
        //         )
        //     );

        //     if ( function_exists( 'ot_register_meta_box' ) )
        //         ot_register_meta_box($my_meta_box );
        // }
    }

    tech888f_CustomProductController::_init();

}

function project_service_register_taxonomy() {

    $args = array (
        'label' => esc_html__( 'Danh mục', 'posolo' ),
        'labels' => array(
            'menu_name' => esc_html__( 'Danh mục', 'posolo' ),
            'all_items' => esc_html__( 'All Danh mục', 'posolo' ),
            'edit_item' => esc_html__( 'Edit Danh mục', 'posolo' ),
            'view_item' => esc_html__( 'View Danh mục', 'posolo' ),
            'update_item' => esc_html__( 'Update Danh mục', 'posolo' ),
            'add_new_item' => esc_html__( 'Add new Danh mục', 'posolo' ),
            'new_item_name' => esc_html__( 'New Danh mục', 'posolo' ),
            'parent_item' => esc_html__( 'Parent Danh mục', 'posolo' ),
            'parent_item_colon' => esc_html__( 'Parent Danh mục:', 'posolo' ),
            'search_items' => esc_html__( 'Search Danh mục', 'posolo' ),
            'popular_items' => esc_html__( 'Popular Danh mục', 'posolo' ),
            'separate_items_with_commas' => esc_html__( 'Separate Danh mục with commas', 'posolo' ),
            'add_or_remove_items' => esc_html__( 'Add or remove Danh mục', 'posolo' ),
            'choose_from_most_used' => esc_html__( 'Choose most used Danh mục', 'posolo' ),
            'not_found' => esc_html__( 'No Danh mục found', 'posolo' ),
            'name' => esc_html__( 'Danh mục', 'posolo' ),
            'singular_name' => esc_html__( 'danh-muc-san-pham', 'posolo' ),
        ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_nav_menus' => true,
        'show_tagcloud' => true,
        'show_in_quick_edit' => true,
        'show_admin_column' => true,
        'show_in_rest' => false,
        'hierarchical' => true,
        'query_var' => true,
        'sort' => false,
        'rewrite_no_front' => false,
        'rewrite_hierarchical' => false,
        'rewrite' => true,
    );
    if(function_exists('stp_reg_taxonomy')){
        stp_reg_taxonomy( 'danh-muc-san-pham', array( 'custom_product' ), $args );
    }

}
add_action( 'init', 'project_service_register_taxonomy', 0 );


// function project_region_register_taxonomy() {

//     $args = array (
//         'label' => esc_html__( 'Project region', 'posolo' ),
//         'labels' => array(
//             'menu_name' => esc_html__( 'Project region', 'posolo' ),
//             'all_items' => esc_html__( 'All Project region', 'posolo' ),
//             'edit_item' => esc_html__( 'Edit project-region', 'posolo' ),
//             'view_item' => esc_html__( 'View project-region', 'posolo' ),
//             'update_item' => esc_html__( 'Update project-region', 'posolo' ),
//             'add_new_item' => esc_html__( 'Add new project-region', 'posolo' ),
//             'new_item_name' => esc_html__( 'New project-region', 'posolo' ),
//             'parent_item' => esc_html__( 'Parent project-region', 'posolo' ),
//             'parent_item_colon' => esc_html__( 'Parent project-region:', 'posolo' ),
//             'search_items' => esc_html__( 'Search Project region', 'posolo' ),
//             'popular_items' => esc_html__( 'Popular Project region', 'posolo' ),
//             'separate_items_with_commas' => esc_html__( 'Separate Project region with commas', 'posolo' ),
//             'add_or_remove_items' => esc_html__( 'Add or remove Project region', 'posolo' ),
//             'choose_from_most_used' => esc_html__( 'Choose most used Project region', 'posolo' ),
//             'not_found' => esc_html__( 'No Project region found', 'posolo' ),
//             'name' => esc_html__( 'Project region', 'posolo' ),
//             'singular_name' => esc_html__( 'project-region', 'posolo' ),
//         ),
//         'public' => true,
//         'show_ui' => true,
//         'show_in_menu' => true,
//         'show_in_nav_menus' => true,
//         'show_tagcloud' => true,
//         'show_in_quick_edit' => true,
//         'show_admin_column' => false,
//         'show_in_rest' => false,
//         'hierarchical' => true,
//         'query_var' => true,
//         'sort' => false,
//         'rewrite_no_front' => false,
//         'rewrite_hierarchical' => false,
//         'rewrite' => true,
//     );
//     if(function_exists('stp_reg_taxonomy')){
//         stp_reg_taxonomy( 'project-region', array( 'project' ), $args );
//     }
// }
// add_action( 'init', 'project_region_register_taxonomy', 0 );

// function project_type_register_taxonomy() {

//     $args = array (
//         'label' => esc_html__( 'Project Type', 'posolo' ),
//         'labels' => array(
//             'menu_name' => esc_html__( 'Project type', 'posolo' ),
//             'all_items' => esc_html__( 'All Project type', 'posolo' ),
//             'edit_item' => esc_html__( 'Edit project-type', 'posolo' ),
//             'view_item' => esc_html__( 'View project-type', 'posolo' ),
//             'update_item' => esc_html__( 'Update project-type', 'posolo' ),
//             'add_new_item' => esc_html__( 'Add new project-type', 'posolo' ),
//             'new_item_name' => esc_html__( 'New project-type', 'posolo' ),
//             'parent_item' => esc_html__( 'Parent project-type', 'posolo' ),
//             'parent_item_colon' => esc_html__( 'Parent project-type:', 'posolo' ),
//             'search_items' => esc_html__( 'Search Project type', 'posolo' ),
//             'popular_items' => esc_html__( 'Popular Project type', 'posolo' ),
//             'separate_items_with_commas' => esc_html__( 'Separate Project type with commas', 'posolo' ),
//             'add_or_remove_items' => esc_html__( 'Add or remove Project type', 'posolo' ),
//             'choose_from_most_used' => esc_html__( 'Choose most used Project type', 'posolo' ),
//             'not_found' => esc_html__( 'No Project type found', 'posolo' ),
//             'name' => esc_html__( 'Project type', 'posolo' ),
//             'singular_name' => esc_html__( 'project-type', 'posolo' ),
//         ),
//         'public' => true,
//         'show_ui' => true,
//         'show_in_menu' => true,
//         'show_in_nav_menus' => true,
//         'show_tagcloud' => true,
//         'show_in_quick_edit' => true,
//         'show_admin_column' => false,
//         'show_in_rest' => false,
//         'hierarchical' => true,
//         'query_var' => true,
//         'sort' => false,
//         'rewrite_no_front' => false,
//         'rewrite_hierarchical' => false,
//         'rewrite' => true,
//     );
//     if (function_exists('stp_reg_taxonomy')){
//         stp_reg_taxonomy( 'project-type', array( 'project' ), $args );
//     }
// }
//add_action( 'init', 'project_type_register_taxonomy', 0 );