<?php
/**
 * Created by Sublime Text 2.
 * User: thanhhiep992
 * Date: 12/08/15
 * Time: 10:20 AM
 */

if(class_exists('Redux')){
    $tech888f_option_name = tech888f_get_option_name();
    add_filter("redux/metaboxes/".$tech888f_option_name."/boxes", "tech888f_custom_meta_boxes");
}
else add_action('admin_init', 'tech888f_custom_meta_boxes');
if(!function_exists('tech888f_register_metabox')){
    function tech888f_register_metabox($settings){
        foreach ($settings as $key => $setting) {
            if(is_array($setting['fields'])){
                $new_options = [];
                foreach ($setting['fields'] as $keyf => $field) {                    
                    $stemp = tech888f_fix_type_redux($field);
                    if($field['type'] == 'tab'){
                        $tab_id = $field['id'];
                        $new_options[$tab_id] = array_merge($new_options,$stemp);
                        if(!isset($new_options[$tab_id]['icon'])) $new_options[$tab_id]['icon'] = '';
                    }
                    else{
                        if(!isset($tab_id)) $tab_id = 0;
                        $new_options[$tab_id]['fields'][] = $stemp;
                    }
                }
            }
            if(isset($new_options['title'])) $new_options['icon'] = '';
            unset($new_options['type']);
            $new_options2 = array();
            foreach ($new_options as $key2 => $value) {
                $new_options2[] = $new_options[$key2];
            }
            $settings[$key]['post_types'] = $settings[$key]['pages'];
            $settings[$key]['position'] = $settings[$key]['context'];
            $settings[$key]['sections'] = $new_options2;
            unset($settings[$key]['fields']);
            unset($settings[$key]['pages']);
            unset($settings[$key]['context']);
        }
        return $settings;
    }
}
if(!function_exists('tech888f_custom_meta_boxes')){
    function tech888f_custom_meta_boxes(){
        //Format content
        $format_metabox = array(
            'id'        => 'block_format_content',
            'title'     => esc_html__('Format Settings', 'posolo'),
            'desc'      => '',
            'pages'     => array('post'),
            'context'   => 'normal',
            'priority'  => 'high',
            'fields'    => array(                
                array(
                    'id'        => 'format_image',
                    'label'     => esc_html__('Upload Image', 'posolo'),
                    'type'      => 'upload',
                    'desc'      => esc_html__('Choose image from media.','posolo'),
                ),
                array(
                    'id'        => 'format_gallery',
                    'label'     => esc_html__('Add Gallery', 'posolo'),
                    'type'      => 'Gallery',
                    'desc'      => esc_html__('Choose images from media.','posolo'),
                ),
                array(
                    'id'        => 'format_media',
                    'label'     => esc_html__('Link Media', 'posolo'),
                    'type'      => 'text',
                    'desc'      => esc_html__('Enter media url(Youtube, Vimeo, SoundCloud ...).','posolo'),
                )
            ),
        );
        // SideBar
        $page_settings = array(
            'id'        => 'tech888f_sidebar_option',
            'title'     => esc_html__('Page Settings','posolo'),
            'pages'     => array( 'page','post','product'),
            'context'   => 'normal',
            'priority'  => 'low',
            'fields'    => array(
                // General tab
                array(
                    'id'        => 'page_general',
                    'type'      => 'tab',
                    'label'     => esc_html__('General Settings','posolo')
                ),
                array(
                    'id'        => 'tech888f_header_page',
                    'label'     => esc_html__('Choose page header','posolo'),
                    'type'      => 'select',
                    'choices'   => tech888f_list_post_type('tech888f_header'),
                    'desc'      => esc_html__('Include Header content. Go to Header page in admin menu to edit/create header content. Default is value of Theme Option.','posolo'),
                ),
                array(
                    'id'         => 'tech888f_footer_page',
                    'label'      => esc_html__('Choose page footer','posolo'),
                    'type'       => 'select',
                    'choices'    => tech888f_list_post_type('tech888f_footer'),
                    'desc'       => esc_html__('Include Footer content. Go to Footer page in admin menu to edit/create footer content. Default is value of Theme Option.','posolo'),
                ),
                array(
                    'id'         => 'tech888f_sidebar_position',
                    'label'      => esc_html__('Sidebar position ','posolo'),
                    'type'       => 'select',
                    'choices'    => array(
                        array(
                            'label' => esc_html__('--Select--','posolo'),
                            'value' => '',
                        ),
                        array(
                            'label' => esc_html__('No Sidebar','posolo'),
                            'value' => 'no'
                        ),
                        array(
                            'label' => esc_html__('Left sidebar','posolo'),
                            'value' => 'left'
                        ),
                        array(
                            'label' => esc_html__('Right sidebar','posolo'),
                            'value' => 'right'
                        ),
                    ),
                    'desc'      => esc_html__('Choose sidebar position for current page/post(Left,Right or No Sidebar).','posolo'),
                ),
                array(
                    'id'        => 'tech888f_select_sidebar',
                    'label'     => esc_html__('Selects sidebar','posolo'),
                    'type'      => 'sidebar-select',
                    'condition' => 'tech888f_sidebar_position:not(no),tech888f_sidebar_position:not()',
                    'desc'      => esc_html__('Choose a sidebar to display.','posolo'),
                ),
                array(
                    'id'          => 'before_append',
                    'label'       => esc_html__('Append content before','posolo'),
                    'type'        => 'select',
                    'choices'     => tech888f_list_post_type('tech888f_mega_item'),
                    'desc'        => esc_html__('Choose a mega page content append to before main content of page/post.','posolo'),
                ),
                array(
                    'id'          => 'after_append',
                    'label'       => esc_html__('Append content after','posolo'),
                    'type'        => 'select',
                    'choices'     => tech888f_list_post_type('tech888f_mega_item'),
                    'desc'        => esc_html__('Choose a mega page content append to after main content of page/post.','posolo'),
                ),
                array(
                    'id'          => 'show_title_page',
                    'label'       => esc_html__('Show title', 'posolo'),
                    'type'        => 'on-off',
                    'std'         => 'on',
                    'desc'        => esc_html__('Show/hide title of page.','posolo'),
                ),
                array(
                    'id' => 'post_single_page_share',
                    'label' => esc_html__('Show Share Box', 'posolo'),
                    'type' => 'select',
                    'std'   => '',
                    'choices'     => array(
                        array(
                            'label'=>esc_html__('--Theme Option--','posolo'),
                            'value'=>'',
                        ),
                        array(
                            'label'=>esc_html__('On','posolo'),
                            'value'=>'1'
                        ),
                        array(
                            'label'=>esc_html__('Off','posolo'),
                            'value'=>'0'
                        ),
                    ),
                    'desc'        => esc_html__( 'You can show/hide share box independent on this page. ', 'posolo' ),
                ),
                // End general tab
                // Custom color
                array(
                    'id'        => 'page_color',
                    'type'      => 'tab',
                    'label'     => esc_html__('Custom color','posolo')
                ),
                array(
                    'id'          => 'body_bg',
                    'label'       => esc_html__('Body Background','posolo'),
                    'type'        => 'colorpicker-opacity',
                    'desc'        => esc_html__( 'Change body background of page.', 'posolo' ),
                ),
                array(
                    'id'          => 'main_color',
                    'label'       => esc_html__('Main color','posolo'),
                    'type'        => 'colorpicker-opacity',
                    'desc'        => esc_html__( 'Change main color of this page.', 'posolo' ),
                ),
                array(
                    'id'          => 'main_color2',
                    'label'       => esc_html__('Main color 2','posolo'),
                    'type'        => 'colorpicker-opacity',
                    'desc'        => esc_html__( 'Change main color 2 of this page.', 'posolo' ),
                ),
                // End Custom color
                // Display & Style tab
                array(
                    'id'        => 'page_layout',
                    'type'      => 'tab',
                    'label'     => esc_html__('Display & Style','posolo')
                ),
                array(
                    'id'          => 'tech888f_page_style',
                    'label'       => esc_html__('Page Style','posolo'),
                    'type'        => 'select',
                    'std'         => '',
                    'choices'     => array(
                        array(
                            'label' =>  esc_html__('Default','posolo'),
                            'value' =>  'page-content-df',
                        ),
                        array(
                            'label' =>  esc_html__('Page boxed','posolo'),
                            'value' =>  'page-content-box'
                        ),
                    ),
                    'desc'        => esc_html__( 'Choose default style for page.', 'posolo' ),
                ),
                array(
                    'id'          => 'container_width',
                    'label'       => esc_html__('Custom container width(px)','posolo'),
                    'type'        => 'text',
                    'desc'        => esc_html__( 'You can custom width of page container. Default is 1200px.', 'posolo' ),
                ),                
                
                // End Display & Style tab               
            )
        );
        
        $product_settings = array(
            'id' => 'block_product_settings',
            'title' => esc_html__('Product Settings', 'posolo'),
            'desc' => '',
            'pages' => array('product'),
            'context' => 'normal',
            'priority' => 'low',
            'fields' => array(    
                // Begin Product Settings
                array(
                    'id'        => 'block_product_custom_tab',
                    'type'      => 'tab',
                    'label'     => esc_html__('General Settings','posolo')
                ),             
                array(
                    'id'          => 'before_append_tab',
                    'label'       => esc_html__('Append content before product tab','posolo'),
                    'type'        => 'select',
                    'choices'     => tech888f_list_post_type('tech888f_mega_item'),
                    'desc'        => esc_html__('Choose a mega page content append to before product tab.','posolo'),
                ),
                array(
                    'id'          => 'after_append_tab',
                    'label'       => esc_html__('Append content after product tab','posolo'),
                    'type'        => 'select',
                    'choices'     => tech888f_list_post_type('tech888f_mega_item'),
                    'desc'        => esc_html__('Choose a mega page content append to before product tab.','posolo'),
                ),
                array(
                    'id'          => 'product_tab_detail',
                    'label'       => esc_html__('Product Tab Style','posolo'),
                    'type'        => 'select',
                    'choices'     => array(                                                    
                        array(
                            'value'=> 'tab-normal',
                            'label'=> esc_html__("Normal", 'posolo'),
                        ),
                        array(
                            'value'=> 'tab-style2',
                            'label'=> esc_html__("Tab style 2", 'posolo'),
                        ),
                    )
                ),
                array(
                    'id'          => 'tech888f_product_tab_data',
                    'label'       => esc_html__('Add Custom Tab','posolo'),
                    'type'        => 'list-item',
                    'settings'    => array(
                        array(
                            'id' => 'tab_content',
                            'label' => esc_html__('Content', 'posolo'),
                            'type' => 'textarea',
                        ),
                        array(
                            'id'            => 'priority',
                            'label'         => esc_html__('Priority (Default 40)', 'posolo'),
                            'type'          => 'numeric-slider',
                            'min_max_step'  => '1,50,1',
                            'std'           => '40',
                            'desc'          => esc_html__('Choose priority value to re-order custom tab position.','posolo'),
                        ),
                    )
                ),
            ),
        );
        $product_type = array(
            'id' => 'product_trendding',
            'title' => esc_html__('Product Type', 'posolo'),
            'desc' => '',
            'pages' => array('product'),
            'context' => 'side',
            'priority' => 'low',
            'fields' => array(                
                array(
                    'id'    => 'trending_product',
                    'label' => esc_html__('Product Trending', 'posolo'),
                    'type'        => 'on-off',
                    'std'         => 'off',
                    'desc'        => esc_html__( 'Set trending for current product.', 'posolo' ),
                ),
                array(
                    'id'    => 'product_thumb_hover',
                    'label' => esc_html__('Product hover image', 'posolo'),
                    'type'  => 'upload',
                    'desc'        => esc_html__( 'Product thumbnail 2. Some hover animation of thumbnail show back image. Default return main product thumbnail.', 'posolo' ),
                ),
            ),
        );        
        if(class_exists('Redux')){      
            $metaboxes = tech888f_register_metabox([$product_type]);
            return $metaboxes;
        }
        else{
            if (function_exists('ot_register_meta_box')){
                //ot_register_meta_box($format_metabox);
                //ot_register_meta_box($page_settings);
                //ot_register_meta_box($product_settings);
                //ot_register_meta_box($product_type);
            }
        }
    }
}
// var_dump(tech888f_custom_meta_boxes());
?>