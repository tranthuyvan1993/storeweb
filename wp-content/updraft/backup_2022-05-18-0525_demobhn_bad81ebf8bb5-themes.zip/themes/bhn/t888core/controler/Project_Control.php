<?php
/**
 * Created by Sublime Text 2.
 * User: thanhhiep992
 * Date: 12/08/15
 * Time: 10:20 AM
 */
if(!class_exists('tech888f_ProjectController'))
{
    class tech888f_ProjectController{

        static function _init()
        {
            if(function_exists('stp_reg_post_type'))
            {
                //add_action('init', 'icl_theme_register_custom', 0);
                add_action('init',array(__CLASS__,'_add_post_type'));
            }
        }

        static function _add_post_type()
        {
            $labels = array(
                'name'               => esc_html__('Project','posolo'),
                'singular_name'      => esc_html__('Project','posolo'),
                'menu_name'          => esc_html__('Project','posolo'),
                'name_admin_bar'     => esc_html__('Project','posolo'),
                'add_new'            => esc_html__('Add New','posolo'),
                'add_new_item'       => esc_html__( 'Add New Project','posolo' ),
                'new_item'           => esc_html__( 'New Project', 'posolo' ),
                'edit_item'          => esc_html__( 'Edit Project', 'posolo' ),
                'view_item'          => esc_html__( 'View Project', 'posolo' ),
                'all_items'          => esc_html__( 'All Project', 'posolo' ),
                'search_items'       => esc_html__( 'Search Project', 'posolo' ),
                'parent_item_colon'  => esc_html__( 'Parent Project:', 'posolo' ),
                'not_found'          => esc_html__( 'No Project found.', 'posolo' ),
                'not_found_in_trash' => esc_html__( 'No Project found in Trash.', 'posolo' )
            );

            $args = array(
                'labels'             => $labels,
                'public'             => true,
                'publicly_queryable' => true,
                'show_ui'            => true,
                'show_in_menu'       => true,
                'query_var'          => true,
                'rewrite'            => array( 'slug' => 'project' ),
                'capability_type'    => 'post',
                'has_archive'        => true,
                'hierarchical'       => false,
                'menu_position'      => null,
                'supports'           => array( 'title', 'editor', 'author', 'thumbnail', 'excerpt' )
            );

            stp_reg_post_type('project',$args);
            //self::tech888f_add_custom_taxonomy();
            self::tech888f_add_custom_meta_box();
        }



        static function tech888f_add_custom_meta_box (){
            $my_meta_box = array(
                'id'        => 'Project_option',
                'title'     => esc_html__(  'Project Option' , 'posolo' ),
                'desc'      => '',
                'pages'     => array( 'Project' ),
                'context'   => 'normal',
                'priority'  => 'high',
                'fields'    => array(                    
                    array(
                        'id'                => 'icon',
                        'label'             => esc_html__('Choose icon', 'posolo'),
                        'desc'              => esc_html__('Choose font awesome icon','posolo'),
                        'type'              => 'text',
                        'class'             => 'sv_iconpicker'
                    ),
                    array(
                        'id'                => 'featured_special',
                        'label'             => esc_html__('Special Featured Image', 'posolo'),
                        'desc'              => esc_html__('Upload Image','posolo'),
                        'type'              => 'upload'
                    )
                )
            );

            if ( function_exists( 'ot_register_meta_box' ) )
                ot_register_meta_box($my_meta_box );
        }
    }

    tech888f_ProjectController::_init();

}

function project_service_register_taxonomy() {

    $args = array (
        'label' => esc_html__( 'Project Service', 'posolo' ),
        'labels' => array(
            'menu_name' => esc_html__( 'Project Service', 'posolo' ),
            'all_items' => esc_html__( 'All Project Service', 'posolo' ),
            'edit_item' => esc_html__( 'Edit project-service', 'posolo' ),
            'view_item' => esc_html__( 'View project-service', 'posolo' ),
            'update_item' => esc_html__( 'Update project-service', 'posolo' ),
            'add_new_item' => esc_html__( 'Add new project-service', 'posolo' ),
            'new_item_name' => esc_html__( 'New project-service', 'posolo' ),
            'parent_item' => esc_html__( 'Parent project-service', 'posolo' ),
            'parent_item_colon' => esc_html__( 'Parent project-service:', 'posolo' ),
            'search_items' => esc_html__( 'Search Project Service', 'posolo' ),
            'popular_items' => esc_html__( 'Popular Project Service', 'posolo' ),
            'separate_items_with_commas' => esc_html__( 'Separate Project Service with commas', 'posolo' ),
            'add_or_remove_items' => esc_html__( 'Add or remove Project Service', 'posolo' ),
            'choose_from_most_used' => esc_html__( 'Choose most used Project Service', 'posolo' ),
            'not_found' => esc_html__( 'No Project Service found', 'posolo' ),
            'name' => esc_html__( 'Project Service', 'posolo' ),
            'singular_name' => esc_html__( 'project-service', 'posolo' ),
        ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_nav_menus' => true,
        'show_tagcloud' => true,
        'show_in_quick_edit' => true,
        'show_admin_column' => false,
        'show_in_rest' => false,
        'hierarchical' => true,
        'query_var' => true,
        'sort' => false,
        'rewrite_no_front' => false,
        'rewrite_hierarchical' => false,
        'rewrite' => true,
    );
    if(function_exists('stp_reg_taxonomy')){
        stp_reg_taxonomy( 'project-service', array( 'project' ), $args );
    }

}
add_action( 'init', 'project_service_register_taxonomy', 0 );


function project_region_register_taxonomy() {

    $args = array (
        'label' => esc_html__( 'Project region', 'posolo' ),
        'labels' => array(
            'menu_name' => esc_html__( 'Project region', 'posolo' ),
            'all_items' => esc_html__( 'All Project region', 'posolo' ),
            'edit_item' => esc_html__( 'Edit project-region', 'posolo' ),
            'view_item' => esc_html__( 'View project-region', 'posolo' ),
            'update_item' => esc_html__( 'Update project-region', 'posolo' ),
            'add_new_item' => esc_html__( 'Add new project-region', 'posolo' ),
            'new_item_name' => esc_html__( 'New project-region', 'posolo' ),
            'parent_item' => esc_html__( 'Parent project-region', 'posolo' ),
            'parent_item_colon' => esc_html__( 'Parent project-region:', 'posolo' ),
            'search_items' => esc_html__( 'Search Project region', 'posolo' ),
            'popular_items' => esc_html__( 'Popular Project region', 'posolo' ),
            'separate_items_with_commas' => esc_html__( 'Separate Project region with commas', 'posolo' ),
            'add_or_remove_items' => esc_html__( 'Add or remove Project region', 'posolo' ),
            'choose_from_most_used' => esc_html__( 'Choose most used Project region', 'posolo' ),
            'not_found' => esc_html__( 'No Project region found', 'posolo' ),
            'name' => esc_html__( 'Project region', 'posolo' ),
            'singular_name' => esc_html__( 'project-region', 'posolo' ),
        ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_nav_menus' => true,
        'show_tagcloud' => true,
        'show_in_quick_edit' => true,
        'show_admin_column' => false,
        'show_in_rest' => false,
        'hierarchical' => true,
        'query_var' => true,
        'sort' => false,
        'rewrite_no_front' => false,
        'rewrite_hierarchical' => false,
        'rewrite' => true,
    );
    if(function_exists('stp_reg_taxonomy')){
        stp_reg_taxonomy( 'project-region', array( 'project' ), $args );
    }
}
add_action( 'init', 'project_region_register_taxonomy', 0 );

function project_type_register_taxonomy() {

    $args = array (
        'label' => esc_html__( 'Project Type', 'posolo' ),
        'labels' => array(
            'menu_name' => esc_html__( 'Project type', 'posolo' ),
            'all_items' => esc_html__( 'All Project type', 'posolo' ),
            'edit_item' => esc_html__( 'Edit project-type', 'posolo' ),
            'view_item' => esc_html__( 'View project-type', 'posolo' ),
            'update_item' => esc_html__( 'Update project-type', 'posolo' ),
            'add_new_item' => esc_html__( 'Add new project-type', 'posolo' ),
            'new_item_name' => esc_html__( 'New project-type', 'posolo' ),
            'parent_item' => esc_html__( 'Parent project-type', 'posolo' ),
            'parent_item_colon' => esc_html__( 'Parent project-type:', 'posolo' ),
            'search_items' => esc_html__( 'Search Project type', 'posolo' ),
            'popular_items' => esc_html__( 'Popular Project type', 'posolo' ),
            'separate_items_with_commas' => esc_html__( 'Separate Project type with commas', 'posolo' ),
            'add_or_remove_items' => esc_html__( 'Add or remove Project type', 'posolo' ),
            'choose_from_most_used' => esc_html__( 'Choose most used Project type', 'posolo' ),
            'not_found' => esc_html__( 'No Project type found', 'posolo' ),
            'name' => esc_html__( 'Project type', 'posolo' ),
            'singular_name' => esc_html__( 'project-type', 'posolo' ),
        ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'show_in_nav_menus' => true,
        'show_tagcloud' => true,
        'show_in_quick_edit' => true,
        'show_admin_column' => false,
        'show_in_rest' => false,
        'hierarchical' => true,
        'query_var' => true,
        'sort' => false,
        'rewrite_no_front' => false,
        'rewrite_hierarchical' => false,
        'rewrite' => true,
    );
    if (function_exists('stp_reg_taxonomy')){
        stp_reg_taxonomy( 'project-type', array( 'project' ), $args );
    }
}
add_action( 'init', 'project_type_register_taxonomy', 0 );