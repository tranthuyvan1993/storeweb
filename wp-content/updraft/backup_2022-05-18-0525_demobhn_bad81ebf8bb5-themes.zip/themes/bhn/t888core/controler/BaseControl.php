<?php
/**
 * Created by Sublime Text 2.
 * User: thanhhiep992
 * Date: 12/08/15
 * Time: 10:20 AM
 */
if(!defined('ABSPATH')) return;

if(!class_exists('tech888f_BaseController')){
    class tech888f_BaseController{
        static function _init(){
            //Default Framwork Hooked
            add_filter( 'wp_title', array(__CLASS__,'_wp_title'), 10, 2 );
            add_action( 'wp', array(__CLASS__,'_setup_author') );
            add_action( 'after_setup_theme', array(__CLASS__,'_after_setup_theme') );
            add_action( 'widgets_init',array(__CLASS__,'_add_sidebars'));
            add_action( 'wp_enqueue_scripts',array(__CLASS__,'_add_scripts'));

            //Custom hooked
            add_filter( 'tech888f_get_sidebar',array(__CLASS__,'_blog_filter_sidebar'));
            add_filter( 'tech888f_header_page_id',array(__CLASS__,'_header_id'));
            add_filter( 'tech888f_footer_page_id',array(__CLASS__,'_footer_id'));
            add_action( 'admin_enqueue_scripts',array(__CLASS__,'_add_admin_scripts'));

            if(class_exists("woocommerce") && !is_admin()){
                add_action('woocommerce_product_query', array(__CLASS__, '_woocommerce_product_query'), 20);
            }
            add_action('after_switch_theme', array(__CLASS__,'tech888f_setup_options'));
            add_filter('body_class', array(__CLASS__,'tech888f_body_classes'));

            // tech888 hook
            add_action( 'pre_get_posts', array(__CLASS__,'tech888f_custom_posts_per_page'));
            add_action( 'tech888f_before_main_content', array(__CLASS__,'tech888f_display_breadcrumb'),20);
            // Before/After append settings
            $terms = array('product_cat','product_tag','category','post_tag');
            foreach ($terms as $term_name) {
                add_action($term_name.'_add_form_fields', array(__CLASS__,'tech888f_product_cat_metabox_add'), 10, 1);
                add_action($term_name.'_edit_form_fields', array(__CLASS__,'tech888f_product_cat_metabox_edit'), 10, 1);
                add_action('created_'.$term_name, array(__CLASS__,'tech888f_product_save_category_metadata'), 10, 1);
                add_action('edited_'.$term_name, array(__CLASS__,'tech888f_product_save_category_metadata'), 10, 1);
            }
            // Before/After append display
            add_action('tech888f_before_main_content', array(__CLASS__,'tech888f_append_content_before'), 10);
            add_action('tech888f_after_main_content', array(__CLASS__,'tech888f_append_content_after'), 10);
            add_action('user_register',array(__CLASS__,'tech888f_set_pass'));

            /*gutenberg optimized hook */
            add_action( 'enqueue_block_editor_assets', array(__CLASS__,'tech888f_add_gutenberg_assets'));
            add_filter('the_content', array(__CLASS__,'tech888f_filter_content'),99);
        }

        static function tech888f_set_pass( $user_id ){
            if ( isset( $_POST['apply_for_vendor'] ) && '1' ==  $_POST['apply_for_vendor']){
                $u = new WP_User( $user_id );
                // Remove role
                $u->remove_role( get_option( 'default_role' ) );

                // Add role
                $u->add_role( 'pending_vendor' );
            }
            if ( isset( $_POST['password'] ) ) wp_set_password( $_POST['password'], $user_id );
        }

        static function tech888f_filter_content($content){
            $content = str_replace('width="640"', 'width="740"', $content);
            $content = str_replace('height="360"', 'height="416"', $content);
            return $content;
        }

        static function tech888f_add_gutenberg_assets() {
            wp_enqueue_style( 'tech888f-gutenberg', get_theme_file_uri( '/assets/css/sass/gutenberg-editor-style.css' ), false );
            wp_enqueue_style('tech888f-google-fonts',tech888f_get_google_link() );
        }

        static function _add_scripts(){
            $css_url = get_template_directory_uri() . '/assets/css/';
            $js_url  = get_template_directory_uri() . '/assets/js/';
            $api_key = tech888f_get_option('map_api_key');
            global $tech888f_config;
            /*
             * Javascript
             * */
            if ( is_singular() && comments_open()){
            wp_enqueue_script( 'comment-reply' );
            }
            if(class_exists("woocommerce")){
                wp_enqueue_script( 'wc-add-to-cart-variation' );
            }

            //ENQUEUE JS

            // Load boostrap script lib version
           wp_enqueue_script( 'bootstrap',$js_url.'lib/bootstrap.min.js',array('jquery'),null,true);
            
            // Load script form wp lib
            wp_enqueue_script('jquery-masonry');
            wp_enqueue_script( 'jquery-ui-tabs');
            wp_enqueue_script( 'jquery-ui-slider');

            // Map script
            if(tech888f_check_enqueue('sv_map') && !empty($api_key)){
                wp_enqueue_script( 'google-map', "//maps.google.com/maps/api/js?key=".$api_key, array('jquery'), null, true );
                wp_enqueue_script( 'tech888f-script-map',$js_url.'map.min.js',array('jquery'),null,true);
            }

            // Load lib
            wp_enqueue_script( 'jquery-fancybox',$js_url.'lib/jquery.fancybox.min.js',array('jquery'),null,true);
            wp_enqueue_script( 'owl-carousel',$js_url.'lib/owl.carousel.min.js',array('jquery'),null,true);
            //wp_enqueue_script( 'jquery-jcarousellite',$js_url.'lib/jquery.jcarousellite.min.js',array('jquery'),null,true);
            //wp_enqueue_script( 'jquery-elevatezoom',$js_url.'lib/jquery.elevatezoom.min.js',array('jquery'),null,true);
         //   wp_enqueue_script( 'timecircles',$js_url.'lib/TimeCircles.min.js',array('jquery'),null,true);
         //   wp_enqueue_script( 'tech888f-tweenmax',$js_url.'lib/tweenmax.min.js',array('jquery'),null,true);
        //    wp_enqueue_script( 'tech888f-backgroundjs',$js_url.'lib/parallax_background.js',array('jquery'),null,true);
            // Custom script
            wp_enqueue_script( 'tech888f-script',$js_url.'script.js',array('jquery'),null,true);

            //AJAX
            wp_enqueue_script( 'tech888f-ajax', $js_url.'ajax.js', array( 'jquery' ),null,true);
            wp_localize_script( 'tech888f-ajax', 'ajax_process', array( 'ajaxurl' => admin_url( 'admin-ajax.php' )));
            if(class_exists('woocommerce')){
                wp_localize_script('tech888f-ajax', 'global_var', array(
                        'woo_cart_url' => get_permalink( wc_get_page_id( 'cart' ) )
                    )
                );
            }

            // ENQUEUE CSS

            // load icon lib
            $icon_lib = tech888f_get_option('tech888f_icon_lib','fontawesome');
            if(function_exists('vc_icon_element_fonts_enqueue')) vc_icon_element_fonts_enqueue( $icon_lib );

            
            // Load font
          //  wp_enqueue_style('tech888f-google-fonts',tech888f_get_google_link() );
          //  var_dump(tech888f_get_google_link());
            
            // Load boostrap style lib version
            // Vân replaced file bootstrap.min.css v5.
           wp_enqueue_style('bootstrap',$css_url.'lib/bootstrap.min.css');

            // Load lib
            wp_dequeue_style( 'yith-wcwl-font-awesome' );
            // wp_dequeue_style( 'font-awesome');
                wp_dequeue_style( 'fontawesome');
            // wp_enqueue_style('t888-font-awesome',$css_url.'lib/font-awesome.min.css');
            wp_enqueue_style('t888-font-awesome',$css_url.'lib/fontawesome.min.css');
         //   wp_enqueue_style('bootstrap-theme',$css_url.'lib/bootstrap-theme.min.css');
            wp_enqueue_style('jquery-fancybox',$css_url.'lib/jquery.fancybox.min.css');
            wp_enqueue_style('jquery-ui',$css_url.'lib/jquery-ui.min.css');
            wp_enqueue_style('owl-carousel',$css_url.'lib/owl.carousel.min.css');
            wp_enqueue_style('owl-theme',$css_url.'lib/owl.theme.min.css');
           // wp_enqueue_style('animate-css');
            wp_enqueue_style('animate-css',$css_url.'lib/animations.min.css');
            wp_enqueue_style('tech888f-color',$css_url.'lib/color.min.css');
            wp_enqueue_style('tech888f-hover-lib',$css_url.'lib/hover.min.css');
//            wp_enqueue_style('tech888f-linear-icon-lib',$css_url.'lib/linear-icon.min.css');
            wp_enqueue_style('tech888f-theme',$css_url.'lib/theme.css');
            wp_enqueue_style('tech888f-theme-css',$css_url.'lib/style-nhov.css');
        //    wp_enqueue_style('tech888f-theme-style',$css_url.'/sass/sass.css');
            wp_enqueue_style('tech888f-responsive',$css_url.'responsive.css');

            // Inline css
            $custom_style = tech888f_Template::load_view('custom_css');
            if(!empty($custom_style)) {
                wp_add_inline_style('tech888f-theme-style',$custom_style);
            }
            // Default style
            wp_enqueue_style('tech888f-theme-default',get_stylesheet_uri());

        }


        static function _blog_filter_sidebar($sidebar){
            if((!is_front_page() && is_home()) || (is_front_page() && is_home() || is_front_page())){
                $pos=tech888f_get_option('tech888f_sidebar_position_blog');
                if(tech888f_get_meta('page_sidebar_pos','') != ''){
                    $pos = tech888f_get_meta('page_sidebar_pos','');
                }
                $sidebar_id=tech888f_get_option('tech888f_sidebar_blog');
            }
            else{
                if(is_single()){
                    $pos = tech888f_get_option('tech888f_sidebar_position_post');
                    $sidebar_id = tech888f_get_option('tech888f_sidebar_post');
                    if(tech888f_get_meta('post_sidebar_position','') != ''){
                        $pos = tech888f_get_meta('post_sidebar_position','');
                        if(tech888f_get_meta('post_sidebar_position','') != 'no' && tech888f_get_meta('post_sidebar_position','') != ''){
                            $sidebar_id = tech888f_get_meta('post_sidebar_item','');
                        }
                    }
                }
                else{
                    $pos = tech888f_get_option('tech888f_sidebar_position_page');
                    $sidebar_id = tech888f_get_option('tech888f_sidebar_page');
                    if(tech888f_get_meta('page_sidebar_pos','') != ''){
                        $pos = tech888f_get_meta('page_sidebar_pos','');
                        if(tech888f_get_meta('page_sidebar_pos','') != 'no' && tech888f_get_meta('page_sidebar_pos','') != ''){
                            $sidebar_id = tech888f_get_meta('page_sidebar_spec','');
                        }
                    }
                }
            }
            if(class_exists( 'WooCommerce' )){
                if(tech888f_is_woocommerce_page()){
                    $pos = tech888f_get_option('tech888f_sidebar_position_woo');
                    $sidebar_id = tech888f_get_option('tech888f_sidebar_woo');
                    if(tech888f_get_meta('page_sidebar_pos','') != ''){
                        $pos = tech888f_get_meta('page_sidebar_pos','');
                        if(tech888f_get_meta('page_sidebar_pos','') != 'no' && tech888f_get_meta('page_sidebar_pos','') != ''){
                            $sidebar_id = tech888f_get_meta('page_sidebar_spec','');
                        }
                    }
                    if(is_product()){
                        $pos = tech888f_get_option('sv_sidebar_position_woo_single');
                        $sidebar_id = tech888f_get_option('sv_sidebar_woo_single');
                        if(tech888f_get_meta('product_sidebar_pos','') != ''){
                            $pos = tech888f_get_meta('product_sidebar_pos','');
                            if(tech888f_get_meta('product_sidebar_pos','') != 'no' && tech888f_get_meta('product_sidebar_pos','') != ''){
                                $sidebar_id = tech888f_get_meta('product_sidebar_spec','');
                            }
                        }
                    }
                }
            }
            if(is_archive() && !tech888f_is_woocommerce_page()){
                $pos = tech888f_get_option('tech888f_sidebar_position_page_archive','right');
                $sidebar_id = tech888f_get_option('tech888f_sidebar_page_archive','blog-sidebar');
            }
            else{
                if(!is_home()){
                    $id = tech888f_get_current_id();
                    $sidebar_pos = get_post_meta($id,'tech888f_sidebar_position',true);
                    $id_side_post = get_post_meta($id,'tech888f_select_sidebar',true);
                    if(!empty($sidebar_pos)){
                        $pos = $sidebar_pos;
                        if(!empty($id_side_post)) $sidebar_id = $id_side_post;
                    }
                }
            }
            if(is_search()) {
                $post_type = '';
                if(isset($_GET['post_type'])) $post_type = sanitize_text_field($_GET['post_type']);
                if($post_type != 'product'){
                    $pos = tech888f_get_option('tech888f_sidebar_position_page_search','right');
                    $sidebar_id = tech888f_get_option('tech888f_sidebar_page_search','blog-sidebar');
                }              
            }
            if($sidebar_id) $sidebar['id'] = $sidebar_id;
            if($pos) $sidebar['position'] = $pos;
            return $sidebar;
        }

        static function _header_id($page_id){
            if(tech888f_is_woocommerce_page()){
                $id = tech888f_get_current_id();
                $meta_value = get_post_meta($id,'tech888f_header_page',true);
                $id_woo = tech888f_get_option('tech888f_header_page_woo');
                if(empty($meta_value) && !empty($id_woo)) $page_id = $id_woo;                    
            }
            return $page_id;
        }

        static function _footer_id($page_id){
            if(tech888f_is_woocommerce_page()){
                $id = tech888f_get_current_id();
                $meta_value = get_post_meta($id,'tech888f_footer_page',true);
                $id_woo = tech888f_get_option('tech888f_footer_page_woo');
                if(empty($meta_value) && !empty($id_woo)) $page_id = $id_woo;                  
            }
            return $page_id;
        }
        
        
        // -----------------------------------------------------
        // Default Hooked, Do not edit

        /**
         * Hook setup theme
         *
         *
         * */

        static function _after_setup_theme(){
            /*
             * Make theme available for translation.
             * Translations can be filed in the /languages/ directory.
             * If you're building a theme based on stframework, use a find and replace
             * to change LANGUAGE to the name of your theme in all the template files
             */

            // This theme uses wp_nav_menu() in one location.
            global $tech888f_config;
            $menus= $tech888f_config['nav_menu'];
            if(is_array($menus) and !empty($menus) ){
                register_nav_menus($menus);
            }


            add_theme_support( "title-tag" );
            add_theme_support('automatic-feed-links');
            add_theme_support('post-thumbnails');
            add_theme_support('html5',array(
                'search-form', 'comment-form', 'comment-list', 'gallery', 'caption',
            ));
            add_theme_support('post-formats',array(
                'image', 'video', 'gallery','audio','quote'
            ));
            add_theme_support('custom-header');
            add_theme_support('custom-background');
            add_theme_support( 'wc-product-gallery-slider' );
            add_theme_support( 'woocommerce', array(
                'gallery_thumbnail_image_width' => 150,
                ));
        }

        /**
         * Add default sidebar to website
         *
         *
         * */
        static function _add_sidebars(){
            // From config file
            global $tech888f_config;
            $sidebars = $tech888f_config['sidebars'];
            if(is_array($sidebars) and !empty($sidebars) ){
                foreach($sidebars as $value){
                    register_sidebar($value);
                }
            }
            $add_sidebars = tech888f_get_option('tech888f_add_sidebar');
            if(is_array($add_sidebars) and !empty($add_sidebars) ){
                foreach($add_sidebars as $sidebar){
                    if(!empty($sidebar['title'])){
                        $id = strtolower(str_replace(' ', '-', $sidebar['title']));
                        $custom_add_sidebar = array(
                                'name' => $sidebar['title'],
                                'id' => $id,
                                'description' => esc_html__( 'SideBar created by add sidebar in theme options.', 'posolo'),
                                'before_title' => '<'.$sidebar['widget_title_heading'].' class="widget-title">',
                                'after_title' => '</'.$sidebar['widget_title_heading'].'>',
                                'before_widget' => '<div id="%1$s" class="sidebar-widget widget %2$s">',
                                'after_widget'  => '</div>',
                            );
                        register_sidebar($custom_add_sidebar);
                        unset($custom_add_sidebar);
                    }
                }
            }

        }

        static function tech888f_setup_options(){
            update_option( 'tech888f_woo_widgets', 'false' );
        }


        /**
         * Set up author data
         *
         * */
        static function _setup_author(){
            global $wp_query;

            if ( $wp_query->is_author() && isset( $wp_query->post ) ) {
                $GLOBALS['authordata'] = get_userdata( $wp_query->post->post_author );
            }
        }


        /**
         * Hook to wp_title
         *
         * */
        static function _wp_title($title,$sep){
            return $title;
        }


        static function _add_admin_scripts(){
            $admin_url = get_template_directory_uri().'/assets/admin/';
            wp_enqueue_media();
            add_editor_style();   
            wp_enqueue_script('redux-js');         
            wp_enqueue_script( 'tech888f-admin-js', $admin_url . '/js/admin.js', array( 'jquery' ),null,true );
            wp_enqueue_style( 'font-awesome',$admin_url.'css/font-awesome.css');
            wp_enqueue_style( 'fontawesome',$admin_url.'css/fontawesome.css');
            wp_enqueue_style( 'tech888f-custom-admin',$admin_url.'css/custom.css');
            $css_url = get_template_directory_uri() . '/assets/css/';
            wp_enqueue_style('ionicons',$css_url.'lib/ionicons.min.css');
        }

        static function _woocommerce_product_query($query){
            if($query->get( 'post_type' ) == 'product'){
                $query->set('post__not_in', '');
            } 
        }

        static function tech888f_body_classes($classes){
            $page_style     = tech888f_get_value_by_id('tech888f_page_style');
            $menu_fixed     = tech888f_get_value_by_id('tech888f_menu_fixed');
            $shop_ajax      = tech888f_get_option('shop_ajax');
            $show_preload   = tech888f_get_option('show_preload');
            $theme_info     = wp_get_theme();
            $id             = tech888f_get_current_id();
            $session_page = tech888f_get_option('session_page');
            $header_session = get_post_meta($id,'tech888f_header_page',true);
            if(empty($header_session) && $session_page == '1'){ 
                $classes[] = 'header-session';
            }
            if(!empty($page_style)) $classes[] = $page_style;
            if(is_rtl()) $classes[] = 'rtl-enable';
            if($show_preload == '1') $classes[] = 'preload';
            if($shop_ajax == '1' && tech888f_is_woocommerce_page()) $classes[] = 'shop-ajax-enable';
            if(!empty($theme_info['Template'])) $theme_info = wp_get_theme($theme_info['Template']);
            $classes[]  = 'theme-ver-'.$theme_info['Version'];
            global $post;
            if(isset($post->post_content)){
                if(strpos($post->post_content, '[tech888f_shop')){
                    $classes[] = 'woocommerce';
                    if(strpos($post->post_content, 'shop_ajax="on"')) $classes[] = 'shop-ajax-enable';
                }
            }
            return $classes;
        }

        // theme function
        static function tech888f_display_breadcrumb(){

            echo tech888f_get_template('breadcrumb');
        }

        static function tech888f_product_cat_metabox_add($tag) {
            ?>
            <div class="form-field">
                <label><?php esc_html_e('Append Content Before','posolo'); ?></label>
                <div class="wrap-metabox">
                    <select name="before_append" id="before_append">
                        <?php
                        $mega_pages = tech888f_list_post_type('tech888f_mega_item',false);
                        foreach ($mega_pages as $key => $value) {
                            echo '<option value="'.esc_attr($key).'">'.esc_html($value).'</option>';
                        }
                        ?>
                    </select>
                </div>
            </div>
            <div class="form-field">
                <label><?php esc_html_e('Append Content After','posolo'); ?></label>
                <div class="wrap-metabox">
                    <select name="after_append" id="after_append">
                        <?php
                        foreach ($mega_pages as $key => $value) {
                            echo '<option value="'.esc_attr($key).'">'.esc_html($value).'</option>';
                        }
                        ?>
                    </select>
                </div>
            </div>
        <?php }
        static function tech888f_product_cat_metabox_edit($tag) { ?>
            <tr class="form-field">
                <th scope="row" valign="top">
                    <label><?php esc_html_e('Append Content Before','posolo'); ?></label>
                </th>
                <td>            
                    <div class="wrap-metabox">
                        <select name="before_append" id="before_append">
                            <?php
                            $page = get_term_meta($tag->term_id, 'before_append', true);
                            $mega_pages = tech888f_list_post_type('tech888f_mega_item',false);
                            foreach ($mega_pages as $key => $value) {
                                $selected = selected($key,$page,false);
                                echo '<option '.$selected.' value="'.esc_attr($key).'">'.esc_html($value).'</option>';
                            }
                            ?>
                        </select>
                    </div>            
                </td>
            </tr>
            <tr class="form-field">
                <th scope="row" valign="top">
                    <label><?php esc_html_e('Append Content After','posolo'); ?></label>
                </th>
                <td>            
                    <div class="wrap-metabox">
                        <select name="after_append" id="after_append">
                            <?php
                            $page = get_term_meta($tag->term_id, 'after_append', true);
                            foreach ($mega_pages as $key => $value) {
                                $selected = selected($key,$page,false);
                                echo '<option '.$selected.' value="'.esc_attr($key).'">'.esc_html($value).'</option>';
                            }
                            ?>
                        </select>
                    </div>            
                </td>
            </tr>
        <?php }
        static function tech888f_product_save_category_metadata($term_id){
            if (isset($_POST['before_append'])){
                $before_append = sanitize_text_field($_POST['before_append']);
                update_term_meta( $term_id, 'before_append', $before_append);
            }
            if (isset($_POST['after_append'])){
                $after_append = sanitize_text_field($_POST['after_append']);
                update_term_meta( $term_id, 'after_append', $after_append);
            }
        }

        static function tech888f_append_content_before(){
            $post_id = tech888f_get_option('before_append_post');
            if(tech888f_is_woocommerce_page()){
                $page_id = tech888f_get_option('before_append_woo');
                if(is_single()) $page_id = tech888f_get_option('before_append_woo_single');
            }
            elseif(is_home() || is_archive() || is_search() || is_singular('post')) $page_id = $post_id;
            else $page_id = tech888f_get_option('before_append_page');
            $id = tech888f_get_current_id();
            $meta_id = get_post_meta($id,'before_append',true);
            if(!empty($meta_id)) $page_id = $meta_id;
            if(function_exists('is_shop')) $is_shop = is_shop();
            else $is_shop = false;           
            if(is_archive() && !$is_shop){
                global $wp_query;
                $term = $wp_query->get_queried_object();
                if(isset($term->term_id)) $cat_id = get_term_meta($term->term_id, 'before_append', true);
                else $cat_id = '';
                if(!empty($cat_id)) $page_id = $cat_id;
            }
            if(!empty($page_id)) echo '<div class="content-append-before"><div class="container">'.tech888f_Template::get_vc_pagecontent($page_id).'</div></div>';
        }
        static function tech888f_append_content_after(){
            $post_id = tech888f_get_option('after_append_post');
            if(tech888f_is_woocommerce_page()){
                $page_id = tech888f_get_option('after_append_woo');
                if(is_single()) $page_id = tech888f_get_option('after_append_woo_single');
            }
            elseif(is_home() || is_archive() || is_search() || is_singular('post')) $page_id = $post_id;
            else $page_id = tech888f_get_option('after_append_page');
            $id = tech888f_get_current_id();
            $meta_id = get_post_meta($id,'after_append',true);
            if(!empty($meta_id)) $page_id = $meta_id;
            if(function_exists('is_shop')) $is_shop = is_shop();
            else $is_shop = false;           
            if(is_archive() && !$is_shop){
                global $wp_query;
                $term = $wp_query->get_queried_object();
                if(isset($term->term_id)) $cat_id = get_term_meta($term->term_id, 'after_append', true);
                else $cat_id = '';
                if(!empty($cat_id)) $page_id = $cat_id;
            }
            if(!empty($page_id)) echo '<div class="content-append-after"><div class="container">'.tech888f_Template::get_vc_pagecontent($page_id).'</div></div>';
        }

        static function tech888f_custom_posts_per_page($query){
            if( $query->is_main_query() && ! is_admin() && $query->get( 'post_type' ) != 'product') {
                $number         = get_option('posts_per_page');
                if(isset($_GET['number'])) $number = sanitize_text_field($_GET['number']);
                $query->set( 'posts_per_page', $number );
            }
        }
    }

    tech888f_BaseController::_init();
}
if(!function_exists('tech888f_default_widget_demo')){
    function tech888f_default_widget_demo(){
        $tech888f_woo_widgets = get_option( 'tech888f_woo_widgets' );
        $active_widgets = get_option( 'sidebars_widgets' );
        if($tech888f_woo_widgets != 'true' && isset($active_widgets['woocommerce-sidebar']) && empty($active_widgets['woocommerce-sidebar'])){
            update_option( 'tech888f_woo_widgets', 'true' );
            $widgets = array(
                'woocommerce_product_categories' => array(
                    'title' => esc_html__('Product categories','posolo'),
                    'orderby' => 'name',
                    'dropdown' => 0,
                    'count' => 0,
                    'hierarchical' => 1,
                    'show_children_only' => 0,
                    'hide_empty' => 0,
                    'max_depth' => ''
                    ),
                'woocommerce_price_filter' => array(
                    'title' => esc_html__('Filter by price','posolo'),
                    ),
                'woocommerce_products' => array(
                    'title' => esc_html__('Products','posolo'),
                    'number' =>  5,
                    'show' => '',
                    'orderby' => 'date',
                    'order' => 'desc',
                    'hide_free' => 0,
                    'show_hidden' => 0,
                    ),
                'woocommerce_product_search' => array(
                    'title' => ''
                    ),
                );
            $woo_active_widgets = array();
            foreach ($widgets as $widget_id => $widget) {
                $w_data = get_option( 'widget_'.$widget_id );
                $w_data[1] = $widget;
                update_option( 'widget_'.$widget_id, $w_data );
                $woo_active_widgets[] = $widget_id.'-1';
            }
            $active_widgets['woocommerce-sidebar'] = $woo_active_widgets;
            update_option( 'sidebars_widgets', $active_widgets );
        }
    }
}
tech888f_default_widget_demo();
