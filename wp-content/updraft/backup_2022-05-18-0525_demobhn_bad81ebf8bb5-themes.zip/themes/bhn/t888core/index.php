<?php
/**
 * Created by Sublime Text 2.
 * User: thanhhiep992
 * Date: 12/08/15
 * Time: 10:20 AM
 */

if(!defined('ABSPATH')) return;
if(function_exists('tech888f_load_lib')){
	if(class_exists('Vc_Manager') && class_exists('PluginCore')){
		tech888f_load_lib('element');
	} 
	tech888f_load_lib('widget');
	if (is_plugin_active( 'elementor/elementor.php' )  ) {
        tech888f_load_lib('elementor-widget');
    }
}