( function( $ ) {
    var WidgetExtendToggleHandler = function( $scope, $ ) {
        $scope.find('.elementor-tab-title-extend').on("click",function (e) {
            e.preventDefault();
            $(this).toggleClass('tab-title-active');
           $(this).next().collapse('toggle');
        });

    };
    // Make sure you run this code under Elementor.
    $( window ).on( 'elementor/frontend/init', function() {
        elementorFrontend.hooks.addAction( 'frontend/element_ready/extend-toggle.default', WidgetExtendToggleHandler );
    } );
} )( jQuery );