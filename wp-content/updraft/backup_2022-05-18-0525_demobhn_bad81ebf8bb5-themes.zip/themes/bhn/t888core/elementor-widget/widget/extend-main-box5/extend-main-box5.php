<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}
namespace Elementor;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

/**
 * Elementor heading widget.
 *
 * Elementor widget that displays an eye-catching headlines.
 *
 * @since 1.0.0
 */
class Widget_Extend_Main_Box5 extends Widget_Base {

    /**
     * Get widget name.
     *
     * Retrieve heading widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'extend-main-box5';
    }

    /**
     * Get widget title.
     *
     * Retrieve heading widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Extend BHN Box5', 'elementor' );
    }

    /**
     * Get widget icon.
     *
     * Retrieve heading widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return '';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the heading widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * @since 2.0.0
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'basic' ];
    }

    /**
     * Get widget keywords.
     *
     * Retrieve the list of keywords the widget belongs to.
     *
     * @since 2.1.0
     * @access public
     *
     * @return array Widget keywords.
     */
    public function get_keywords() {
        return [ 'heading', 'title', 'text' ];
    }

    /**
     * Register heading widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 3.1.0
     * @access protected
     */
    protected function register_controls() {
        $this->start_controls_section(
            'section_title',
            [
                'label' => __( 'Title', 'elementor' ),
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => __( 'Title', 'elementor' ),
                'type' => Controls_Manager::TEXTAREA,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => __( 'Enter your title', 'elementor' ),
                'default' => __( 'Add Your Heading Text Here', 'elementor' ),
            ]
        );

        $repeater = new Repeater();
        $repeater->add_control(
            'image',
            [
                'label' => __( 'Image', 'elementor' ),
                'type' => Controls_Manager::MEDIA,
            ]
            );

        $repeater->add_control(
            'description',
            [
                'label' => __( 'Description', 'elementor-pro' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => __( 'Your description here', 'elementor-pro' ),
                'show_label' => false,
            ]
        );
        $repeater->add_control(
                'title',
                [
                    'label' => __( 'Title', 'elementor-pro' ),
                    'type'  => Controls_Manager::TEXTAREA,
                    'default' => 'Title Box',
                    'description' => 'Using for case white space entity.',
                ]
        );
        $repeater->add_control(
            'link',
            [
                'label' => __( 'Link', 'elementor-pro' ),
                'type' => Controls_Manager::URL,
                'placeholder' => __( 'https://your-link.com', 'elementor-pro' ),
            ]
        );
        $repeater->add_control(
			'margin',
			[
				'type' => Controls_Manager::TEXT,
				'label' => esc_html__( 'Margin', 'elementor' )
			]
		);
        $this->add_control(
                'descriptions',
                [
                    'label' => __( 'Descriptions', 'elementor-pro' ),
                    'type' => Controls_Manager::REPEATER,
                    'show_label' => true,
                    'fields' => $repeater->get_controls(),
                    'default' => [
                       [
                           'description' => __( 'Description Box', 'elementor-pro' ),
                       ],
                    ],
                    'title_field' => '{{{ title }}}'
                ]
        );

        $this->add_control(
          'style',
          [
              'label' => __( 'Style', 'elementor' ),
              'type' => Controls_Manager::SELECT,
              'placeholder' => __( 'Select title style', 'elementor' ),
              'options' => [
                      'default' => 'Default - Center Align Home',
                      'style2' => 'Style 2 - Align left',
              ],
              'default' => 'default'
          ]
        );

        $this->add_control(
            'button_text',
            [
                'label' => __( 'Button', 'elementor-pro' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( 'Đăng ký ngay', 'elementor-pro' ),
            ]
        );
       $this->add_control(
           'link',
           [
            'label' => __( 'Link', 'elementor-pro' ),
            'type' => Controls_Manager::URL,
            'placeholder' => __( 'https://your-link.com', 'elementor-pro' ),
           ]
       );

        $this->add_control(
            'size',
            [
                'label' => __( 'Size', 'elementor' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'default',
                'options' => [
                    'default' => __( 'Default', 'elementor' ),
                    'small' => __( 'Small', 'elementor' ),
                    'medium' => __( 'Medium', 'elementor' ),
                    'large' => __( 'Large', 'elementor' ),
                    'xl' => __( 'XL', 'elementor' ),
                    'xxl' => __( 'XXL', 'elementor' ),
                ],
            ]
        );

        $this->add_control(
            'header_size',
            [
                'label' => __( 'HTML Tag', 'elementor' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => 'H1',
                    'h2' => 'H2',
                    'h3' => 'H3',
                    'h4' => 'H4',
                    'h5' => 'H5',
                    'h6' => 'H6',
                    'div' => 'div',
                    'span' => 'span',
                    'p' => 'p',
                ],
                'default' => 'h4',
            ]
        );

        $this->add_responsive_control(
            'align',
            [
                'label' => __( 'Alignment', 'elementor' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => __( 'Left', 'elementor' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => __( 'Center', 'elementor' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => __( 'Right', 'elementor' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                    'justify' => [
                        'title' => __( 'Justified', 'elementor' ),
                        'icon' => 'eicon-text-align-justify',
                    ],
                ],
                'default' => 'left',
                'selectors' => [
                    '{{WRAPPER}}' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'view',
            [
                'label' => __( 'View', 'elementor' ),
                'type' => Controls_Manager::HIDDEN,
                'default' => 'traditional',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_title_style',
            [
                'label' => __( 'Title', 'elementor' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __( 'Text Color', 'elementor' ),
                'type' => Controls_Manager::COLOR,
                'global' => [
                    'default' => Global_Colors::COLOR_PRIMARY,
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-heading-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'typography',
                'global' => [
                    'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
                ],
                'selector' => '{{WRAPPER}} .elementor-heading-title',
            ]
        );

        $this->add_group_control(
            Group_Control_Text_Shadow::get_type(),
            [
                'name' => 'text_shadow',
                'selector' => '{{WRAPPER}} .elementor-heading-title',
            ]
        );

        $this->add_control(
            'blend_mode',
            [
                'label' => __( 'Blend Mode', 'elementor' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '' => __( 'Normal', 'elementor' ),
                    'multiply' => 'Multiply',
                    'screen' => 'Screen',
                    'overlay' => 'Overlay',
                    'darken' => 'Darken',
                    'lighten' => 'Lighten',
                    'color-dodge' => 'Color Dodge',
                    'saturation' => 'Saturation',
                    'color' => 'Color',
                    'difference' => 'Difference',
                    'exclusion' => 'Exclusion',
                    'hue' => 'Hue',
                    'luminosity' => 'Luminosity',
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-heading-title' => 'mix-blend-mode: {{VALUE}}',
                ],
                'separator' => 'none',
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Render heading widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        if ( '' === $settings['title'] ) {
            return;
        }
        $this->add_render_attribute( 'title', 'class', 'title '.$settings['style'].'' );


        if ( ! empty( $settings['size'] ) ) {
            $this->add_render_attribute( 'title', 'class', 'elementor-size-' . $settings['size'] );
        }

        $this->add_inline_editing_attributes( 'title' );

        $title = $settings['title'];

        $title_class = $this->get_render_attribute_string( 'title' );
        $title_html = sprintf( '<%1$s %2$s>%3$s</%1$s>', Utils::validate_html_tag( $settings['header_size'] ), $title_class, $title );

        if($settings['image']) {
           // $image_html = '<div class="image-wrap">'.wp_get_attachment_image($settings['image']['id'],array(114,114),false,array()).'</div>';
        }
        $header_html = '<div class="box-title text-center" style="text-align:{{ settings.align }};">'.$title_html.'</div>';
        // var_dump($settings);
        $des_html = '';
        if($settings['descriptions'] ){
            $des_html = '';
            foreach ($settings['descriptions'] as $description){
                $des_html .= '<div class="col-xl-4 col-lg-6">
                                <div class="customer-item" margin: '.$description["margin"].'">
                                    <a  href="'.$description["link"]['url'].'" class="images-form">
                                        <img src="'.$description["image"]['url'].'" alt="" class="lazy entered loaded">
                                    </a>
                                    <div class="content-form">
                                        <h5 class="customer-title"> 
                                            <a href="'.$description["link"]['url'].'" target="_blank" class="color-text-primary">'.$description["title"].'</a>
                                        </h5>
                                        <p class="color-text-secondary font-small mb-0">'.$description["description"].'</p>
                                    </div>
                                </div>
                            </div>';
            }
            $des_html .= '';
        }
        echo '<div class="customer-box wow fadeInUp">
                <div class="container">
                    '.$header_html.'
                    <div class="row customer-list">';
                            echo $des_html;
                echo '</div></div>';
                echo '<div class="box-link-customer text-center"> 
                        <a href="'.$settings["link"]['url'].'" class="btn btn-outline-primary" rel="nofollow">'.$settings['button_text'].'</a>
                    </div>';
        echo '</div>';
    }

    /**.$settings['image']['url'].
     * Render heading widget output in the editor.
     *
     * Written as a Backbone JavaScript template and used to generate the live preview.
     *
     * @since 2.9.0
     * @access protected
     */
    protected function content_template() {
        ?>
        <#
        var title = settings.title;

        view.addRenderAttribute( 'title', 'class', [ 'title '+settings.style, 'elementor-size-' + settings.size ] );
        view.addInlineEditingAttributes( 'title' );

        var headerSizeTag = elementor.helpers.validateHTMLTag( settings.header_size );
        title_html = '<' + headerSizeTag  + ' ' + view.getRenderAttributeString( 'title' ) + '>' + title + '</' + headerSizeTag + '>';
        <!-- console.log(title_html); -->
        var image_html = '';
        #>
        <div class="customer-box wow fadeInUp">
                <div class="container">
                    <div class="box-title text-center" style="text-align:{{ settings.align }};"> 
                        {{{title_html}}}
                    </div>
                    <div class="row customer-list">
        <!-- var des_html = ''; -->
                        <#jQuery.each( settings.descriptions, function( index, description ){#>
                            <div class="col-xl-4 col-lg-6">
                                <div class="customer-item" style="margin:{{description.margin}}">
                                
                                    <a  href="{{description.link.url}}" class="images-form">
                                        <img src="{{description.image.url}}" alt="" class="lazy entered loaded">
                                    </a>
                                    <div class="content-form">
                                        <h5 class="customer-title"> 
                                            <a href="{{description.link.url}}" target="_blank" class="color-text-primary">{{{description.title}}}</a>
                                        </h5>
                                        <p class="color-text-secondary font-small mb-0">{{{description.description}}}</p>
                                    </div>
                                </div>
                            </div>
                        <# }); #>
                        </div>
                    </div>
                    <div class="box-link-customer text-center"> 
                        <a href="{{settings.link.url}}" class="btn btn-outline-primary" rel="nofollow">{{{settings.button_text}}}</a>
                    </div>
                </div>
        </div>
        <?php
    }
}
?>