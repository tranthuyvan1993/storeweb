<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}
namespace Elementor;
use Elementor\Core\Kits\Documents\Tabs\Global_Colors;
use Elementor\Core\Kits\Documents\Tabs\Global_Typography;

/**
 * Elementor heading widget.
 *
 * Elementor widget that displays an eye-catching headlines.
 *
 * @since 1.0.0
 */
class Widget_Extend_Bhn_Banner extends Widget_Base {

    /**
     * Get widget name.
     *
     * Retrieve heading widget name.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'extend-bhn-banner';
    }

    /**
     * Get widget title.
     *
     * Retrieve heading widget title.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'News BHN', 'elementor' );
    }

    /**
     * Get widget icon.
     *
     * Retrieve heading widget icon.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return '';
    }

    /**
     * Get widget categories.
     *
     * Retrieve the list of categories the heading widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * @since 2.0.0
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'basic' ];
    }

    /**
     * Get widget keywords.
     *
     * Retrieve the list of keywords the widget belongs to.
     *
     * @since 2.1.0
     * @access public
     *
     * @return array Widget keywords.
     */
    public function get_keywords() {
        return [ 'heading', 'title', 'text' ];
    }

    /**
     * Register heading widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 3.1.0
     * @access protected
     */
    protected function register_controls() {
        $this->start_controls_section(
            'section_title',
            [
                'label' => __( 'Title', 'elementor' ),
            ]
        );

        $this->add_control(
            'title1',
            [
                'label' => __( 'Title', 'elementor' ),
                'type' => Controls_Manager::TEXTAREA,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => __( 'Enter your title', 'elementor' ),
                'default' => __( 'Add Your Heading Text Here', 'elementor' ),
            ]
        );
        $this->add_control(
            'header_size1',
            [
                'label' => __( 'HTML Tag', 'elementor' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => 'H1',
                    'h2' => 'H2',
                    'h3' => 'H3',
                    'h4' => 'H4',
                    'h5' => 'H5',
                    'h6' => 'H6',
                    'div' => 'div',
                    'span' => 'span',
                    'p' => 'p',
                ],
                'default' => 'h4',
            ]
        );
        $this->add_control(
            'title2',
            [
                'label' => __( 'Title', 'elementor' ),
                'type' => Controls_Manager::TEXTAREA,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => __( 'Enter your title', 'elementor' ),
                'default' => __( 'Add Your Heading Text Here', 'elementor' ),
            ]
        );
        $this->add_control(
            'header_size2',
            [
                'label' => __( 'HTML Tag', 'elementor' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => 'H1',
                    'h2' => 'H2',
                    'h3' => 'H3',
                    'h4' => 'H4',
                    'h5' => 'H5',
                    'h6' => 'H6',
                    'div' => 'div',
                    'span' => 'span',
                    'p' => 'p',
                ],
                'default' => 'h4',
            ]
        );
        $this->add_control(
            'title3',
            [
                'label' => __( 'Title', 'elementor' ),
                'type' => Controls_Manager::TEXTAREA,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => __( 'Enter your title', 'elementor' ),
                'default' => __( 'Add Your Heading Text Here', 'elementor' ),
            ]
        );
        
        $this->add_control(
            'header_size3',
            [
                'label' => __( 'HTML Tag', 'elementor' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => 'H1',
                    'h2' => 'H2',
                    'h3' => 'H3',
                    'h4' => 'H4',
                    'h5' => 'H5',
                    'h6' => 'H6',
                    'div' => 'div',
                    'span' => 'span',
                    'p' => 'p',
                ],
                'default' => 'h4',
            ]
        );
        $this->add_control(
            'bg_image',
            [
                'label' => __( 'Image', 'elementor' ),
                'type' => Controls_Manager::MEDIA,
            ]
            );

        $this->add_control(
            'bg_color',
            [
                'label' => __( 'Màu nền', 'elementor' ),
                'type' => Controls_Manager::COLOR,
                'global' => [
                    'default' => Global_Colors::COLOR_PRIMARY,
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-heading-title' => 'color: {{VALUE}};',
                ],
            ]
        );
        $this->add_control(
          'style',
          [
              'label' => __( 'Style', 'elementor' ),
              'type' => Controls_Manager::SELECT,
              'placeholder' => __( 'Select title style', 'elementor' ),
              'options' => [
                      'default' => 'Default - Center Align Home',
                      'style2' => 'Style 2 - Align left',
              ],
              'default' => 'default'
          ]
        );

        $this->add_control(
            'button_text',
            [
                'label' => __( 'Button', 'elementor-pro' ),
                'type' => Controls_Manager::TEXT,
                'default' => __( 'Đăng ký ngay', 'elementor-pro' ),
            ]
        );
       $this->add_control(
           'link',
           [
            'label' => __( 'Link', 'elementor-pro' ),
            'type' => Controls_Manager::URL,
            'placeholder' => __( 'https://your-link.com', 'elementor-pro' ),
           ]
       );

        $this->add_control(
            'size',
            [
                'label' => __( 'Size', 'elementor' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'default',
                'options' => [
                    'default' => __( 'Default', 'elementor' ),
                    'small' => __( 'Small', 'elementor' ),
                    'medium' => __( 'Medium', 'elementor' ),
                    'large' => __( 'Large', 'elementor' ),
                    'xl' => __( 'XL', 'elementor' ),
                    'xxl' => __( 'XXL', 'elementor' ),
                ],
            ]
        );

        $this->add_control(
            'header_size',
            [
                'label' => __( 'HTML Tag', 'elementor' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => 'H1',
                    'h2' => 'H2',
                    'h3' => 'H3',
                    'h4' => 'H4',
                    'h5' => 'H5',
                    'h6' => 'H6',
                    'div' => 'div',
                    'span' => 'span',
                    'p' => 'p',
                ],
                'default' => 'h4',
            ]
        );

        $this->add_responsive_control(
            'align',
            [
                'label' => __( 'Alignment', 'elementor' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title1' => __( 'Left', 'elementor' ),
                        'icon' => 'eicon-text-align-left',
                        'title2' => __( 'Left', 'elementor' ),
                        'icon' => 'eicon-text-align-left',
                        'title3' => __( 'Left', 'elementor' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title1' => __( 'Center', 'elementor' ),
                        'icon' => 'eicon-text-align-center',
                        'title2' => __( 'Center', 'elementor' ),
                        'icon' => 'eicon-text-align-center',
                        'title3' => __( 'Center', 'elementor' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title1' => __( 'Right', 'elementor' ),
                        'icon' => 'eicon-text-align-right',
                        'title2' => __( 'Right', 'elementor' ),
                        'icon' => 'eicon-text-align-right',
                        'title3' => __( 'Right', 'elementor' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                    'justify' => [
                        'title' => __( 'Justified', 'elementor' ),
                        'icon' => 'eicon-text-align-justify',
                        'title2' => __( 'Justified', 'elementor' ),
                        'icon' => 'eicon-text-align-justify',
                        'title3' => __( 'Justified', 'elementor' ),
                        'icon' => 'eicon-text-align-justify',
                    ],
                ],
                'default' => 'left',
                'selectors' => [
                    '{{WRAPPER}}' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'view',
            [
                'label' => __( 'View', 'elementor' ),
                'type' => Controls_Manager::HIDDEN,
                'default' => 'traditional',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'section_title_style',
            [
                'label' => __( 'Title', 'elementor' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __( 'Text Color', 'elementor' ),
                'type' => Controls_Manager::COLOR,
                'global' => [
                    'default' => Global_Colors::COLOR_PRIMARY,
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-heading-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'typography',
                'global' => [
                    'default' => Global_Typography::TYPOGRAPHY_PRIMARY,
                ],
                'selector' => '{{WRAPPER}} .elementor-heading-title',
            ]
        );

        $this->add_group_control(
            Group_Control_Text_Shadow::get_type(),
            [
                'name' => 'text_shadow',
                'selector' => '{{WRAPPER}} .elementor-heading-title',
            ]
        );

        $this->add_control(
            'blend_mode',
            [
                'label' => __( 'Blend Mode', 'elementor' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '' => __( 'Normal', 'elementor' ),
                    'multiply' => 'Multiply',
                    'screen' => 'Screen',
                    'overlay' => 'Overlay',
                    'darken' => 'Darken',
                    'lighten' => 'Lighten',
                    'color-dodge' => 'Color Dodge',
                    'saturation' => 'Saturation',
                    'color' => 'Color',
                    'difference' => 'Difference',
                    'exclusion' => 'Exclusion',
                    'hue' => 'Hue',
                    'luminosity' => 'Luminosity',
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-heading-title' => 'mix-blend-mode: {{VALUE}}',
                ],
                'separator' => 'none',
            ]
        );

        $this->end_controls_section();
    }

    /**
     * Render heading widget output on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        if ( '' === $settings['title1'] ||'' === $settings['title2'] ||'' === $settings['title3']) {
            return;
        }
        $this->add_render_attribute( 'title1', 'class', 'title1 '.$settings['style'].'' );
        $this->add_render_attribute( 'title2', 'class', 'title2 '.$settings['style'].'' );
        $this->add_render_attribute( 'title3', 'class', 'title3 '.$settings['style'].'' );


        if ( ! empty( $settings['size'] ) ) {
            $this->add_render_attribute( 'title1', 'class', 'elementor-size-' . $settings['size'] );
            $this->add_render_attribute( 'title2', 'class', 'elementor-size-' . $settings['size'] );
            $this->add_render_attribute( 'title3', 'class', 'elementor-size-' . $settings['size'] );
        }

        $this->add_inline_editing_attributes( 'title1' );
        $this->add_inline_editing_attributes( 'title2' );
        $this->add_inline_editing_attributes( 'title3' );

        $title1 = $settings['title1'];
        $title2 = $settings['title2'];
        $title3 = $settings['title3'];

        $title_class = $this->get_render_attribute_string( 'title' );
        $title_html1 = sprintf( '<%1$s %2$s>%3$s</%1$s>', Utils::validate_html_tag( $settings['header_size1'] ), $title_class, $title1 );
        $title_html2 = sprintf( '<%1$s %2$s>%3$s</%1$s>', Utils::validate_html_tag( $settings['header_size2'] ), $title_class, $title2 );
        $title_html3 = sprintf( '<%1$s %2$s>%3$s</%1$s>', Utils::validate_html_tag( $settings['header_size3'] ), $title_class, $title3 );

        if($settings['image']) {
           // $image_html = '<div class="image-wrap">'.wp_get_attachment_image($settings['image']['id'],array(114,114),false,array()).'</div>';
        }
        $header_html = '<div class="container">'.$title_html1.''.$title_html2.''.$title_html3;
        $des_html = '';
        // echo '<div class="appstore-box wow fadeInUp" style="background: '.$settings["bg_color"].';">
        echo '<div class="industry-banner text-center contact-banner page-banner" style="background-image: url('.$settings["bg_image"]['url'].');" >
                '.$header_html.'
                <a href="tel:'.$settings["title2"].'" class="btn btn-outline-gray btn-contact-now">'.$settings["button_text"].'</a>';
        echo '</div></div>';
    }

    /**.$settings['image']['url'].
     * Render heading widget output in the editor.
     *
     * Written as a Backbone JavaScript template and used to generate the live preview.
     *
     * @since 2.9.0
     * @access protected
     */
    protected function content_template() {
        ?>
        <#
        var title1 = settings.title1;
        var title2 = settings.title2;
        var title3 = settings.title3;

        view.addRenderAttribute( 'title1', 'class', [ 'title1 '+settings.style, 'elementor-size-' + settings.size ] );
        view.addRenderAttribute( 'title2', 'class', [ 'title2 '+settings.style, 'elementor-size-' + settings.size ] );
        view.addRenderAttribute( 'title3', 'class', [ 'title3 '+settings.style, 'elementor-size-' + settings.size ] );
        view.addInlineEditingAttributes( 'title1' );
        view.addInlineEditingAttributes( 'title2' );
        view.addInlineEditingAttributes( 'title3' );

        var headerSizeTag1 = elementor.helpers.validateHTMLTag( settings.header_size1 );
        var headerSizeTag2 = elementor.helpers.validateHTMLTag( settings.header_size2 );
        var headerSizeTag3 = elementor.helpers.validateHTMLTag( settings.header_size3 );
        title_html1 = '<' + headerSizeTag1  + ' ' + view.getRenderAttributeString( 'title1' ) + '>' + title1 + '</' + headerSizeTag1 + '>';
        title_html2 = '<' + headerSizeTag2  + ' ' + view.getRenderAttributeString( 'title2' ) + '>' + title2 + '</' + headerSizeTag2 + '>';
        title_html3 = '<' + headerSizeTag3  + ' ' + view.getRenderAttributeString( 'title3' ) + '>' + title3 + '</' + headerSizeTag3 + '>';
        console.log(settings.bg_image);
        var image_html = '';
        #>
        <div class="industry-banner text-center contact-banner page-banner" style="background-image: url({{settings.bg_image.url}});">
            <div class="container">
                {{{title_html1 + title_html2 + title_html3}}}
                <a href="tel:'{{settings.title2}}" class="btn btn-outline-gray btn-contact-now">{{{settings.button_text}}}</a>';
            </div>
            </div>
        </div>
        <?php
    }
}
?>