<?php
/**
 * Created by PhpStorm.
 * User: toanngo92
 * Date: 2/11/2019
 * Time: 2:39 PM
 */

if (!class_exists('Tech888f_Metabox_Product_Controller')) {
    class Tech888f_Metabox_Product_Controller
    {

        static function _init()
        {
            if (function_exists('tech888f_reg_metabox')) {
                //add_action( 'admin_menu' , 'remove_post_metabox_fields' );
                add_filter( 'rwmb_meta_boxes', 'tech888f_register_product_meta_boxes' );
            }
        }

//        static function _add_meta_box()
//        {
//            $id = 'tech888f_product_metabox';
//            $title = esc_html__('Tech888 Product Customize Settings', 'posolo');
//            //   $screen = 'post';
//            $context = 'normal';
//            $callback_args = null;
//            tech888f_reg_metabox($id, $title, 'output_metabox_product_backend', null, $context, null, $callback_args);
//        }

    }

    Tech888f_Metabox_Product_Controller::_init();

}


if(!function_exists('tech888f_register_product_meta_boxes')){
    function tech888f_register_product_meta_boxes( $meta_boxes ) {

        $meta_boxes[] = array (
            'title' => 'Product Settings',
            'id' => 'product-settings',
            'post_types' => array(
                0 => 'product',
            ),
            'context' => 'normal',
            'priority' => 'low',
            'fields' => array(
                array (
                    'id' => 'product_sidebar_pos',
                    'name' => 'Post select Template',
                    'label'       => esc_html__( 'select sidebar', 'posolo' ),
                    'type' => 'select',
                    'desc' => 'select option sidebar',
                    'placeholder' => 'Select an Item',
                    'options'     => array(
                        'no' => esc_html__('No Sidebar','posolo'),
                        'left' => esc_html__('Left Sidebar','posolo'),
                        'right' => esc_html__('Right Sidebar','posolo'),
                    ),
                ),
                array(
                    'id' => 'product_sidebar_spec',
                    'name' => 'product Sidebar Item',
                    'type' => 'sidebar',
                    'field_type'  => 'select_advanced',
                    'placeholder' => 'Select a sidebar',
                    'desc' => 'Choose your Post Sidebar',
                    'placeholder' => 'Select an Item',
                    'hidden' => array( 'product_sidebar_pos', '=', 'no' )
                ),
                array(
                    'id'          => 'product_tab_detail',
                    'name'        => 'Product tab style',
                    'label'       => esc_html__('Product tab style','posolo'),
                    'type'        => 'select',
                    'desc'        => 'Choose your style product',
                    'options'     => array(
                        'tab-normal' => esc_html__("Normal", 'posolo'),
                        'tab-style2' => esc_html__("Tab style 2", 'posolo'),
                    )
                ),
                array(
                    'id'          => 'product_related_itemres',
                    'name'        => 'related style',
                    'label'       => esc_html__('Product related format responsive','posolo'),
                    'type'        => 'text',
                ),
                array(
                    'id'          => 'product_latest_itemres',
                    'name'        => 'latest style',
                    'label'       => esc_html__('Product latest format responsive','posolo'),
                    'type'        => 'text',
                )
            ),
        );
        return $meta_boxes;
    }
}