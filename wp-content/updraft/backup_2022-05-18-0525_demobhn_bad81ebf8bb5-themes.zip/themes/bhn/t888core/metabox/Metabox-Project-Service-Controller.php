<?php
/**
 * Created by PhpStorm.
 * User: toanngo92
 * Date: 2/11/2019
 * Time: 2:39 PM
 */

if (!class_exists('Tech888f_Metabox_Project_Service_Controller')) {
    class Tech888f_Metabox_Project_Service_Controller
    {

        static function _init()
        {
            if (function_exists('tech888f_reg_metabox')) {
                add_filter( 'rwmb_meta_boxes', 'tech888f_register_service_project_meta_boxes' );
            }
        }

//        static function _add_meta_box()
//        {
//            $id = 'tech888f_service_project_metabox';
//            $title = esc_html__('Tech888 Project Service Customize Settings', 'posolo');
//            $screen = null;
//            $context = 'normal';
//            $callback_args = null;
//            tech888f_reg_metabox($id, $title, 'output_metabox_service_project_backend', $screen, $context, null, $callback_args);
//        }

    }

    Tech888f_Metabox_Project_Service_Controller::_init();

}


if(!function_exists('tech888f_register_service_project_meta_boxes')){
    function tech888f_register_service_project_meta_boxes( $meta_boxes ) {
        $meta_boxes[] = array (
            'title' => 'Project Service Field',
            'id' => 'project-service-field',
            'taxonomies' => array(
                0 => 'project-service',
            ),
            'fields' => array(
                array (
                    'id' => 'project_service_image_list',
                    'type' => 'image_advanced',
                    'name' => 'Project Service Slider Image',
                    'max_file_uploads' => 4,
                    'image_size' => 'thumbnail',
                ),
                array (
                    'id' => 'project_service_tab_list',
                    'type' => 'group',
                    'name' => 'Service Tab List',
                    'fields' => array(
                        array (
                            'id' => 'project_service_tab_title',
                            'type' => 'text',
                            'name' => 'Project Service Tab Title',
                        ),
                        array (
                            'id' => 'project_service_tab_content',
                            'name' => 'Project Service Tab Content',
                            'type' => 'wysiwyg',
                        ),
                    ),
                    'clone' => 1,
                    'default_state' => 'collapsed',
                    'max_clone' => 3,
                    'collapsible' => true,
                    'save_state' => true,
                ),
            ),
        );
        return $meta_boxes;
    }
}