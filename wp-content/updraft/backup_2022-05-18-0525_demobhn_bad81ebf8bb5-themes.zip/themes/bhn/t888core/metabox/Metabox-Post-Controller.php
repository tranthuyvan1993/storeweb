<?php
/**
 * Created by PhpStorm.
 * User: toanngo92
 * Date: 2/11/2019
 * Time: 2:39 PM
 */

if (!class_exists('Tech888f_Metabox_Post_Controller')) {
    class Tech888f_Metabox_Post_Controller
    {

        static function _init()
        {
            if (function_exists('tech888f_reg_metabox')) {
                add_filter( 'rwmb_meta_boxes', 'tech888f_register_post_meta_boxes' );
            }
        }

//        static function _add_meta_box()
//        {
//            $id = 'tech888f_post_metabox';
//            $title = esc_html__('Tech888 Post Customize Settings', 'posolo');
//            $screen = 'post';
//            $context = 'normal';
//            $callback_args = null;
//            tech888f_reg_metabox($id, $title, 'output_metabox_post_backend', $screen, $context, null, $callback_args);
//        }

    }

    Tech888f_Metabox_Post_Controller::_init();

}


if(!function_exists('tech888f_register_post_meta_boxes')){
    function tech888f_register_post_meta_boxes( $meta_boxes ) {
        $meta_boxes[] = array (
            'title' => 'Post Settings',
            'id' => 'post-settings',
            'post_types' => array(
                0 => 'post',
            ),
            'context' => 'normal',
            'priority' => 'low',
            'fields' => array(
                array (
                    'id' => 'mtb_post_detail_gallery',
                    'name' => 'Post Detail Gallery (For Gallery Post Format)',
                    'type' => 'image_advanced',
                    'max_status' => false,
                    'image_size' => 'thumbnail'
                ),
                array (
                    'id' => 'post_sidebar_position',
                    'name' => 'Post Sidebar Position',
                    'type' => 'select',
                    'placeholder' => 'Select an Item',
                    'options'     => array(
                        'no' => esc_html__('No Sidebar','posolo'),
                        'left' => esc_html__('Left Sidebar','posolo'),
                        'right' => esc_html__('Right Sidebar','posolo'),
                    ),
                ),
                array (
                    'id' => 'post_sidebar_item',
                    'type' => 'sidebar',
                    'name' => 'Post Sidebar Item',
                    'field_type' => 'select_advanced',
                    'desc' => 'Choose your Post Sidebar',
                    'placeholder' => 'Select an Item',
                    'hidden' => array( 'post_sidebar_position', '=', 'no' )
                ),
                array (
                    'id' => 'post_related_format',
                    'label'       => esc_html__('Post related format responsive','posolo'),
                    'type' => 'text',
                    'name' => esc_html('Related Format','posolo'),
                ),
                array (
                    'id' => 'mtb_post_content_media',
                    'name' => 'Post Media Url',
                    'type' => 'text',
                ),
            ),
        );
        return $meta_boxes;
    }
}