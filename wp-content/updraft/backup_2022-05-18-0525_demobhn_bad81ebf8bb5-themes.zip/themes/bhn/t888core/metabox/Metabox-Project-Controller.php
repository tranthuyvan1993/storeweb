<?php
/**
 * Created by PhpStorm.
 * User: toanngo92
 * Date: 2/11/2019
 * Time: 2:39 PM
 */

if (!class_exists('Tech888f_Metabox_Project_Controller')) {
    class Tech888f_Metabox_Project_Controller
    {

        static function _init()
        {
            if (function_exists('tech888f_reg_metabox')) {
                add_filter( 'rwmb_meta_boxes', 'tech888f_register_project_meta_boxes' );
            }
        }

//        static function _add_meta_box()
//        {
//            $id = 'tech888f_project_metabox';
//            $title = esc_html__('Tech888 Project Customize Settings', 'posolo');
//            $screen = 'project';
//            $context = 'normal';
//            $callback_args = null;
//            tech888f_reg_metabox($id, $title, 'output_metabox_project_backend', $screen, $context, null, $callback_args);
//        }

    }

    Tech888f_Metabox_Project_Controller::_init();

}


if(!function_exists('tech888f_register_project_meta_boxes')){
    function tech888f_register_project_meta_boxes( $meta_boxes ) {
        $meta_boxes[] = array (
            'title' => 'Project Information',
            'id' => 'project_info_metabox',
            'post_types' => array(
                0 => 'project',
            ),
            'context' => 'normal',
            'priority' => 'high',
            'fields' => array(
                array (
                    'id' => 'project_scope_mtb',
                    'type' => 'text',
                    'name' => esc_html__('Scope','posolo'),
                ),
                array (
                    'id' => 'project_location_mtb',
                    'type' => 'text',
                    'name' => esc_html__('Location','posolo'),
                ),
                array (
                    'id' => 'project_client_mtb',
                    'type' => 'text',
                    'name' => esc_html__('Client','posolo'),
                ),
                array (
                    'id' => 'project_architect_mtb',
                    'type' => 'text',
                    'name' => esc_html__('Architect','posolo'),
                ),
                array (
                    'id' => 'project_photography_mtb',
                    'type' => 'text',
                    'name' => esc_html__("Designer","posolo"),
                ),
                array (
                    'id' => 'project_image_lst_mtb',
                    'type' => 'image_advanced',
                    'name' => esc_html__("Project Gallery","posolo"),
                    'max_status' => false,
                    'image_size' => 'thumbnail',
                ),
            ),
        );
        return $meta_boxes;
    }
}