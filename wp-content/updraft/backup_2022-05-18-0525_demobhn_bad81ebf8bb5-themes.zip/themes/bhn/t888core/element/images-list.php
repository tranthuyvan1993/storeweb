<?php
/**
 * Created by Sublime text 2.
 * User: thanhhiep992
 * Date: 26/10/17
 * Time: 10:00 AM
 */
if(!function_exists('tech888f_vc_payment'))
{
    function tech888f_vc_payment($attr, $content = false)
    {
        $html = $icon_html = '';
        $data_array = array_merge(array(
            'style'         => 'image-list-default',
            'title'         => '',
            'des'           => '',
            'list'          => '',
            'itemres'       => '',
            'speed'         => '',
            'size'          => '',
            'el_class'      => '',
            'custom_css'    => '',
            'content'       => $content,
        ),tech888f_get_responsive_default_atts());
        $attr = shortcode_atts($data_array,$attr);
        extract($attr);
        $css_classes = vc_shortcode_custom_css_class( $custom_css );
        $css_class = preg_replace( '/\s+/', ' ', apply_filters( 'vc_shortcodes_css_class', $css_classes, '', $attr ) );

        $size = tech888f_get_size_crop($size,'full');

        // Variable process vc_shortcodes_css_class
        if(!empty($css_class)) $el_class .= ' '.$css_class;
        $el_class .= ' '.$style;
        
        $data = (array) vc_param_group_parse_atts( $list );
        $default_val = array(
            'image'     => '',
            'icon'      => '',
            'title'     => '',
            'des'       => '',
            'link'      => '',
            'pos'       => '',
            );

        // Add variable to data
        $attr = array_merge($attr,array(
            'el_class'      => $el_class,
            'data'          => $data,
            'default_val'   => $default_val,
            'size'          => $size,
            ));

        // Call function get template
        $html = tech888f_get_template_element('images-list/list',$style,$attr);

        return  $html;
    }
}

stp_reg_shortcode('sv_payment','tech888f_vc_payment');


vc_map( array(
    "name"          => esc_html__("Images list", 'posolo'),
    "base"          => "sv_payment",
    "icon"          => "icon-st",
    "category"      => esc_html__("T888-Elements", 'posolo'),
    "description"   => esc_html__( 'Display list images ', 'posolo' ),
    "params"        => array(
        array(
            "type"          => "dropdown",
            "admin_label"   => true,
            "heading"       => esc_html__("Style",'posolo'),
            "param_name"    => "style",
            "value"         => array(
                esc_html__("Default",'posolo')    => 'brand-slider',
                esc_html__("style 2 - List logo đối tác",'posolo')    => 'style2',
                esc_html__("style 3 - Danh sách kết quả",'posolo')    => 'style3',
                esc_html__("style 4",'posolo')    => 'style4',
                esc_html__("style 5",'posolo')    => 'style5',
                ),
            "description"   => esc_html__( 'Choose a style to display.', 'posolo' )
        ),
        array(
            "type"          => "textfield",
            "admin_label"   => true,
            "heading"       => esc_html__("Title",'posolo'),
            "param_name"    => "title",
            "description"   => esc_html__( 'Enter title of element.', 'posolo' )
        ),
        array(
            "admin_label"   => true,
            "type"          => "textfield",
            "heading"       => esc_html__("Description",'posolo'),
            "param_name"    => "des",
            "description"   => esc_html__( 'Enter description of element.', 'posolo' )
        ),        
        array(
            "type"          => "textfield",
            "heading"       => esc_html__("Image custom size",'posolo'),
            "param_name"    => "size",
            'description'   => esc_html__( 'Enter image size (Example: "thumbnail", "medium", "large", "full" or other sizes defined by theme). Alternatively enter size in pixels (Example: 200x100 (Width x Height)).', 'posolo' ),
        ),
        array(
            'heading'       => esc_html__( 'Custom Item', 'posolo' ),
            'type'          => 'textfield',
            'description'   => esc_html__( 'Enter item for screen width(px) format is width:value and separate values by ",". Example is 0:2,600:3,1000:4. Default is auto.', 'posolo' ),
            'param_name'    => 'itemres',
            'group'         => esc_html__("Slider Settings","posolo"),
            'dependency'    => array(
                'element'       => 'style',
                'value'         => array('brand-slider'),
                )
        ),        
        array(
            'heading'       => esc_html__( 'Speed', 'posolo' ),
            'type'          => 'textfield',
            'group'         => esc_html__("Slider Settings","posolo"),
            'description'   => esc_html__( 'Enter time slider go to next item. Unit (ms). Example 5000. If empty this field autoPlay is false.', 'posolo' ),
            'param_name'    => 'speed',
            'dependency'    => array(
                'element'       => 'style',
                'value'         => array('brand-slider'),
                )
        ),
        array(
            "type"          => "param_group",
            "heading"       => esc_html__("Add Image List",'posolo'),
            "param_name"    => "list",
            "params"        => array(
                array(
                    "type"          => "attach_image",
                    "heading"       => esc_html__("Image",'posolo'),
                    "param_name"    => "image",
                ),
                array(
                    'type'          => 'iconpicker',
                    'heading'       => esc_html__( 'Icon', 'posolo' ),
                    'param_name'    => 'icon',
                    'value'         => '',
                    'settings'      => array(
                        'emptyIcon'     => true,
                        'type'          => tech888f_default_icon_lib(),
                        'iconsPerPage'  => 4000,
                    ),
                    'description'   => esc_html__( 'Select icon from library.', 'posolo' ),
                ),
                array(
                    "type"          => "textfield",
                    "heading"       => esc_html__("Title",'posolo'),
                    "param_name"    => "title",
                ),
                array(
                    "type"          => "textarea",
                    "heading"       => esc_html__("Description",'posolo'),
                    "param_name"    => "des",
                ),
                array(
                    "type"          => "textfield",
                    "heading"       => esc_html__("Position",'posolo'),
                    "param_name"    => "pos",
                    'description'   => esc_html__( 'Only testimonial item', 'posolo' ),
                ),
                array(
                    "type"          => "textfield",
                    "heading"       => esc_html__("Link",'posolo'),
                    "param_name"    => "link",
                ),
            ),
            'description'   => esc_html__( 'Add more image with link', 'posolo' ),
        ),
        array(
            "type"          => "textfield",
            "heading"       => esc_html__("Extra class name",'posolo'),
            "param_name"    => "el_class",
            'group'         => esc_html__('Design Options','posolo'),
            'description'   => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'posolo' )
        ),
        array(
            "type"          => "css_editor",
            "heading"       => esc_html__("CSS box",'posolo'),
            "param_name"    => "custom_css",
            'group'         => esc_html__('Design Options','posolo')
        ),
    )
));