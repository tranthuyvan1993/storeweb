<?php
/**
 * Created by Sublime text 2.
 * User: thanhhiep992
 * Date: 15/12/15
 * Time: 10:00 AM
 */

if(!function_exists('t88f_vc_people_section'))
{
    function t88f_vc_people_section($attr)
    {
        $html = '';
        $data_array = array(
            'el_class'      => '',
            'custom_css'    => '',
            'list' => '',
            'number_item' => '',
            'item_res'   => '',
            'style' =>'',
        );
        $attr = shortcode_atts($data_array,$attr);
        extract($attr);
        $css_classes = vc_shortcode_custom_css_class( $custom_css );
        $css_class = preg_replace( '/\s+/', ' ', apply_filters( 'vc_shortcodes_css_class', $css_classes, '', $attr ) );


        if(!empty($css_class)) $el_class .= ' '.$css_class;
        $el_class .= ' '.$style;

         $data = (array) vc_param_group_parse_atts( $list );
        $default_val = array(
            'icon'      => '',
            'title'     => '',
            'link'      =>'',
            );
          $attr = array_merge($attr,array(
            'el_class'      => $el_class,
            'data'          => $data,
            'default_val'   => $default_val,
        ));
          $html = tech888f_get_template_element('contact-header/contact-header',$style,$attr);
          return $html;

    }
}
stp_reg_shortcode('t88f_people_section','t88f_vc_people_section');

vc_map( array(
    "name"      => esc_html__("Contact Header", 'posolo'),
    "base"      => "t88f_people_section",
    "icon"      => "icon-st",
    "category"  => 'T888-Elements',
    "params"    => array(

        array(
            "type"          => "dropdown",
            "admin_label"   => true,
            "heading"       => esc_html__("Style",'posolo'),
            "param_name"    => "style",
            "value"         => array(
                esc_html__("Default",'posolo')    => '',
                // esc_html__("Style 2 - Slider",'posolo')    => 'style2',
                // esc_html__("Style 3",'posolo')    => 'style3',
            ),
            "description"   => esc_html__( 'Choose a style to display.', 'posolo' ),
        ),
        // array(
        //     'heading'     => esc_html__( 'Number of Items', 'posolo' ),
        //     'type'        => 'textfield',
        //     'description' => esc_html__( 'Enter number of item. Default is 3.', 'posolo' ),
        //     'param_name'  => 'number_item',
        //     'dependency'  => array(
        //         'element' => 'style',
        //         'value'  => 'style2'
        //     )
        // ),
        // array(
        //     'heading'     => esc_html__( 'Responsive format', 'posolo' ),
        //     'type'        => 'textfield',
        //     'description' => esc_html__( 'Enter responsive format - Example: 0:1,600:2,1000:3', 'posolo' ),
        //     'param_name'  => 'item_res',
        //     'dependency'  => array(
        //         'element' => 'style',
        //         'value'  => 'style2'
        //     )
        // ),
        array(
                    "type"          => "param_group",
                    "heading"       => esc_html__("Add People image",'posolo'),
                    "param_name"    => "list",
                    "params"        => array(
                        array(
                            'type'          => 'iconpicker',
                            'heading'       => esc_html__( 'Icon', 'posolo' ),
                            'param_name'    => 'icon',
                            'value'         => '',
                            'settings'      => array(
                                'emptyIcon'     => true,
                                'type'          => tech888f_default_icon_lib(),
                                'iconsPerPage'  => 4000,
                            ),
                            'description'   => esc_html__( 'Select icon from library.', 'posolo' ),
                        ),
                        // array(
                        //     "type"          => "attach_image",
                        //     "heading"       => esc_html__("Image",'posolo'),
                        //     "param_name"    => "image",
                        // ),
                        array(
                            "type"          => "textfield",
                            "heading"       => esc_html__("Title",'posolo'),
                            "param_name"    => "title",
                        ),
                         array(
                            "type"          => "textfield",
                            "heading"       => esc_html__("Url",'posolo'),
                            "param_name"    => "link",
                        ),
                    ),
                    'description'   => esc_html__( 'Add more image with link', 'posolo' ),
                ),
        array(
                    "type"          => "textfield",
                    "heading"       => esc_html__("Extra class name",'posolo'),
                    "param_name"    => "el_class",
                    'group'         => esc_html__('Design Options','posolo'),
                    'description'   => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'posolo' )
                ),
                array(
                    "type"          => "css_editor",
                    "heading"       => esc_html__("CSS box",'posolo'),
                    "param_name"    => "custom_css",
                    'group'         => esc_html__('Design Options','posolo')
                ),

    )
));