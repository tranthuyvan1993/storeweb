<?php
/**
 * Created by PhpStorm.
 * User: toanngo92
 * Date: 4/12/2019
 * Time: 3:00 PM
 */

if(!function_exists('tech888f_vc_mega_list_url'))
{
    function tech888f_vc_mega_list_url($attr)
    {
        $html = '';
        extract(shortcode_atts(array(
            'title'         => '',
            'list'          => '',
            'style'         => '',
        ),$attr));

        switch ($style){
            case "":
                $html .=    '<div class="r3-lst-text-wrap">';
                if(!empty($list)){
                    $data_list  = (array) vc_param_group_parse_atts( $list );
                    $html .=    '<ul class="list-none">';
                    if(is_array($data_list)){
                        foreach ($data_list as $key => $value) {
                                if(!empty($value['link_title'])){
                                    $title = $value['link_title'];
                                }else{
                                    $title = "";
                                }

                                $custom_class ="";
                                if(!empty($value['custom_class'])){
                                    $custom_class = $value['custom_class'];
                                }else{
                                    $custom_class = "";
                                }
                                $html .=    '<li class="flex-wrap flex-wrap-wrap align-items-center '.esc_attr($custom_class).'"><i class="fa fa-caret-right title24 color"></i><span class="title18 gray666">'.esc_html($title).'</span></li>';
                        }
                    }
                    $html .=    '</ul>';
                }
                $html .=    '</div>';
                break;
            case "style2":
                $html .=    '<div class="footer-link-wrap">';
                if(!empty($title)) $html .= '<h2 class="title24 title-ft fontphilo white no-margin text-left">'.esc_html($title).'</h2>';
                if(!empty($list)){
                    $data_list  = (array) vc_param_group_parse_atts( $list );
                    $html .=    '<ul class="list-none text-left">';
                    if(is_array($data_list)){
                        foreach ($data_list as $key => $value) {
                            if(!empty($value['link_value'])){
                                if(!empty($value['link_title'])){
                                    $title = $value['link_title'];
                                }else{
                                    $title = "";
                                }
                                if(!empty($value['link_value'])){
                                    $link = $value['link_value'];
                                }else{
                                    $link = "#";
                                }

                                $custom_class ="";
                                if(!empty($value['custom_class'])){
                                    $custom_class = $value['custom_class'];
                                }else{
                                    $custom_class = "";
                                }
                                $html .=    '<li class="'.esc_attr($custom_class).'"><a class="title15 white hvr-forward" href="'.esc_html($link).'">'.esc_html($title).'</a></li>';
                            }
                        }
                    }
                    $html .=    '</ul>';
                }
                $html .=    '</div>';
                break;
        }


        return $html;
    }
}

stp_reg_shortcode('tech888f_mega_list_url','tech888f_vc_mega_list_url');

vc_map( array(
    "name"      => esc_html__("Mega List Url", 'posolo'),
    "base"      => "tech888f_mega_list_url",
    "icon"      => "icon-st",
    "category"      => esc_html__("T888-Elements", 'posolo'),
    "description"   => esc_html__( 'Display list of page', 'posolo' ),
    "params"    => array(
        array(
            "type" => "textfield",
            "admin_label"   => true,
            "heading" => esc_html__("Title",'posolo'),
            "param_name" => "title",
        ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__("Style",'posolo'),
            "param_name" => "style",
            "value"         => array(
                esc_html__("Default",'posolo')   => '',
                esc_html__("Style 2",'posolo')   => 'style2',
            ),
        ),
        array(
            "type" => "param_group",
            "heading" => esc_html__("Add List Item",'posolo'),
            "param_name" => "list",
            "params"    => array(
                array(
                    "type" => "textfield",
                    "heading" => esc_html__("Title",'posolo'),
                    "param_name" => "link_title",
                ),
                array(
                    "type" => "textfield",
                    "heading" => esc_html__("Link",'posolo'),
                    "param_name" => "link_value",
                    'description'   => esc_html__( 'Enter your link.', 'posolo' ),
                ),
                array(
                    "type" => "textfield",
                    "heading" => esc_html__("Custom class",'posolo'),
                    "param_name" => "custom_class",
                    'description'   => esc_html__( 'Enter element custom class.', 'posolo' ),
                ),
            ),
        ),
    )
));