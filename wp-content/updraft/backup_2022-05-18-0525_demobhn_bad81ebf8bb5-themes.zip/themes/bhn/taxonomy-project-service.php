<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package tech888-core
 */

get_header();

/* get all terms */
$project_types = get_terms(array(
    'taxonomy' => 'project-type',
    'hide_empty' => false,
));
$project_regions = get_terms(array(
    'taxonomy' => 'project-region',
    'hide_empty' => false,
));
$project_services = get_terms(array(
    'taxonomy' => 'project-service',
    'hide_empty' => false,
));

// project service id
$term_id = get_queried_object_id();
$term = get_term($term_id);

//project service custom fields
$project_service_image_list = rwmb_meta('project_service_image_list', array('object_type' => 'term'), $term_id);
$project_service_tab_list = rwmb_meta('project_service_tab_list', array('object_type' => 'term'), $term_id);


?>
<?php do_action('tech888f_before_main_content') ?>
<div class="project-service-images-wrap">
    <div class="banner-slider project-service-image-slider">
        <div class="wrap-item banner-carousel-slider owl-carousel owl-theme" data-item="1" data-speed="5000"
             data-itemres="0:1,480:1"
             data-navigation="" data-pagination="" data-prev="" data-next="" data-margin="" data-stage_padding=""
             data-start_position="" data-loop="" data-animation_out="" data-animation_in="" data-mousewheel="">
            <?php
            if (!empty($project_service_image_list) && is_array($project_service_image_list)) {
                foreach ($project_service_image_list as $key => $value) {
                    ?>
                    <div class="item-slider project-service-slider-item">
                        <div class="banner-thumb">
                            <a href="javascript:void(0)"><img
                                        src="<?php echo wp_get_attachment_image_src((int)(esc_attr($value["ID"])), 'full')[0]; ?>"/></a>
                        </div>
                    </div>
                    <?php
                }
            }
            ?>
        </div>
    </div>
</div>
<div id="main-content" class="main-page-default">
    <div class="container">
        <div class="row">
            <div class="col-sm-12 archive-project-wrap">
                <div class="project-service-name-des row-full">
                    <div class="project-service-name-des-inner clearfix">
                        <?php if (!empty($term->name)) echo '<div class="box-title text-center "> <h2 class="no-margin text-uppercase"><span class="title title25">' . esc_html($term->name) . '</span></h2></div>' ?>
                        <div class="project-service-desc-wrap">
                            <ul class="text-center nav nav-pills">
                                <?php
                                if (!empty($project_service_tab_list) && is_array($project_service_tab_list)) {
                                    foreach ($project_service_tab_list as $key => $value) {
                                        $active = "";
                                        if ($key == 0) {
                                            $class_active = "active";
                                        } else {
                                            $class_active = "";
                                        }
                                        ?>
                                        <li class="<?php echo esc_attr($class_active) ?>">
                                            <a href="#<?php echo 'project_service_tab_title' . esc_attr($key); ?>"
                                               data-toggle="tab"><?php if (!empty($value['project_service_tab_title'])) echo esc_html($value['project_service_tab_title']); ?></a>
                                        </li>

                                        <?php
                                    }
                                } ?>
                            </ul>
                            <div class="tab-content clearfix">
                                <?php
                                if(!empty($project_service_tab_list) && is_array($project_service_tab_list)){
                                foreach ($project_service_tab_list as $key => $value) {
                                    $active = "";
                                    if ($key == 0) {
                                        $class_active = "active";
                                    } else {
                                        $class_active = "";
                                    }

                                    ?>
                                    <div class="tab-pane <?php echo esc_attr($class_active) ?>"
                                         id="<?php echo 'project_service_tab_title' . $key; ?>">
                                        <div class="content-tab-detail"><?php if (!empty($value['project_service_tab_content'])) echo do_shortcode(wpautop($value['project_service_tab_content'])); ?></div>
                                    </div>
                                <?php }
                                }
                                ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-12 related-project">
                <div class="box-title text-center">
                    <h2 class="no-margin"><span
                                class="title title25"><?php echo esc_html__("RELATED PROJECT", "posolo"); ?></span></h2>
                </div>
                <div class="">
                    <?php
                    $style = tech888f_get_option('blog_default_style', 'list');
                    $grid_type = tech888f_get_option('post_grid_type');
                    $item_style = tech888f_get_option('post_grid_item_style');
                    $item_style_list = tech888f_get_option('post_list_item_style');
                    $excerpt = tech888f_get_option('post_grid_excerpt', 80);
                    $blog_style = tech888f_get_option('blog_style');
                    $column = tech888f_get_option('post_grid_column');
                    $size = tech888f_get_option('post_grid_size');
                    $size_list = tech888f_get_option('post_list_size');
                    $number = get_option('posts_per_page');
                    $check_number = tech888f_get_option('blog_number_filter');
                    $check_type = tech888f_get_option('blog_type_filter');
                    if (isset($_GET['number'])) $number = sanitize_text_field($_GET['number']);
                    if (isset($_GET['type'])) $style = sanitize_text_field($_GET['type']);
                    $size = tech888f_get_size_crop($size);
                    $size_list = tech888f_get_size_crop($size_list);
                    $slug = $item_style;
                    if ($style == 'list') $slug = $item_style_list;
                    $attr = array(
                        'style' => $style,
                        'item_style' => $item_style,
                        'excerpt' => $excerpt,
                        'column' => $column,
                        'size' => $size,
                        'size_list' => $size_list,
                        'number' => $number,
                    );
                    $max_page = $GLOBALS['wp_query']->max_num_pages;
                    $paged = (get_query_var('paged')) ? absint(get_query_var('paged')) : 1;
                    $args = array(
                        'post_type' => 'post',
                        'posts_per_page' => $number,
                        'order' => 'DESC',
                        'paged' => $paged,
                    );
                    $curent_query = $GLOBALS['wp_query']->query;
                    if (is_array($curent_query)) $args = array_merge($args, $curent_query);
                    $style = "list";
                    ?>
                    <div class="js-content-wrap project-<?php echo esc_attr($style . '-view ' . $grid_type) ?>">
                        <?php if (have_posts()): ?>
                            <div class="js-content-main list-project-wrap">
                                <div class="list-project-slider wrap-item group-navi smart-slider owl-carousel owl-theme"
                                     data-speed="" data-itemres="0:2,600:3,989:4,1000:5" data-prev="" data-next=""
                                     data-pagination="" data-navigation="" data-item="">
                                    <?php while (have_posts()) :the_post(); ?>

                                        <?php tech888f_get_template_project($style . '/' . $style, $slug, $attr, true); ?>

                                    <?php endwhile; ?>
                                </div>
                            </div>
                        <?php else : ?>

                            <?php echo tech888f_get_template_post('content', 'none'); ?>

                        <?php endif; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php do_action('tech888f_after_main_content') ?>
<?php get_footer(); ?>
