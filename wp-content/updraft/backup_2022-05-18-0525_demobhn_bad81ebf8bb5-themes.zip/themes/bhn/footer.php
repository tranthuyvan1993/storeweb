<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package tech888core
 */

?>
	    <?php echo tech888f_get_template('footer-default');?>
	    <?php // echo tech888f_get_template('scroll-top');?>
	    <?php // echo tech888f_get_template('wishlist-notification');?>
	    <?php // echo tech888f_get_template('tool-panel');?>
	    <?php // tech888f_content_form_popup()?>
    </div>
<?php wp_footer(); ?>
</body>
</html>
