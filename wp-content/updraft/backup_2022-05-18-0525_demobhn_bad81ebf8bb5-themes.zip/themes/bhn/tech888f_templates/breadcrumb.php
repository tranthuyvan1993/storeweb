<?php
if (!isset($breadcrumb)) {
	$breadcrumb = tech888f_get_option('tech888f_show_breadrumb', '1');
}

if (!isset($el_class)) {
	$el_class = '';
}

if ($breadcrumb == '1'):
	$b_class = tech888f_fill_css_background(tech888f_get_option('tech888f_bg_breadcrumb'));
	$step = '';
	?>
		<div class="wrap-bread-crumb news <?php echo esc_attr($el_class) ?>">
			<div class="container">
				<div class="bread-crumb <?php echo esc_attr($b_class) ?>">
					<?php
	if (!tech888f_is_woocommerce_page()) {
		if (function_exists('bcn_display')) {
			bcn_display();
		} else {
			tech888f_breadcrumb($step);
		}

	} else {
		if (function_exists('woocommerce_breadcrumb')) {
			woocommerce_breadcrumb(array(
				'delimiter' => $step,
				'wrap_before' => '',
				'wrap_after' => '',
				'before' => '<span>',
				'after' => '</span>',
			));
		}
	}
	?>
				</div>
			</div>
		</div>
		<?php endif;?>