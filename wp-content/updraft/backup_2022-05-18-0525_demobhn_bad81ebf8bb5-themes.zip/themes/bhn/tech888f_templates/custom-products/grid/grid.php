<?php
if (empty($size)) $size = array(222, 288);
//$size = tech888f_size_random($size);
?>
<div class="list-col-item list-4-item">
    <div class="item-custom-product">
        <div class="item-custom-product-inner">
            <div class="post-thumb">
                <a href="<?php echo esc_url(get_the_permalink()) ?>" class="image-thumb display-block hvr-glow">
                    <?php echo get_the_post_thumbnail(get_the_ID(), $size); ?>
                </a>
            </div>
            <div class="post-info">
                <h3 class="no-margin text-uppercase title18 post-title font-bold color text-center"><a class="color2" href="<?php echo esc_url(get_the_permalink()) ?>"><?php the_title() ?></a></h3>
            </div>
        </div>
    </div>
</div>