<?php
tech888f_set_post_view();
$thumb_class = 'col-md-6 col-sm-12 col-xs-12';
$info_class = 'col-md-6 col-sm-12 col-xs-12';
$zoom_style = tech888f_get_option('product_image_zoom');
global $product;
$thumb_id = array(get_post_thumbnail_id());
$attachment_ids = $product->get_gallery_image_ids();
$attachment_ids = array_merge($thumb_id,$attachment_ids);
$gallerys = ''; $i = 1;
foreach ( $attachment_ids as $attachment_id ) {
    $image_link = wp_get_attachment_url( $attachment_id );
    if($i == 1) $gallerys .= $image_link;
    else $gallerys .= ','.$image_link;
    $i++;
}
$product_schedule = get_post_meta( get_the_ID(), '_sale_price_dates_to', true);
if (!empty($product_schedule)) $date_sales =  date('Y/m/d', $product_schedule);

$today = date("Y-m-d");

$days = 0;

if(!empty($date_sales) && !empty($today)){
    if(strtotime($date_sales) > strtotime($today)){
        $days = (strtotime($date_sales) - strtotime($today)) / (60 * 60 * 24);
    }
}



$pos_style = tech888f_get_value_by_id('product_tab_detail');
if($pos_style=='tab-style2'){
    ?>
    <div class="product-detail">
        <div class="row">
            <div class="<?php echo esc_attr($info_class)?>">
                <div class="summary entry-summary detail-info">
                    <h2 class="product-title title24"><?php the_title()?></h2>
                    <?php
                    if($days > 0){
                        echo '<div class="detail-countdown-wrap" data-txtd="Days" data-txth="Hours" data-txtm="Mins" data-txts="Secs">';
                        echo '<div class="detail-sale-countdown countdown transition" data-date="'.esc_attr($date_sales).' 00:00:00"></div>';
                        echo '</div>';
                    }
                    ?>
                    <?php
                    do_action( 'woocommerce_single_product_summary' );
                    ?>
                </div>
            </div>
            <div class="<?php echo esc_attr($thumb_class)?>">
                <div class="detail-gallery">
                    <div class="wrap-detail-gallery images <?php echo esc_attr($zoom_style)?>">
                        <div class="mid woocommerce-product-gallery__image image-lightbox" data-number="0" data-fancybox="gallery" data-gallery="<?php echo esc_attr($gallerys)?>">
                            <?php
                            $html = get_the_post_thumbnail(get_the_ID(),'shop_single',array('class'=> 'wp-post-image'));
                            echo apply_filters( 'woocommerce_single_product_image_thumbnail_html', $html, get_post_thumbnail_id( get_the_ID() ) );
                            ?>
                        </div>
                        <?php
                        if ( $attachment_ids && has_post_thumbnail() && count($attachment_ids) > 1) {
                            ?>
                            <div class="item-gallery">
                                <div class="gallery-control images-item smart-slider owl-carousel owl-theme owl-loaded owl-drag" data-item="4" data-speed="" data-itemres="" data-prev="" data-next="" data-pagination="" data-navigation="">
                                    <?php
                                    $i = 1;
                                    foreach ( $attachment_ids as $attachment_id ) {
                                        if($i == 1) $active = 'active';
                                        else $active = '';
                                        $attributes      = array(
                                            'data-src'      => wp_get_attachment_image_url( $attachment_id, 'woocommerce_single' ),
                                            'data-srcset'   => wp_get_attachment_image_srcset( $attachment_id, 'woocommerce_single' ),
                                            'data-srcfull'  => wp_get_attachment_image_url( $attachment_id, 'full' ),
                                        );
                                        $html = wp_get_attachment_image($attachment_id,'shop_thumbnail',false,$attributes );
                                        echo   '<div data-number="'.esc_attr($i).'">
                                        <a title="'.esc_attr( get_the_title( $attachment_id ) ).'" class="'.esc_attr($active).'" href="#">
                                            '.apply_filters( 'woocommerce_single_product_image_thumbnail_html',$html,$attachment_id).'
                                        </a>
                                    </div>';
                                        $i++;
                                    }
                                    ?>
                                </div>
                            </div>
                            <?php
                            do_action( 'woocommerce_product_thumbnails' );
                        }
                        ?>
                    </div>
                    <?php tech888f_get_template( 'share','',false,true );?>
                </div>
            </div>
        </div>
    </div>
    <?php
}
else{
    ?>
    <div class="product-detail">
        <div class="row">
            <div class="<?php echo esc_attr($thumb_class)?>">
                <div class="detail-gallery">
                    <div class="wrap-detail-gallery images <?php echo esc_attr($zoom_style)?>">
                        <div class="mid woocommerce-product-gallery__image image-lightbox" data-number="0" data-fancybox="gallery" data-gallery="<?php echo esc_attr($gallerys)?>">
                            <?php
                            $html = get_the_post_thumbnail(get_the_ID(),'shop_single',array('class'=> 'wp-post-image'));
                            echo apply_filters( 'woocommerce_single_product_image_thumbnail_html', $html, get_post_thumbnail_id( get_the_ID() ) );
                            ?>
                        </div>
                        <?php
                        if ( $attachment_ids && has_post_thumbnail() && count($attachment_ids) > 1) {
                            ?>
                            <div class="item-gallery">
                                <div class="gallery-control images-item smart-slider owl-carousel owl-theme owl-loaded owl-drag" data-item="4" data-speed="" data-itemres="0:3,800:4" data-prev="" data-next="" data-pagination="" data-navigation="">
                                    <?php
                                    $i = 1;
                                    foreach ( $attachment_ids as $attachment_id ) {
                                        if($i == 1) $active = 'active';
                                        else $active = '';
                                        $attributes      = array(
                                            'data-src'      => wp_get_attachment_image_url( $attachment_id, 'woocommerce_single' ),
                                            'data-srcset'   => wp_get_attachment_image_srcset( $attachment_id, 'woocommerce_single' ),
                                            'data-srcfull'  => wp_get_attachment_image_url( $attachment_id, 'full' ),
                                        );
                                        $html = wp_get_attachment_image($attachment_id,'shop_thumbnail',false,$attributes );
                                        echo   '<div data-number="'.esc_attr($i).'">
                                        <a title="'.esc_attr( get_the_title( $attachment_id ) ).'" class="'.esc_attr($active).'" href="#">
                                            '.apply_filters( 'woocommerce_single_product_image_thumbnail_html',$html,$attachment_id).'
                                        </a>
                                    </div>';
                                        $i++;
                                    }
                                    ?>
                                </div>
                            </div>
                            <?php
                            do_action( 'woocommerce_product_thumbnails' );
                        }
                        ?>
                    </div>
                    <?php tech888f_get_template( 'share','',false,true );?>
                </div>
            </div>
            <div class="<?php echo esc_attr($info_class)?>">
                <div class="summary entry-summary detail-info">
                    <h2 class="product-title title24"><?php the_title()?></h2>
                    <?php
                    if($days > 0){
                        echo '<div class="detail-countdown-wrap" data-txtd="Days" data-txth="Hours" data-txtm="Mins" data-txts="Secs">';
                        echo '<div class="detail-sale-countdown countdown transition" data-date="'.esc_attr($date_sales).' 00:00:00"></div>';
                        echo '</div>';
                    }
                    ?>
                    <?php
                    do_action( 'woocommerce_single_product_summary' );
                    ?>
                </div>
            </div>
        </div>
    </div>
<?php
}
?>
