<?php
if(empty($size)) $size = array(350,200);
$size = tech888f_size_random($size);
$post_date = get_the_date( 'F j, Y' );
?>
<?php if(isset($column)):?><div class="list-col-item list-<?php echo esc_attr($column)?>-item"><?php endif;?>
<div class="item-post item-gallery-default grid-item-default">
    <div class="post-thumb banner-advs zoom-image overlay-image">
        <a href="<?php echo get_the_post_thumbnail_url(get_the_ID()) ?>" data-fancybox="library-fancy" class="adv-thumb-link">
            <?php echo get_the_post_thumbnail(get_the_ID(),$size);?>
        </a>
        <div class="date-wrap pst-absolute">
            <?php echo get_the_date( 'j F, Y' ); ?>
        </div>
    </div>
</div>
<?php if(isset($column)):?></div><?php endif;?>