<?php
if(empty($item)) $item = '6';
if(empty($itemres)) $itemres = '0:1,320:2,990:3,1439:4';
if(empty($speed)) $speed = '3000';
?>
<div class="images-slider <?php echo esc_attr($el_class);?>">
    <?php
    if(!empty($title)) echo '<h3 class="block-title">'.esc_html($title).'</h3>';
    if(!empty($des)) echo '<p class="desc">'.esc_html($des).'</p>';
    ?>
    <div class="wrap-item smart-slider owl-carousel owl-theme navi-nav-style"
         data-item="" data-speed="<?php echo esc_attr($speed);?>"
         data-itemres="<?php echo esc_attr($itemres)?>"
         data-prev='' data-next=''
         data-pagination="true" data-navigation="">
        <?php
        if(is_array($data)){
            foreach ($data as $key => $value) {
                $value = array_merge($default_val,$value);
                $attr_item = array(
                    'title' => $value['title'],
                    'alt' => $value['des'],
                );
                $size = array(800,600);
                ?>
                <div class="item-image-list">
                    <div class="banner-advs text-center">
                        <div class="img-outer">
                            <?php if(!empty($value['link'])):?>
                            <a href="<?php echo esc_url($value['link']);?>" title="<?php echo esc_attr($value['title']);?>" class="adv-thumb-link round img-wrap">
                                <?php endif;?>
                                <?php echo wp_get_attachment_image($value['image'],$size,false,$attr_item);?>
                                <?php if(!empty($value['link'])):?>
                            </a>
                        <?php endif;?>
                        </div>
                    </div>
                    <div class="item-image-info text-center">
                        <h3 class="item-image-title no-margin title20 fontphilo"><?php if(!empty($value["title"])) echo esc_html($value["title"]) ?></h3>
                        <p class="desc"><?php if(!empty($value["des"])) echo $value["des"] ?></p>
                        <div class="btn-single-wrap btn-single-style2 flex-wrap flex-wrap-wrap jtf-content-center">
                            <a class="display-block text-uppercase font-bold title13 text-center" href="#" >Đăng ký học thử miễn phí</a>
                        </div>
                    </div>
                </div>
            <?php }
        }?>
    </div>
</div>