<?php
if(empty($itemres)) $itemres = '0:1,767:2,840:3';
?>
<div class="images-slider <?php echo esc_attr($el_class);?>">
    <?php
    if(!empty($title)) echo '<h3 class="block-title">'.esc_html($title).'</h3>';
    if(!empty($des)) echo '<p class="desc">'.esc_html($des).'</p>';
    ?>
    <div class="wrap-item smart-slider owl-carousel owl-theme navi-nav-style"
         data-item="" data-speed="<?php echo esc_attr($speed);?>"
         data-itemres="<?php echo esc_attr($itemres)?>"
         data-prev='' data-next=''
         data-pagination="" data-navigation="">
        <?php
        if(is_array($data)){
            foreach ($data as $key => $value) {
                $value = array_merge($default_val,$value);
                $attr_item = array(
                    'title' => $value['title'],
                    'alt' => $value['des'],
                );
                if(empty($size)) $size = "full";
                ?>
                <div class="item-image-list">
                    <div class="item-image-info text-center">
                        <div class="title-icon-wrap flex-wrap jtf-content-center align-items-center flex-wrap-wrap">
                            <i class="<?php echo esc_attr($value["icon"]) ?> title36 color"></i>
                            <h3 class="item-image-title no-margin title36 fontphilo"><?php if(!empty($value["title"])) echo esc_html($value["title"]) ?></h3>
                        </div>
                        <p class="desc title18"><?php if(!empty($value["des"])) echo $value["des"] ?></p>
                    </div>
                </div>
            <?php }
        }?>
    </div>
</div>