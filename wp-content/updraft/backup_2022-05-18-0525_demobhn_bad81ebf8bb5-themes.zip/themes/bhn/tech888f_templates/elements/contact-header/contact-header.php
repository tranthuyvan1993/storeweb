<?php

if(empty($size)){
    $size= array(180,232);
}

?>

<div class="header-contact">
    <?php foreach ($data as $key => $value) {
        $par_cate_url = '#';

        if (!empty($value['link'])) {
            $par_cate_url = $value['link'];
        }
        if(!empty($value['image'])){
            $img_attr = wp_get_attachment_image_src($value["image"],$size, false);
        }
        ?>
        <div class="item" >
            <a class="name-people" href="<?php if (!empty($par_cate_url)) echo esc_url($par_cate_url); ?>">
            <?php if (!empty($value["name"])) echo esc_html($value['name']) ?></a>
        </div>
        <?php
    } ?>
</div>