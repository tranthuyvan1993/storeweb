<?php
/**
 * Created by PhpStorm.
 * User: dell3537
 * Date: 12/18/2019
 * Time: 11:32 PM
 */

if (empty($size)){
    $size = "full";
}
else{
    $size  = explode("x",$size);
}
?>
<div class="single-image-wrap style4 overflow-hidden hvr-float pst-relative <?php echo esc_attr($el_class) ?>">
        <?php
        if (!empty($url)) echo '<a class="" href="' . esc_url($url) . '">';
        if (!empty($image)) echo wp_get_attachment_image($image, $size, false, '');
        if (!empty($url)) echo "</a>";
        ?>
</div>
