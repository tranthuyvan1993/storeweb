<nav class="main-nav flex-wrap flex-wrap-wrap jtf-content-center <?php echo esc_attr($el_class);?>">
    <?php wp_nav_menu($menu_data);?>
	<a href="#" class="toggle-mobile-menu"><span></span></a>
</nav>