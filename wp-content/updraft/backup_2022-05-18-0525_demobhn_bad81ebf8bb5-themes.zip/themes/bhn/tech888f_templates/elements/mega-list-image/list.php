<?php
/**
 * Created by PhpStorm.
 * User: dell3537
 * Date: 8/7/2019
 * Time: 11:22 AM
 */
if (empty($size)) $size = "125x113";
?>
    <div class="image-list-wrap <?php echo esc_attr($el_class) ?>">
        <h2 class="title28 fontita black333 no-margin"><?php echo esc_html($title) ?></h2>
        <?php
        if (is_array($data) & count($data) > 0) {
            ?>
            <ul class="list-none flex-wrap flex-wrap-wrap">
                <?php
            foreach ($data as $key => $value){
                if (empty($value['url'])) $value['url'] = "#";
                if (empty($value['custom_class'])) $value['custom_class'] = '';
                ?>
                <li class="<?php echo esc_attr($value['custom_class']) ?>">
                    <a class="hvr-bob" href="<?php echo esc_url($value['url']) ?>">
                        <img src="<?php echo esc_url(wp_get_attachment_image_url($value['image'], $size)) ?>" alt="mega-list-image"/>
                    </a>
                </li>
                <?php
            }
                ?>
            </ul>
            <?php
        }
        ?>
    </div>