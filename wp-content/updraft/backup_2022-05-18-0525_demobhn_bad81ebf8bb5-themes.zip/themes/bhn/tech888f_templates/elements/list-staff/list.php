<?php

?>
<div class="list-staff default flex-wrap flex-wrap-wrap jtf-content-center <?php echo esc_attr($el_class);?>">
    <?php if( !empty($data) && is_array($data)){
        foreach ($data as $key => $value){
            ?>
            <div class="staff-item text-center">
                <?php // if(!empty($value["image"])) echo '<div class="img-wrap">'.wp_get_attachment_image($value["image"],array(346,426),false,'').'</div>' ?>
                <?php
                if(!empty($value["image"])):
                    ?>
                    <div class="img-wrap pst-relative">
                        <div class="social-wrap pst-absolute bg-overlay flex-wrap flex-wrap-wrap jtf-content-center">
                            <a target="_blank" href="<?php $value["link_fb"] = (!empty($value["link_fb"]) ) ? $value["link_fb"] : "#"; echo esc_url($value["link_fb"]) ?>"><i class="fa fa-facebook"></i> </a>
                            <a target="_blank" href="<?php $value["link_yt"] = (!empty($value["link_yt"]) ) ? $value["link_yt"] : "#"; echo esc_url($value["link_yt"]) ?>"><i class="fa fa-youtube"></i> </a>
                            <a target="_blank" href="<?php $value["link_insta"] = (!empty($value["link_insta"]) ) ? $value["link_insta"] : "#"; echo esc_url($value["link_insta"]) ?>"><i class="fa fa-instagram"></i> </a>
                        </div>
                        <?php echo wp_get_attachment_image($value["image"],array(346,426),false,'') ?>
                    </div>
                    <?php
                endif;
                ?>
                <?php if(!empty($value["title"])) echo '<h3 class="title1 no-margin fontphilo title30 font-normal">'.$value["title"].'</h3>'; ?>
                <?php if(!empty($value["des"])) echo '<h3 class="des no-margin font-bold text-uppercase title18 color3">'.$value["des"].'</h3>'; ?>
            </div>
            <?php
        }
    } ?>
</div>