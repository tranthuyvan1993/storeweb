<?php
/**
 * Created by PhpStorm.
 * User: dell3537
 * Date: 10/2/2020
 * Time: 3:08 PM
 */
if(!empty($data)){
   ?>
    <div class="btn-single-wrap btn-single-style3">
        <a class="display-block text-uppercase font-bold title13 text-center" href="<?php echo esc_url($data["url"]) ?>" ><?php echo esc_html($data["title"]) ?></a>
    </div>
    <?php
}