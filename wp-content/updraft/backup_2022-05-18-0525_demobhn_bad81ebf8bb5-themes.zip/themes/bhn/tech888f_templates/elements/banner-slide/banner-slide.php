<?php
/**
 * Created by PhpStorm.
 * User: toan1
 * Date: 07/06/2021
 * Time: 11:18 AM
 */
?>
<div class="banner-wrap">
    <div class="banner-slider <?php echo esc_attr($el_class) ?>">
        <div class="wrap-item bg-slider banner-carousel-slider owl-carousel owl-theme"
             data-item="1"
             data-speed="5000"
             data-itemres="0:1,1000:1"
             data-navigation=""
             data-pagination="true"
             data-prev=""
             data-next=""
             data-margin=""
             data-stage_padding=""
             data-start_position=""
             data-loop=""
             data-animation_out="fadeOut"
             data-animation_in="fadeIn"
             data-mousewheel="">
            <?php
            if(!empty($data) && is_array($data)){
                foreach ($data as $key => $value){
                    ?>
                    <div class="item-slider">
                        <div class="banner-thumb">
                            <a href="<?php echo esc_url($value["link"])?>"><?php echo wp_get_attachment_image($value["image"],array(1920,836),false,'') ?></a>
                        </div>
                        <div class="banner-animate pst-absolute" style="background-image:url(<?php echo get_the_post_thumbnail_url(null,'full') ?>)">
                            <?php // echo get_the_post_thumbnail(null,array(1920,836),''); ?>
                        </div>
                        <div class="banner-info">
                            <div class="container">
                                <div class="slider-content-text text-center">
                                    <?php if(!empty($value["title"])) echo '<h3 class="banner-title1 text-capitalize no-margin title50 fontphilo white">'.esc_html($value["title"]).'</h3>'; //; ?>
                                    <?php if(!empty($value["title2"])) echo '<h3 class="banner-title2 text-capitalize no-margin title60 fontphilo white">'.esc_html($value["title2"]).'</h3>';  ?>
                                    <?php if(!empty($value["des"])) echo '<p class="desc white title18">'.esc_html($value["des"]).'</p>'; ?>
                                    <div class="btn-wrap flex-wrap jtf-content-center btn-single-wrap btn-single-banner"><a class="text-uppercase display-block text-center font-bold bg-color blackmain" href="#">Đăng ký học thử miễn phí</a></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                }
            }
            ?>
        </div>
    </div>
</div>