<?php
/**
 * Created by PhpStorm.
 * User: Admin
 * Date: 15/3/2021
 * Time: 12:37 PM
 */

    if(!empty($data) && is_array($data)){
//    ?>
<div class="row">
<!--    <div class="col-sm-12">-->

        <?php
        foreach ($data as $key => $value){
            $matches = array();
            preg_match("%(?:youtube(?:-nocookie)?\.com/(?:[^/]+/.+/|(?:v|e(?:mbed)?)/|.*[?&]v=)|youtu\.be/)([^\"&?/\s]{11})%i", $value["link"], $matches);
            /*
            Array matches value
            [0] => youtube.com/watch?v=WwPs88cE23U
            [1] => WwPs88cE23U
            */
            if(count($matches) > 0){
                ?>
                <div class="col-sm-4 col-md-4 col-lg-4 youtube-item">
                    <a href="<?php echo esc_url($matches[0])  ?>" data-fancybox="youtube-gallery" >
                        <i class="fa fa-youtube-play title60 iteam"></i>
                        <img src="http://img.youtube.com/vi/<?php echo esc_attr($matches[1]) ?>/mqdefault.jpg"  width="100%"/>
                    </a>
                </div>
                <?php
            }
        }
        ?>
    </div>

<!--</div>-->
<style>
    .youtube-item a i {
        position: absolute;
        top: calc(50% - 30px);
        left: calc(50% - 30px);
        width: 60px;
        height: 60px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .youtube-item{
        margin: 0 0 20px 0;
    }
</style>
<?php } ?>

