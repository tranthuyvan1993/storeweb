<?php
$page_id = apply_filters('tech888f_footer_page_id', tech888f_get_value_by_id('tech888f_footer_page'));
$footer_col_1_title = tech888f_get_option('footer_col_1_title');
$footer_col_1 = tech888f_get_option('footer_col_1');
$background_footer = tech888f_get_option('background_footer');
$footer_col_2_title = tech888f_get_option('footer_col_2_title');
$footer_col_2_subtitle = tech888f_get_option('footer_col_2_subtitle');
$footer_col_2 = tech888f_get_option('footer_col_2');
$footer_col_3_title = tech888f_get_option('footer_col_3_title');
$footer_col_3 = tech888f_get_option('footer_col_3');
$footer_col_3_media = tech888f_get_option('footer_col_3_media');
$footer_col_4_title = tech888f_get_option('footer_col_4_title');
$footer_col_4_fb = tech888f_get_option('footer_col_4_fb');
if (!empty($page_id)) { ?>
    <div id="footer" class="footer-page">
        <div class="container">
            <?php echo Tech888f_Template::get_vc_pagecontent($page_id); ?>
        </div>
    </div>
<?php
} else {
?>
    <style>
        .hp-footer {
            background: url('<?= $background_footer['url'] ?>');
            background-repeat: no-repeat;
            background-position: center;
            background-size: cover;
            padding-top: 50px;
            padding-bottom: 50px;
        }

        .fa-input {
            font-family: FontAwesome;
            font-size: 17px;
            background: #fff;
        }
    </style>
    <div id="fb-root"></div>
    <script async defer crossorigin="anonymous" src="https://connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v13.0" nonce="6R1V1KsD"></script>
    <div id="footer" class="footer-default hp-footer white relative">
        <div class="container hp-footer-top ">
            <div class="row">
                <div class="col-md-3 col-sm-6 padding-bottom-15">
                    <h4 class="relative footer-col-title uppercase"><strong class="line-height-150"><?= $footer_col_1_title ?></strong></h4>
                    <ul>
                        <li class="flex align-center item1"><?= $footer_col_1[0]['icon'] ?><?= $footer_col_1[0]['desc'] ?><?= $footer_col_1[0]['link'] ?></li>
                        <li class="flex align-center item2"><?= $footer_col_1[1]['icon'] ?><?= $footer_col_1[1]['desc'] ?><a class="white" href="tel:<?= $footer_col_1[1]['link'] ?>"><?= $footer_col_1[1]['link'] ?></a></li>
                        <li class="flex align-center item3"><?= $footer_col_1[2]['icon'] ?><?= $footer_col_1[2]['desc'] ?><a class="white" href="<?= $footer_col_1[2]['link'] ?>"><?= $footer_col_1[2]['link'] ?></a></li>
                        <li class="flex align-center item4"><?= $footer_col_1[3]['icon'] ?><?= $footer_col_1[3]['desc'] ?><a class="white" href="mailto:<?= $footer_col_1[3]['link'] ?>"><?= $footer_col_1[3]['link'] ?></a></li>
                    </ul>
                </div>
                <div class="col-md-3 col-sm-6 padding-bottom-15">
                    <h4 class="relative footer-col-title uppercase"><strong class="line-height-150"><?= $footer_col_2_title ?></strong></h4>
                    <div class="padding-bottom-15">Liên hệ với chúng tôi để được hỗ trợ.</div>
                    <div class="flex align-center padding-bottom-15">
                        <input class="black padding-7" type="text" placeholder="Nhập địa chỉ email">
                        <input type="submit" class="padding-7 fa-input color-mainlight" value="&#xf1d9;">
                    </div>
                    <div class="margin-bottom-15"><strong><?= $footer_col_2_subtitle ?></strong></div>
                    <ul>
                        <?php foreach ($footer_col_2 as $item) : ?>
                            <li><?= $item['title'] ?><?= $item['link'] ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <div class="col-md-3 col-sm-6 padding-bottom-15">
                    <h4 class="relative footer-col-title uppercase"><strong class="line-height-150"><?= $footer_col_3_title ?></strong></h4>
                    <ul class="padding-bottom-15">
                        <?php foreach ($footer_col_3 as $item) : ?>
                            <li class="flex align-center"> <i class="fa fa-caret-right padding-right-5"></i><a class="white" href="<?= $item['link'] ?>"><?= $item['title'] ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                    <div class="font36 media-item flex">
                        <?php foreach ($footer_col_3_media as $item) : ?>
                            <div class="padding-right-5"><a class="<?= $item['bg'] ?> flex align-center justify-center" href="<?= $item['link'] ?>" target="_blank"><?= $item['icon'] ?></a></div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <div class="col-md-3 col-sm-6 padding-bottom-15">
                    <h4 class="relative footer-col-title uppercase"><strong class="line-height-150"><?= $footer_col_4_title ?></strong></h4>
                    
                </div>
            </div>
        </div>
    </div>

    <div class="bg-mainbold white padding-top-bottom-5 text-center italic">© Bản quyền thuộc tech888.vn - Thiết kế bởi Toanngo92</div>
<?php
}
?>