<div class="text-center">
	<?php esc_html_e('No any post to display. Please recheck your posts.','posolo');?>
</div>