<?php
$data = '';
global $post;
if (empty($size)) $size = 'full';
$tech888f_image_blog = get_post_meta(get_the_ID(), 'format_image', true);


if ($check_thumb == '1') {
    if (isset($tech888f_image_blog['id'])) {
        $data .= '<div class="single-post-thumb banner-advs">
                    ' . wp_get_attachment_image($tech888f_image_blog['id'], 'full') . '
                </div>';
    } else {
        if (has_post_thumbnail()) {
            $data .= '<div class="single-post-thumb banner-advs">
                        ' . get_the_post_thumbnail(get_the_ID(), $size, array('class' => 'img-responsive')) . '                
                    </div>';
        }
    }
}
?>
<div class="content-single-blog <?php echo (is_sticky()) ? 'sticky' : '' ?>">
    <?php if (!empty($data)) echo apply_filters('tech888f_output_content', $data); ?>
    <div class="content-post-default">
        <div class="row">
            <div class="col-sm-4 col-md-3 col-meta-box">
                <div class="mtb-wrap">
                    <div class="mtb-key"><?php echo esc_html__("Scope", "posolo") ?></div>
                    <div class="mtb-value"><?php echo esc_html(tech888f_get_meta('project_scope_mtb','')) ?></div>
                </div>
                <div class="mtb-wrap">
                    <div class="mtb-key"><?php echo esc_html__("Location", "posolo") ?></div>
                    <div class="mtb-value"><?php echo esc_html(tech888f_get_meta('project_location_mtb','')) ?></div>
                </div>
                <div class="mtb-wrap">
                    <div class="mtb-key"><?php echo esc_html__("Client", "posolo") ?></div>
                    <div class="mtb-value"><?php echo esc_html(tech888f_get_meta('project_client_mtb','')) ?></div>
                </div>
                <div class="mtb-wrap">
                    <div class="mtb-key"><?php echo esc_html__("Architect", "posolo") ?></div>
                    <div class="mtb-value"><?php echo esc_html(tech888f_get_meta('project_architect_mtb','')) ?></div>
                </div>
                <div class="mtb-wrap">
                    <div class="mtb-key"><?php echo esc_html__("Design", "posolo") ?></div>
                    <div class="mtb-value"><?php echo esc_html(tech888f_get_meta('project_photography_mtb','')) ?></div>
                </div>
            </div>
            <div class="col-sm-8 col-md-9 col-content-box">
                <h2 class="title14 project-title font-bold">
                    <?php the_title() ?>
                </h2>
                <div class="excerpt-project-wrap clearfix">
                    <?php the_content(); ?>
                </div>
            </div>
            <div class="col-md-12 col-sm-12 col-xs-12 lst-image-wrap">
                <?php
                $list_img_obj = tech888f_get_meta('project_image_lst_mtb','');
                if(is_array($list_img_obj) && !empty($list_img_obj)){
                    foreach ($list_img_obj as $key => $value) {
                        ?>
                        <img class="img-responsive"
                             src="<?php echo wp_get_attachment_image_src((int)(esc_attr($value["ID"])), 'full')[0]; ?>"/>
                        <?php
                    }
                }
                ?>
            </div>
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="return-cate-wrap">
                    <a href="<?php echo get_post_type_archive_link('project') ?>" class="return-category">
                        <?php echo esc_html__("BACK TO ALL PROJECTS", "posolo"); ?>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>