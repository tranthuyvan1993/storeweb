<?php
$data = '';
global $post;
if (empty($size)) $size = 'full';
if (empty($size_mtb)) $size_mtb = 'full';
if(empty($itemres)) $itemres = '0:2,567:3';
$mtb_image_gallery = tech888f_get_meta('mtb_post_detail_gallery','');
$tech888f_image_blog = get_post_meta(get_the_ID(), 'format_image', true);
if ($check_thumb == '1') {
    if (has_post_thumbnail()) {
        $data .= '<div class="single-post-thumb banner-advs">
                        ' . get_the_post_thumbnail(get_the_ID(), $size) . '
                    </div>';
    }
    if (!empty($mtb_image_gallery)) {
        if (is_array($mtb_image_gallery) && count($mtb_image_gallery) > 0) {
            $data .= '<div class="single-post-gallery-slider"><div class="wrap-item smart-slider owl-carousel owl-theme" data-speed=""  data-item="" data-itemres="'.$itemres.'">';
               foreach ($mtb_image_gallery as $value){
                   $data .= '<a class="gallery-item" href="'.$value['full_url'].'">';
                   $data .= wp_get_attachment_image($value['ID'],$size_mtb);
                  // var_dump($value['ID']);
                   $data .= '</a>';
               }
            $data .= '</div></div>';
        }
    }
}
/*$list_img_obj = rwmb_meta('post_image_lst_mtb');*/
$post_style = tech888f_get_option('tech888f_post_detail_style', '');
?>
<div class="content-single-blog <?php echo (is_sticky()) ? 'sticky' : '' ?>">
    <div class="post-single-gallery">
    <?php if (!empty($data)) echo apply_filters('tech888f_output_content', $data); ?>
    </div>
    <?php // if($check_meta == '1') tech888f_display_metabox();?>
    <div class="content-post-default row">
        <div class="single-post-default-wrap">
            <div class="col-sm-12">
                <div class="single-post-info">
                    <h2 class="title48 post-detail-title fontphilo font-normal blackmain">
                        <?php the_title() ?>
                    </h2>
                    <?php tech888f_display_metabox();?>
                    <div class="detail-content-wrap clearfix"><?php the_content(); ?></div>
                    <div class="tag-list-wrap flex-wrap flex-wrap-wrap">
                        <!--<strong class="tag-title"><?php /*echo esc_html__("Tags:","posolo") */?></strong>-->
                        <div class="tag-list"><?php echo get_the_tag_list("","",""); ?></div>
                        <?php tech888f_get_template( 'share','',false,true ); ?>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>