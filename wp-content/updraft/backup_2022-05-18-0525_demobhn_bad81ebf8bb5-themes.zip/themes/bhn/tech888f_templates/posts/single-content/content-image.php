<?php
$data = '';
global $post;
if (empty($size)) $size = 'full';
$tech888f_image_blog = get_post_meta(get_the_ID(), 'format_image', true);
if($check_thumb == '1'){
    if(isset($tech888f_image_blog['id'])){
        $data .='<div class="single-post-thumb banner-advs">
                    '.wp_get_attachment_image($tech888f_image_blog['id'],'full').'
                </div>';
    }
    else{
        if (has_post_thumbnail()) {
            $data .= '<div class="single-post-thumb banner-advs">
                        '.get_the_post_thumbnail(get_the_ID(),$size).'
                    </div>';
        }
    }
}
/*$list_img_obj = rwmb_meta('post_image_lst_mtb');*/
$post_style = tech888f_get_option('tech888f_post_detail_style', '');
?>
<div class="content-single-blog <?php echo (is_sticky()) ? 'sticky' : '' ?>">
    <?php if (!empty($data)) echo apply_filters('tech888f_output_content', $data); ?>
    <?php // if($check_meta == '1') tech888f_display_metabox();?>
    <div class="content-post-default row">
        <?php if ($post_style == 'style2') {
            ?>
            <div class="single-post-style2-wrap">
                <div class="single-post-thumb col-md-6 col-sm-6">
                    <div class="img-wrap">
                        <?php if (!empty($list_img_obj) && is_array($list_img_obj)) {
                            foreach ($list_img_obj as $key => $value) {
                                echo '<img src="' . wp_get_attachment_url($value['ID']) . '"/>';
                            }
                        } ?>
                    </div>
                </div>
                <div class="single-post-info col-md-6 col-sm-6">
                    <div class="date-wrap"><?php echo get_the_date() ?></div>
                    <h2 class="title11 post-detail-title font-normal text-uppercase">
                        <?php the_title() ?>
                    </h2>
                    <div class="detail-content-wrap clearfix"><?php the_content(); ?></div>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="return-cate-wrap">
                        <?php
                        $categories = get_the_category();
                        $cat_url = get_term_link($categories[0]);
                        ?>
                        <a href="<?php echo esc_url($cat_url) ?>" class="return-category">
                            <?php echo esc_html__("BACK TO ALL NEWS", "posolo"); ?>
                        </a>
                    </div>
                </div>
            </div>
            <?php
        } else {
            ?>
            <div class="single-post-default-wrap">
                <div class="col-sm-12">
                    <div class="single-post-info">
                        <h2 class="title24 post-detail-title font-normal black000">
                            <?php the_title() ?>
                        </h2>
                        <?php tech888f_display_metabox();?>
                        <div class="detail-content-wrap clearfix"><?php the_content(); ?></div>
                        <div class="tag-list-wrap flex-wrap flex-wrap-wrap">
                            <strong class="tag-title"><?php echo esc_html__("Tags:","posolo") ?></strong>
                            <div class="tag-list"><?php echo get_the_tag_list("",",",""); ?></div>
                        </div>

                    </div>
                </div>
            </div>

            <?php
        } ?>
    </div>
</div>