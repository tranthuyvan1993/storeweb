<?php
$data = '';

if (!empty(tech888f_get_meta( 'mtb_post_content_media', ""))) {
  //  $media_url = get_post_meta(get_the_ID(), 'format_media', true);
    $media_url = tech888f_get_meta( 'mtb_post_content_media', "");
    $data .= '<div class="audio single-post-thumb banner-advs">' . tech888f_remove_w3c(wp_oembed_get($media_url, array('height' => '176'))) . '</div>';
}
?>
<div class="content-single-blog <?php echo (is_sticky()) ? 'sticky':''?>">
    <?php if(!empty($data)) echo apply_filters('tech888f_output_content',$data);?>
    <div class="content-post-default row">
            <div class="single-post-default-wrap">
                <div class="col-sm-12">
                    <div class="single-post-info">
                        <h2 class="title24 post-detail-title font-normal black000">
                            <?php the_title() ?>
                        </h2>
                        <?php tech888f_display_metabox();?>
                        <div class="detail-content-wrap clearfix"><?php the_content(); ?></div>
                        <div class="tag-list-wrap flex-wrap flex-wrap-wrap">
                            <strong class="tag-title"><?php echo esc_html__("Tags:","posolo") ?></strong>
                            <div class="tag-list"><?php echo get_the_tag_list("",",",""); ?></div>
                        </div>

                    </div>
                </div>
            </div>
    </div>
</div>