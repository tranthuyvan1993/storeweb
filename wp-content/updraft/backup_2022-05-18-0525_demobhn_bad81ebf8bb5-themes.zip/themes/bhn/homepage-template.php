<?php
/*
 * Template Name: Home Page Template
 *
 *
 * */
get_header();
$nav_prev = "";
$nav_next = "";
$stage_padding = "";
$start_position = "";
$mousewheel = "";
$margin = "";
?>
    <div id="main-content">
        <div class="banner-wrap">
            <div class="banner-slider <?php echo esc_attr($el_class) ?>">
                <div class="wrap-item bg-slider banner-carousel-slider owl-carousel owl-theme"
                     data-item="1"
                     data-speed="5000"
                     data-itemres="0:1,1000:1"
                     data-navigation=""
                     data-pagination="true"
                     data-prev="<?php echo esc_attr($nav_prev) ?>"
                     data-next="<?php echo esc_attr($nav_next) ?>"
                     data-margin="<?php echo esc_attr($margin) ?>"
                     data-stage_padding="<?php echo esc_attr($stage_padding) ?>"
                     data-start_position="<?php echo esc_attr($start_position) ?>"
                     data-loop="<?php echo esc_attr($loop) ?>"
                     data-animation_out="fadeOut"
                     data-animation_in="fadeIn"
                     data-mousewheel="<?php echo esc_attr($mousewheel) ?>">
                    <?php
                    $args = array(
                        'post_type' => 'banner_item',
                        'posts_per_page' => 10,
                        'orderby' => 'date',
                        'order' => 'desc',
                        'paged' => 1,
                    );
                    $post_query = new WP_Query($args);
                    if ($post_query->have_posts()):
                        while ($post_query->have_posts()) {
                            $post_query->the_post();
                            $img_banner = get_the_post_thumbnail();
                            ?>
                            <div class="item-slider">
                                <div class="banner-thumb">
                                    <a href="<?php echo esc_url($link)?>"><?php echo get_the_post_thumbnail(null,array(1920,836),''); ?></a>
                                </div>
                                <div class="banner-animate pst-absolute" style="background-image:url(<?php echo get_the_post_thumbnail_url(null,'full') ?>)">
                                    <?php // echo get_the_post_thumbnail(null,array(1920,836),''); ?>
                                </div>
                                <div class="banner-info">
                                    <div class="container">
                                        <div class="slider-content-text text-center">
                                            <?php if(!empty(rwmb_meta('banner_item_title_1'))) echo '<h3 class="banner-title1 text-capitalize no-margin title50 fontphilo white">'.esc_html(rwmb_meta('banner_item_title_1')).'</h3>'; //; ?>
                                            <?php if(!empty(rwmb_meta('banner_item_title_2'))) echo '<h3 class="banner-title2 text-capitalize no-margin title60 fontphilo white">'.esc_html(rwmb_meta('banner_item_title_2')).'</h3>';  ?>
                                            <?php if(!empty(rwmb_meta('banner_item_desc'))) echo '<p class="desc white title18">'.esc_html(rwmb_meta('banner_item_desc')).'</p>'; ?>
                                            <div class="btn-wrap flex-wrap jtf-content-center btn-single-wrap btn-single-banner"><a class="text-uppercase display-block text-center font-bold bg-color blackmain" href="#">Đăng ký học thử miễn phí</a></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }
                    endif;
                    wp_reset_postdata();
                    ?>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="<?php echo esc_attr(tech888f_get_main_class()); ?>">
                    <?php
                    while (have_posts()) : the_post();

                        /*
                        * Include the post format-specific template for the content. If you want to
                        * use this in a child theme, then include a file called called content-___.php
                        * (where ___ is the post format) and that will be used instead.
                        */
                        ?>
                        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                            <div class="entry-content">
                                <?php the_content(); ?>
                                <?php
                                wp_link_pages(array(
                                    'before' => '<div class="page-links page-links flex-wrap flex-wrap-wrap align-items-center">' . esc_html__('Pages:', 'posolo'),
                                    'after' => '</div>',
                                ));
                                tech888f_get_template('share', '', false, true);
                                ?>
                            </div><!-- .entry-content -->
                        </article><!-- #post-## -->
                        <?php

                        // If comments are open or we have at least one comment, load up the comment template.
                        if (comments_open() || get_comments_number()) :
                            comments_template();
                        endif;


                        // End the loop.
                    endwhile; ?>
                </div>
            </div>

        </div>

    </div>
<?php
get_footer();
